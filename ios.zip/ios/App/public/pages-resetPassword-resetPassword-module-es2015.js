(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-resetPassword-resetPassword-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/resetPassword/resetPassword.component.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/resetPassword/resetPassword.component.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"p-3\">\n  <div class=\"theme-container\">\n\n    <div fxLayout=\"row\" fxLayoutAlign=\"center center\" class=\"my-3 resetPassword-card-container\" fxFlex=\"100\" fxFlex.gt-sm=\"40\" fxFlex.sm=\"50\">\n        <mat-card class=\"resetPassword-card\" [style.max-width.px]=\"500\">\n          <div fxLayout=\"column\" fxLayoutAlign=\"center center\" class=\"text-center\">  \n            <h1 class=\"uppercase\">Reset Password</h1>\n          </div>\n          <form [formGroup]=\"resetPasswordForm\" (ngSubmit)=\"onResetPasswordFormSubmit(resetPasswordForm.value)\">\n              <mat-form-field appearance=\"outline\" class=\"w-100 mt-2\">\n                  <mat-icon matPrefix class=\"mr-1 text-muted\">person</mat-icon>\n                  <mat-label>Email</mat-label>\n                  <input matInput placeholder=\"Email\" formControlName=\"email\" required>\n                  <mat-error *ngIf=\"resetPasswordForm.controls.email.errors?.required\">Email is required</mat-error>\n                  <mat-error *ngIf=\"resetPasswordForm.controls.email.hasError('email')\">Invalid Email</mat-error>\n                  <!-- server-side validation errors -->\n                  <mat-error *ngIf=\"resetPasswordForm.controls.email.errors?.serverError\">\n                    {{ resetPasswordForm.controls.email.errors?.serverError }}\n                  </mat-error>\n              </mat-form-field>\n                <mat-form-field  appearance=\"outline\" class=\"w-100 mt-1\">\n                  <mat-icon matPrefix class=\"mr-1 text-muted\">lock</mat-icon>\n                  <mat-label>Password</mat-label>\n                  <input matInput placeholder=\"Password\" formControlName=\"password\" type=\"password\" minlength=\"6\" required [type]=\"hide ? 'password' : 'text'\">\n                  <mat-error *ngIf=\"resetPasswordForm.controls.password.errors?.required\">Password is required</mat-error>\n                  <mat-error *ngIf=\"resetPasswordForm.controls.password.hasError('minlength')\">Password isn't long enough, minimum of 6 characters</mat-error>\n                  <!-- server-side validation errors -->\n                  <mat-error *ngIf=\"resetPasswordForm.controls.password.errors?.serverError\">\n                    {{ resetPasswordForm.controls.password.errors?.serverError }}\n                  </mat-error>\n                  <button mat-icon-button matSuffix (click)=\"hide = !hide\" type=\"button\" class=\"text-muted\">\n                      <mat-icon>{{hide ? 'visibility_off' : 'visibility'}}</mat-icon>\n                  </button>\n                </mat-form-field> \n                <mat-form-field  appearance=\"outline\" class=\"w-100 mt-1\">\n                  <mat-icon matPrefix class=\"mr-1 text-muted\">lock</mat-icon>\n                  <mat-label>Confirm Password</mat-label>\n                  <input matInput placeholder=\"Confirm Password\" formControlName=\"password_confirmation\" type=\"password\" required [type]=\"hide ? 'password' : 'text'\">\n                  <mat-error *ngIf=\"resetPasswordForm.controls.password_confirmation.errors?.required\">Confirm Password is required</mat-error>\n                  <mat-error *ngIf=\"resetPasswordForm.controls.password_confirmation.hasError('mismatchedPasswords')\">Passwords do not match</mat-error>\n                  <!-- server-side validation errors -->\n                  <mat-error *ngIf=\"resetPasswordForm.controls.password_confirmation.errors?.serverError\">\n                    {{ resetPasswordForm.controls.password_confirmation.errors?.serverError }}\n                  </mat-error>\n                  <button mat-icon-button matSuffix (click)=\"hide = !hide\" type=\"button\" class=\"text-muted\">\n                      <mat-icon>{{hide ? 'visibility_off' : 'visibility'}}</mat-icon>\n                  </button>\n                </mat-form-field>\n              <div class=\"text-center mt-2\"> \n                  <button mat-raised-button color=\"accent\" class=\"uppercase\" type=\"submit\" [disabled]=\"loading\">\n                      Reset Password\n                  </button>\n              </div>\n          </form>\n          <mat-card-actions fxLayoutAlign=\"end center\">\n            <a routerLink=\"/login\" mat-button>\n              <mat-icon class=\"text-muted\">login</mat-icon>\n              <span class=\"mx-1\">Back to Login</span>\n            </a>\n          </mat-card-actions>\n        </mat-card>\n    </div> \n\n  </div>\n</div>");

/***/ }),

/***/ "./src/app/pages/resetPassword/resetPassword.component.scss":
/*!******************************************************************!*\
  !*** ./src/app/pages/resetPassword/resetPassword.component.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".auth {\n  white-space: nowrap;\n  padding: 7px 14px;\n  font-weight: 500;\n}\n\n.alert.alert-danger {\n  color: #ff5252;\n}\n\n.resetPassword-card-container {\n  margin: 0 auto;\n}\n\n.resetPassword-card.mat-card {\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcmVzZXRQYXNzd29yZC9yZXNldFBhc3N3b3JkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBQ0E7RUFDSSxjQUFBO0FBRUo7O0FBQUE7RUFDSSxjQUFBO0FBR0o7O0FBREE7RUFDSSxXQUFBO0FBSUoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9yZXNldFBhc3N3b3JkL3Jlc2V0UGFzc3dvcmQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYXV0aCB7XG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICBwYWRkaW5nOiA3cHggMTRweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xufVxuLmFsZXJ0LmFsZXJ0LWRhbmdlcntcbiAgICBjb2xvcjogI2ZmNTI1Mjtcbn1cbi5yZXNldFBhc3N3b3JkLWNhcmQtY29udGFpbmVye1xuICAgIG1hcmdpbjogMCBhdXRvO1xufVxuLnJlc2V0UGFzc3dvcmQtY2FyZC5tYXQtY2FyZHtcbiAgICB3aWR0aDogMTAwJTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/resetPassword/resetPassword.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/pages/resetPassword/resetPassword.component.ts ***!
  \****************************************************************/
/*! exports provided: ResetPasswordComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetPasswordComponent", function() { return ResetPasswordComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/auth.service */ "./src/app/services/auth.service.ts");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/snack-bar */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/snack-bar.js");
/* harmony import */ var src_app_theme_utils_app_validators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/theme/utils/app-validators */ "./src/app/theme/utils/app-validators.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








let ResetPasswordComponent = class ResetPasswordComponent {
    constructor(fb, router, snackBar, activatedRoute, authService) {
        this.fb = fb;
        this.router = router;
        this.snackBar = snackBar;
        this.activatedRoute = activatedRoute;
        this.authService = authService;
        this.hide = true;
    }
    ngOnInit() {
        this.resetPasswordForm = this.fb.group({
            email: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].email])],
            password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].minLength(8)])],
            password_confirmation: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].minLength(8)])],
        }, { validator: Object(src_app_theme_utils_app_validators__WEBPACK_IMPORTED_MODULE_6__["matchingPasswords"])('password', 'password_confirmation') });
        this.sub = this.activatedRoute.params.subscribe(params => {
            this.sub = this.activatedRoute.queryParams.subscribe(queryParams => {
                this.controls.email.setValue(queryParams['email']);
                this.token = params['token'];
            });
        });
    }
    onResetPasswordFormSubmit(values) {
        if (this.resetPasswordForm.valid) {
            this.loading = true;
            this.errors = false;
            this.authService.reset(this.token, this.controls.email.value, this.controls.password.value, this.controls.password_confirmation.value).subscribe((res) => {
                // Store the access token in the localstorage
                // localStorage.setItem('access_token', res.success.token);
                // localStorage.setItem('user', JSON.stringify(res.success.user));
                // this.authService.loggedIn.next(true);
                this.loading = false;
                this.snackBar.open(res.message, '×', { panelClass: 'success', verticalPosition: 'top', duration: 3000 });
                // Navigate to home page
                this.router.navigate(['/login']);
            }, (err) => {
                if (err instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpErrorResponse"]) {
                    const validationErrors = err.error.errors;
                    if (err.status === 422) {
                        Object.keys(validationErrors).forEach(prop => {
                            const formControl = this.resetPasswordForm.get(prop);
                            if (formControl) {
                                // activate the error message
                                formControl.setErrors({
                                    serverError: validationErrors[prop]
                                });
                            }
                        });
                    }
                }
                // This error can be internal or invalid credentials
                // You need to customize this based on the error.status code
                this.loading = false;
                this.errors = true;
                console.log(err);
                this.snackBar.open('Oops! Something went wrong', '×', { panelClass: 'danger', verticalPosition: 'top', duration: 3000 });
            });
            // this.router.navigate(['/']);
        }
    }
    /**
     * Getter for the form controls
     */
    get controls() {
        return this.resetPasswordForm.controls;
    }
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
};
ResetPasswordComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_5__["MatSnackBar"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] }
];
ResetPasswordComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-resetPassword',
        template: __importDefault(__webpack_require__(/*! raw-loader!./resetPassword.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/resetPassword/resetPassword.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./resetPassword.component.scss */ "./src/app/pages/resetPassword/resetPassword.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_5__["MatSnackBar"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        _services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]])
], ResetPasswordComponent);



/***/ }),

/***/ "./src/app/pages/resetPassword/resetPassword.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/resetPassword/resetPassword.module.ts ***!
  \*************************************************************/
/*! exports provided: routes, ResetPasswordModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetPasswordModule", function() { return ResetPasswordModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/shared.module */ "./src/app/shared/shared.module.ts");
/* harmony import */ var _resetPassword_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./resetPassword.component */ "./src/app/pages/resetPassword/resetPassword.component.ts");
/* harmony import */ var _services_guest_guard_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/guest-guard.service */ "./src/app/services/guest-guard.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






const routes = [
    { path: ':token', component: _resetPassword_component__WEBPACK_IMPORTED_MODULE_4__["ResetPasswordComponent"], canActivate: [_services_guest_guard_service__WEBPACK_IMPORTED_MODULE_5__["GuestGuardService"]] }
];
let ResetPasswordModule = class ResetPasswordModule {
};
ResetPasswordModule = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
        declarations: [_resetPassword_component__WEBPACK_IMPORTED_MODULE_4__["ResetPasswordComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes),
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__["SharedModule"]
        ]
    })
], ResetPasswordModule);



/***/ })

}]);
//# sourceMappingURL=pages-resetPassword-resetPassword-module-es2015.js.map