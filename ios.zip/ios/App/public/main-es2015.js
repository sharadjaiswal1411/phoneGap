(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div id=\"app\" class=\"app\" [dir]=\"(settings.rtl) ? 'rtl' : 'ltr'\"\n            [ngClass]=\"[settings.theme, 'toolbar-'+settings.toolbar]\" \n            [class.main-toolbar-fixed]=\"settings.mainToolbarFixed\"> \n    <router-outlet></router-outlet>\n    <ng-progress \n        [spinner]=\"false\"\n        [meteor]=\"false\" \n        color=\"#e91e63\"></ng-progress>\n</div>\n\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/lock-screen/lock-screen.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/lock-screen/lock-screen.component.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<mat-drawer-container fxFlexFill>\n  <div fxFlexFill fxLayout=\"column\" fxLayoutAlign=\"center center\" class=\"p-3 lock-screen\"> \n    <form [formGroup]=\"form\" (ngSubmit)=\"onSubmit(form.value)\" fxLayout=\"row\" fxLayoutAlign=\"center center\"> \n        <h3 class=\"name text-muted\">Adam Sandler</h3>  \n        <img src=\"assets/images/profile/adam.jpg\" alt=\"\" class=\"mat-elevation-z4\">             \n        <input placeholder=\"Enter password\" formControlName=\"password\" required type=\"password\">\n        <button mat-icon-button color=\"primary\" type=\"submit\" class=\"submit\" [disabled]=\"!form.valid\">\n          <mat-icon>arrow_forward</mat-icon>\n        </button>\n        <a mat-button routerLink=\"/login\" color=\"primary\">Or sign in as a different user</a>  \n    </form>\n     <p class=\"time\">{{ date | date:\"hh:mm:ss a\" }}</p> \n  </div>\n</mat-drawer-container>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/not-found/not-found.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/not-found/not-found.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div fxLayout=\"row\" fxLayoutAlign=\"center center\" class=\"h-100\">\n    <div fxFlex=\"80\" fxFlex.gt-sm=\"30\" fxFlex.sm=\"60\">\n        <mat-card class=\"p-0 mat-elevation-z6 box\">\n            <div fxLayout=\"column\" fxLayoutAlign=\"center center\" class=\"bg-primary box-header\">\n                <mat-icon class=\"mat-icon-xlg\">error</mat-icon>\n                <h1 class=\"error\">404</h1>\n            </div>\n            <mat-card-content fxLayout=\"column\" fxLayoutAlign=\"end center\" class=\"box-content\">\n                <mat-card fxLayout=\"column\" fxLayoutAlign=\"center center\" class=\"mat-elevation-z8 box-content-inner\">\n                    <p class=\"box-text\">Opps, it seems that this page does not exist.</p> \n                    <p class=\"box-text\">If you are sure it should, search for it.</p> \n                    <mat-form-field appearance=\"outline\" class=\"w-100\">\n                        <mat-label>Search keyword</mat-label>\n                        <input matInput placeholder=\"Enter search keyword...\">\n                    </mat-form-field>\n                </mat-card>\n                <div class=\"box-footer\">\n                    <button mat-raised-button color=\"primary\" class=\"mat-elevation-z8\" type=\"button\" (click)=\"goHome()\">\n                        <mat-icon>home</mat-icon>\n                    </button>\n                    <button mat-raised-button color=\"primary\" class=\"mat-elevation-z8\" type=\"button\" (click)=\"goHome()\">\n                        <mat-icon>search</mat-icon>\n                    </button>\n                </div>\n            </mat-card-content>\n        </mat-card>          \n    </div>\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pages.component.html":
/*!**********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pages.component.html ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<mat-sidenav-container> \n    <mat-sidenav [opened]=\"false\" mode=\"over\" #sidenav class=\"sidenav mat-elevation-z6\">\n        <button mat-icon-button color=\"warn\" class=\"close\" (click)=\"sidenav.close()\">\n           <mat-icon color=\"warn\">close</mat-icon>\n        </button>\n        <div class=\"divider\"></div>\n\n        <div perfectScrollbar class=\"vertical-menu-wrapper\">\n            <app-vertical-menu [menuParentId]=\"0\"></app-vertical-menu>    \n        </div>       \n\n        <div class=\"divider\"></div>\n        <app-social-icons [iconSize]=\"'xlg'\" [iconColor]=\"'primary'\" fxLayout=\"row\" fxLayoutAlign=\"center center\"></app-social-icons>\n        \n    </mat-sidenav>\n\n    <mat-sidenav-content class=\"page-wrapper\" fxLayout=\"column\" fxLayoutAlign=\"start stretch\">\n\n        <header [ngClass]=\"'toolbar-'+settings.toolbar\" [class.has-bg-image]=\"settings.headerBgImage\" [class.main-toolbar-fixed]=\"settings.mainToolbarFixed\">\n\n            <app-toolbar1 *ngIf=\"settings.toolbar == 1\" (onMenuIconClick)=\"sidenav.toggle()\"></app-toolbar1>\n            <app-toolbar2 *ngIf=\"settings.toolbar == 2\" (onMenuIconClick)=\"sidenav.toggle()\"></app-toolbar2>\n        \n        </header>\n          \n        <main [class.content-offset-to-top]=\"settings.contentOffsetToTop\">\n            <router-outlet></router-outlet>              \n        </main>\n\n        <div class=\"sticky-footer-helper\" fxFlex=\"grow\"></div>\n\n        <app-footer></app-footer>\n       \n        <div fxLayout=\"row\" fxLayoutAlign=\"center center\" class=\"options-icon\" (click)=\"options.toggle()\">\n            <mat-icon>settings</mat-icon>\n        </div>\n        \n        <div *ngIf=\"showBackToTop\" fxLayout=\"row\" fxLayoutAlign=\"center center\" class=\"back-to-top\" (click)=\"scrollToTop()\">\n            <mat-icon>arrow_upward</mat-icon>\n        </div>\n\n    </mat-sidenav-content> \n    \n    <mat-sidenav #options position=\"end\" class=\"options\" autoFocus=\"false\">\n        <div fxLayout=\"row\" fxLayoutAlign=\"space-between center\" class=\"op-header mat-elevation-z1\">\n            <h2>Settings</h2>\n            <button mat-icon-button (click)=\"options.toggle()\" color=\"accent\">\n                <mat-icon>close</mat-icon>\n            </button>\n        </div> \n        <div perfectScrollbar>\n            <div fxLayout=\"column\" class=\"control\">\n                <h4>Layout</h4>\n                <div fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n                    <span>Sticky Menu Toolbar</span>\n                    <mat-slide-toggle [checked]=\"settings.stickyMenuToolbar\" (change)=\"settings.stickyMenuToolbar = !settings.stickyMenuToolbar\" labelPosition=\"before\"></mat-slide-toggle>\n                </div>                 \n                <div fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n                    <span>RTL</span>\n                    <mat-slide-toggle [checked]=\"settings.rtl\" (change)=\"settings.rtl = !settings.rtl\" labelPosition=\"before\"></mat-slide-toggle>\n                </div> \n            </div>\n\n            <div fxLayout=\"column\" class=\"control\">\n                <h4>Choose toolbar type</h4>\n                <mat-radio-group [(ngModel)]=\"toolbarTypeOption\" (change)=\"chooseToolbarType()\">\n                    <mat-radio-button *ngFor=\"let toolbarType of toolbarTypes\" [value]=\"toolbarType\">toolbar-{{toolbarType}}</mat-radio-button>\n                </mat-radio-group>\n            </div>\n            \n            <div fxLayout=\"column\" class=\"control\">\n                <h4>Choose header type</h4>\n                <mat-radio-group [(ngModel)]=\"headerTypeOption\" (change)=\"chooseHeaderType()\">\n                    <mat-radio-button *ngFor=\"let headerType of headerTypes\" [value]=\"headerType\">{{headerType}}</mat-radio-button>\n                </mat-radio-group>\n            </div>\n\n            <div fxLayout=\"column\" class=\"control\">\n                <h4>Choose theme skin</h4> \n                <div fxLayout=\"row\" fxLayoutAlign=\"space-between center\"> \n                    <div class=\"skin-primary blue\" (click)=\"changeTheme('blue')\"></div>  \n                    <div class=\"skin-primary green\" (click)=\"changeTheme('green')\"></div> \n                    <div class=\"skin-primary red\" (click)=\"changeTheme('red')\"></div> \n                    <div class=\"skin-primary pink\" (click)=\"changeTheme('pink')\"></div> \n                    <div class=\"skin-primary purple\" (click)=\"changeTheme('purple')\"></div>\n                    <div class=\"skin-primary grey\" (click)=\"changeTheme('grey')\"></div>\n                    <div class=\"skin-primary orange-dark\" (click)=\"changeTheme('orange-dark')\"><div class=\"skin-secondary\"></div></div>\n                </div>\n            </div>\n\n            <div fxLayout=\"column\" class=\"control\">\n                <h4>Choose search panel variant</h4>\n                <mat-radio-group [(ngModel)]=\"searchPanelVariantOption\" (change)=\"chooseSearchPanelVariant()\">\n                    <mat-radio-button *ngFor=\"let searchPanelVariant of searchPanelVariants\" [value]=\"searchPanelVariant\">variant-{{searchPanelVariant}}</mat-radio-button>\n                </mat-radio-group>\n                <mat-slide-toggle [checked]=\"settings.searchOnBtnClick\" (change)=\"settings.searchOnBtnClick = !settings.searchOnBtnClick\" labelPosition=\"after\">Search On Button Click</mat-slide-toggle>\n            </div> \n\n        </div>\n    </mat-sidenav>\n    \n</mat-sidenav-container> ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/back-button/back-button.component.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/back-button/back-button.component.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<a *ngIf=\"showBack\"  href=\"javascript:void(0)\" (click)=\"goBack()\">\n<mat-icon                \nmatBadgeSize=\"small\" \nmatBadgeColor=\"warn\">arrow_back</mat-icon>\n\n</a>\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/clients/clients.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/clients/clients.component.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"section mt-3\">\n  <div class=\"px-3\">\n      <div class=\"theme-container\">\n          <h1 class=\"section-title mb-3\">Our Clients</h1>\n          <p class=\"text-center\">Sed magna ipsum, ultricies sed sagittis nec, scelerisque eu libero. Donec at metus ac eros accumsan semper.</p>\n\n          <div class=\"clients-carousel\"> \n              <div class=\"swiper-container h-100\" [swiper]=\"config\"> \n                  <div class=\"swiper-wrapper h-100\">      \n                      <div *ngFor=\"let client of clients\" class=\"swiper-slide\">\n                          <div class=\"client-item\"> \n                              <img [attr.data-src]=\"client.image\" class=\"swiper-lazy\"> \n                              <div class=\"swiper-lazy-preloader\"></div>\n                          </div>\n                      </div>\n                  </div> \n              </div>\n          </div>\n              \n      </div>\n  </div>   \n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/comments/comments.component.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/comments/comments.component.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<mat-card class=\"p-5 mt-5\">\n    <mat-card-header fxLayoutAlign=\"center center\"> \n        <mat-card-title class=\"uppercase\">Leave a Reply</mat-card-title> \n    </mat-card-header>                \n    <div class=\"divider\"></div>\n    <mat-list class=\"reviews mt-3\">\n        <mat-list-item *ngFor=\"let review of reviews\" class=\"h-100\">\n            <img matListAvatar [src]=\"review.avatar\" alt=\"image\" class=\"review-author\">\n            <p matLine fxLayoutAlign=\"start center\">\n                <span class=\"fw-500\">{{review.author}}</span> \n                <mat-icon class=\"text-muted px-1\" [matTooltip]=\"review.tooltip\" matTooltipPosition=\"after\">{{review.icon}}</mat-icon>\n            </p>\n            <p matLine class=\"text-muted\"><small>{{review.date}}</small></p>\n            <p matLine class=\"text\">{{review.text}}</p>\n        </mat-list-item>\n    </mat-list>                    \n    <h3 class=\"mt-3\">LEAVE YOUR REVIEW</h3>\n    <div class=\"divider\"></div>\n    <p class=\"mt-3 text-muted\">Your email address will not be published. Required fields are marked *</p>\n    <h3 fxLayoutAlign=\"start center\" class=\"my-3 text-muted\">\n        <span>Your Rating:</span>\n        <button *ngFor=\"let rating of ratings\" mat-icon-button [matTooltip]=\"rating.title\" matTooltipPosition=\"above\" (click)=\"rate(rating)\">\n          <mat-icon class=\"mat-icon-lg\" [class.primary-color]=\"rating.selected\">{{rating.icon}}</mat-icon>\n        </button>\n    </h3>\n    <form [formGroup]=\"commentForm\" (ngSubmit)=\"onCommentFormSubmit(commentForm.value)\" fxLayout=\"row wrap\" fxLayoutAlign=\"space-between\" class=\"comment-form\">\n        <div fxFlex=\"100\" class=\"p-2\">\n            <mat-form-field appearance=\"outline\" class=\"w-100\">\n                <mat-label>Your review</mat-label>\n                <textarea matInput placeholder=\"Your review\" formControlName=\"review\" required rows=\"5\"></textarea>\n                <mat-error *ngIf=\"commentForm.controls.review.errors?.required\">Review is required</mat-error>\n            </mat-form-field>\n        </div>\n        <div fxFlex=\"100\" fxFlex.gt-sm=\"49\" class=\"p-2\">\n            <mat-form-field appearance=\"outline\" class=\"w-100\">\n                <mat-label>Your name</mat-label>\n                <input matInput placeholder=\"Your name\" formControlName=\"name\" required>\n                <mat-error *ngIf=\"commentForm.controls.name.errors?.required\">Name is required</mat-error>\n                <mat-error *ngIf=\"commentForm.controls.name.hasError('minlength')\">Name isn't long enough, minimum of 4 characters</mat-error>\n            </mat-form-field> \n        </div>\n        <div fxFlex=\"100\" fxFlex.gt-sm=\"49\" class=\"p-2\">\n            <mat-form-field appearance=\"outline\" class=\"w-100\">\n                <mat-label>Your email</mat-label>\n                <input matInput placeholder=\"Your email\" formControlName=\"email\" required>\n                <mat-error *ngIf=\"commentForm.controls.email.errors?.required\">Email is required</mat-error>\n                <mat-error *ngIf=\"commentForm.controls.email.hasError('invalidEmail')\">Invalid email address</mat-error>\n            </mat-form-field> \n        </div>\n        <div fxFlex=\"100\" class=\"text-center w-100\">\n            <button mat-raised-button color=\"primary\" type=\"submit\" class=\"uppercase\">Submit review</button>\n        </div>\n    </form>\n</mat-card>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/compare-overview/compare-overview.component.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/compare-overview/compare-overview.component.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<mat-toolbar fxLayoutAlign=\"space-between center\">      \n  <a routerLink=\"/compare\" (click)=\"hideSheet(true)\" mat-raised-button color=\"primary\">Compare - {{ properties.length }}</a>        \n  <div fxLayout=\"row\" fxLayoutAlign=\"end center\">\n      <button mat-icon-button (click)=\"appService.Data.compareList.length = 0; hideSheet(false)\" matTooltip=\"Clear Compare List\">\n        <mat-icon color=\"warn\" class=\"mat-icon-lg\">cancel</mat-icon> \n      </button>\n      <button mat-icon-button (click)=\"hideSheet(false)\" matTooltip=\"Hide\">\n        <mat-icon color=\"primary\" class=\"mat-icon-lg\">arrow_drop_down_circle</mat-icon> \n      </button>\n  </div>\n</mat-toolbar>\n<mat-nav-list>\n  <a mat-list-item *ngFor=\"let property of properties\" [routerLink]=\"['/properties', property.id]\" (click)=\"hideSheet(true)\">\n    <h3 mat-line class=\"fw-500\">{{property.title}}</h3>\n    <i mat-line><mat-icon class=\"mat-icon-sm text-muted\">location_on</mat-icon><small>{{property.formattedAddress}}</small></i>\n    <span *ngIf=\"settings.currency == 'USD'\" class=\"primary-color price fw-500 mx-2\">\n        <span *ngIf=\"property.priceDollar.sale\">{{property.priceDollar.sale | currency : 'USD' : 'symbol' : '1.0'}}</span>\n        <span *ngIf=\"property.priceDollar.rent\">{{property.priceDollar.rent | currency : 'USD' : 'symbol' : '1.0'}} /month</span>\n    </span>\n    <span *ngIf=\"settings.currency == 'EUR'\" class=\"primary-color price fw-500 mx-2\">\n        <span *ngIf=\"property.priceEuro.sale\">{{property.priceEuro.sale | currency : 'EUR' : 'symbol' : '1.0'}}</span>\n        <span *ngIf=\"property.priceEuro.rent\">{{property.priceEuro.rent | currency : 'EUR' : 'symbol' : '1.0'}} /month</span>\n    </span>  \n    <button mat-icon-button color=\"warn\" class=\"remove\" (click)=\"remove(property, $event)\" matTooltip=\"Remove\" matTooltipPosition=\"after\">\n        <mat-icon class=\"mat-icon-sm\">close</mat-icon>\n    </button>\n  </a>\n</mat-nav-list>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/get-in-touch/get-in-touch.component.html":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/get-in-touch/get-in-touch.component.html ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"px-3\">\n    <div class=\"theme-container\"> \n\n        <div class=\"get-in-touch bg-primary\" ngClass.lt-md=\"mt-3\">\n            \n            <img src=\"assets/images/others/operator.png\" alt=\"operator\" fxShow=\"false\" fxShow.gt-xs>\n\n            <div fxLayout=\"row wrap\" fxLayoutAlign=\"space-between center\" class=\"content\" ngClass.xs=\"p-0\"> \n                <div fxLayout=\"column\" class=\"p-3\">\n                    <h2>LOOKING TO SELL YOUR HOME?</h2>\n                    <p class=\"mb-0\">Lorem ipsum dolor sit, amet consectetur adipisicing elit.</p>\n                </div>\n                <div fxLayout=\"row\" fxLayoutAlign=\"start center\" class=\"p-3\">\n                    <mat-icon class=\"mat-icon-xlg mx-2\">call</mat-icon>\n                    <div fxLayout=\"column\">               \n                        <p class=\"mb-0\">CALL US NOW</p>\n                        <h2 class=\"ws-nowrap\">(+100) 123 456 7890</h2>\n                    </div>\n                </div>\n                <div class=\"p-3\">\n                    <a mat-flat-button routerLink=\"/contact\" class=\"mx-3 uppercase\">get in touch</a>\n                </div>\n            </div> \n\n        </div>\n\n    </div>\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/header-carousel/header-carousel.component.html":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/header-carousel/header-carousel.component.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-carousel\" [class.offset-bottom]=\"contentOffsetToTop\">\n    <div *ngIf=\"slides.length > 1\"  class=\"swiper-container h-100\" [swiper]=\"config\" (indexChange)=\"onIndexChange($event)\">\n        <div class=\"swiper-wrapper h-100\">      \n            <div *ngFor=\"let slide of slides;\" class=\"swiper-slide\">\n                <div [attr.data-background]=\"slide.image\" class=\"slide-item swiper-lazy\">\n                    <div class=\"swiper-lazy-preloader\"></div>\n                </div>\n            </div>\n        </div>     \n        <button mat-mini-fab color=\"primary\" class=\"swiper-button-prev swipe-arrow\"><mat-icon>keyboard_arrow_left</mat-icon></button>\n        <button mat-mini-fab color=\"primary\" class=\"swiper-button-next swipe-arrow\"><mat-icon>keyboard_arrow_right</mat-icon></button>\n      \n        <div fxLayout=\"column\" fxLayoutAlign=\"center center\" class=\"slide-info\" [dir]=\"(settings.rtl) ? 'rtl' : 'ltr'\">\n            <mat-card class=\"p-4\">\n                <h1 class=\"slide-title\">{{currentSlide.title}}</h1>\n                <p class=\"location\" fxLayout=\"row\" fxLayoutAlign=\"center center\">\n                    <mat-icon color=\"primary\" ngClass.gt-sm=\"mat-icon-lg\">location_on</mat-icon>\n                    <span class=\"px-1\">{{currentSlide.location}}</span>\n                </p> \n                <button mat-raised-button color=\"primary\" class=\"price\">                        \n                    <span *ngIf=\"settings.currency == 'USD'\" class=\"price\">\n                        <span *ngIf=\"currentSlide.priceDollar.sale\">{{currentSlide.priceDollar.sale | currency : 'USD' : 'symbol' : '1.0'}}</span>\n                        <span *ngIf=\"currentSlide.priceDollar.rent\">{{currentSlide.priceDollar.rent | currency : 'USD' : 'symbol' : '1.0'}} /month</span>\n                    </span>\n                    <span *ngIf=\"settings.currency == 'EUR'\" class=\"price\">\n                        <span *ngIf=\"currentSlide.priceEuro.sale\">{{currentSlide.priceEuro.sale | currency : 'EUR' : 'symbol' : '1.0'}}</span>\n                        <span *ngIf=\"currentSlide.priceEuro.rent\">{{currentSlide.priceEuro.rent | currency : 'EUR' : 'symbol' : '1.0'}} /month</span>\n                    </span>\n                </button>                  \n            </mat-card>  \n        </div> \n    </div>\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/header-image/header-image.component.html":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/header-image/header-image.component.html ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-image-wrapper\" [dir]=\"(settings.rtl) ? 'rtl' : 'ltr'\">\n    <div class=\"bg\" [style.background-image]=\"bgImage\" [class.bg-anime]=\"bgImageAnimate\"></div>\n    <div class=\"mask\"></div>\n   \n    <div class=\"header-image-content\" fxLayout=\"column\" fxLayoutAlign=\"center center\" [class.offset-bottom]=\"contentOffsetToTop\" [class.home-page]=\"isHomePage\"  [style.min-height.px]=\"contentMinHeight\">\n        <h1 *ngIf=\"title\" class=\"title\">{{title}}</h1>\n        <p *ngIf=\"desc\" class=\"desc\">{{desc}}</p>\n        <div *ngIf=\"isHomePage\" ngClass.gt-xs=\"mt-4\" ngClass.xs=\"mt-3\">\n          <!-- <a mat-raised-button routerLink=\"/about\">about us</a> -->\n          <!-- <a mat-raised-button routerLink=\"/contact\">contact</a>       -->\n        </div>\n    </div>\n  </div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/load-more/load-more.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/load-more/load-more.component.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div id=\"load-more\">\n  <div *ngIf=\"!settings.loadMore.complete\">\n      <button *ngIf=\"!settings.loadMore.start\" mat-raised-button color=\"primary\" (click)=\"startLoad()\" class=\"uppercase\">Load More</button>\n      <mat-spinner *ngIf=\"settings.loadMore.start\"></mat-spinner> \n  </div>\n  <mat-chip-list *ngIf=\"settings.loadMore.complete\">\n      <mat-chip selected disableRipple=\"true\" color=\"warn\" class=\"uppercase ws-nowrap\">\n          {{settings.loadMore.result}} results\n      </mat-chip> \n  </mat-chip-list>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/logo/logo.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/logo/logo.component.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"logo header-logo\">\n\t<img *ngIf=\"!isHeader || (settings.headerBgImage && !settings.mainToolbarFixed)\" src=\"assets/images/logos/homevoxx-logo-whitetext-transparent.png\" alt=\"logo\" width=\"212\" height=\"47\">\n\t<img *ngIf=\"isHeader && (!settings.headerBgImage || settings.mainToolbarFixed)\" src=\"assets/images/logos/homevoxx-logo-transparent.png\" alt=\"logo\" width=\"212\" height=\"47\">\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/mission/mission.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/mission/mission.component.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"section default\">\n    <div class=\"px-3\">\n        <div class=\"theme-container\">\n            <h1 class=\"section-title\">Our Mission</h1>            \n\n            <mat-card class=\"p-0\" fxLayout=\"row wrap\"> \n                <div fxFlex=\"100\" fxFlex.gt-md=\"50\" class=\"p-3\">            \n                   <div fxLayout=\"row wrap\">\n                        <div fxFlex=\"100\" fxFlex.gt-xs=\"50\" class=\"p-2\">\n                            <mat-icon color=\"primary\" class=\"mat-icon-xlg\">monetization_on</mat-icon>\n                            <h2 class=\"capitalize fw-600 my-2\">save money</h2>\n                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae dolor magnam, facilis voluptas quia excepturi provident cupiditate.</p>\n                        </div>\n                        <div fxFlex=\"100\" fxFlex.gt-xs=\"50\" class=\"p-2\">\n                            <mat-icon color=\"primary\" class=\"mat-icon-xlg\">thumb_up</mat-icon>\n                            <h2 class=\"capitalize fw-600 my-2\">better ideas</h2>\n                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae dolor magnam, facilis voluptas quia excepturi provident cupiditate.</p>\n                        </div>\n                        <div fxFlex=\"100\" fxFlex.gt-xs=\"50\" class=\"p-2\">\n                            <mat-icon color=\"primary\" class=\"mat-icon-xlg\">group</mat-icon>\n                            <h2 class=\"capitalize fw-600 my-2\">collaboration</h2>\n                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae dolor magnam, facilis voluptas quia excepturi provident cupiditate.</p>\n                        </div>\n                        <div fxFlex=\"100\" fxFlex.gt-xs=\"50\" class=\"p-2\">\n                            <mat-icon color=\"primary\" class=\"mat-icon-xlg\">search</mat-icon>\n                            <h2 class=\"capitalize fw-600 my-2\">easy to find</h2>\n                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae dolor magnam, facilis voluptas quia excepturi provident cupiditate.</p>\n                        </div>\n                   </div>                     \n                </div> \n                <div fxFlex=\"100\" fxFlex.gt-md=\"50\" fxShow=\"false\" fxShow.gt-md>                    \n                    <img src=\"assets/images/others/mission.jpg\" alt=\"mission\" class=\"mw-100 d-block\">                \n                </div>            \n            </mat-card>\n                \n        </div>\n    </div>   \n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/our-agents/our-agents.component.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/our-agents/our-agents.component.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"section agents\">\n    <div class=\"px-3\">\n        <div class=\"theme-container\">\n            <h1 class=\"section-title\">Meet our agents</h1>\n\n            <div class=\"agents-carousel\"> \n                <div class=\"swiper-container h-100 carousel-outer\" [swiper]=\"config\"> \n                    <div class=\"swiper-wrapper h-100\">      \n                        <div *ngFor=\"let agent of agents\" class=\"swiper-slide\">\n\n                            <mat-card>\n                                <img mat-card-image [attr.data-src]=\"agent.image\" alt=\"\" class=\"swiper-lazy d-block\">\n                                <div class=\"swiper-lazy-preloader\"></div>\n                                <mat-card-content>\n                                    <h2 class=\"fw-600\">{{agent.fullName}}</h2>\n                                    <app-rating [ratingsCount]=\"agent.ratingsCount\" [ratingsValue]=\"agent.ratingsValue\"></app-rating>\n                                    <p class=\"mt-3\">{{agent.desc}}</p>                                    \n                                    <p fxLayoutAlign=\"start center\"><mat-icon color=\"primary\" matTooltip=\"Organization\" matTooltipPosition=\"above\">business</mat-icon><span class=\"mx-2\">{{agent.organization}}</span></p>\n                                    <p fxLayoutAlign=\"start center\"><mat-icon color=\"primary\">email</mat-icon><span class=\"mx-2\">{{agent.email}}</span></p>\n                                    <p fxLayoutAlign=\"start center\"><mat-icon color=\"primary\">call</mat-icon><span class=\"mx-2\">{{agent.phone}}</span></p>\n                                </mat-card-content>\n                                <mat-divider></mat-divider>\n                                <mat-card-actions fxLayoutAlign=\"space-between center\">\n                                    <div fxLayout=\"row\" fxLayoutAlign=\"start center\" class=\"text-muted\">\n                                        <a [href]=\"'https://www.facebook.com/'+agent.social.facebook\" target=\"blank\" class=\"social-icon\">\n                                          <svg class=\"mat-icon\" viewBox=\"0 0 24 24\">\n                                            <path d=\"M5,3H19A2,2 0 0,1 21,5V19A2,2 0 0,1 19,21H5A2,2 0 0,1 3,19V5A2,2 0 0,1 5,3M18,5H15.5A3.5,3.5 0 0,0 12,8.5V11H10V14H12V21H15V14H18V11H15V9A1,1 0 0,1 16,8H18V5Z\" />\n                                          </svg>\n                                        </a>\n                                        <a [href]=\"'https://twitter.com/'+agent.social.twitter\" target=\"blank\" class=\"social-icon\">\n                                          <svg class=\"mat-icon\" viewBox=\"0 0 24 24\">\n                                              <path d=\"M5,3H19A2,2 0 0,1 21,5V19A2,2 0 0,1 19,21H5A2,2 0 0,1 3,19V5A2,2 0 0,1 5,3M17.71,9.33C18.19,8.93 18.75,8.45 19,7.92C18.59,8.13 18.1,8.26 17.56,8.33C18.06,7.97 18.47,7.5 18.68,6.86C18.16,7.14 17.63,7.38 16.97,7.5C15.42,5.63 11.71,7.15 12.37,9.95C9.76,9.79 8.17,8.61 6.85,7.16C6.1,8.38 6.75,10.23 7.64,10.74C7.18,10.71 6.83,10.57 6.5,10.41C6.54,11.95 7.39,12.69 8.58,13.09C8.22,13.16 7.82,13.18 7.44,13.12C7.81,14.19 8.58,14.86 9.9,15C9,15.76 7.34,16.29 6,16.08C7.15,16.81 8.46,17.39 10.28,17.31C14.69,17.11 17.64,13.95 17.71,9.33Z\" />\n                                          </svg> \n                                        </a>\n                                        <a [href]=\"'https://www.linkedin.com/'+agent.social.linkedin\" target=\"blank\" class=\"social-icon\"> \n                                          <svg class=\"mat-icon\" viewBox=\"0 0 24 24\">\n                                            <path d=\"M19,3A2,2 0 0,1 21,5V19A2,2 0 0,1 19,21H5A2,2 0 0,1 3,19V5A2,2 0 0,1 5,3H19M18.5,18.5V13.2A3.26,3.26 0 0,0 15.24,9.94C14.39,9.94 13.4,10.46 12.92,11.24V10.13H10.13V18.5H12.92V13.57C12.92,12.8 13.54,12.17 14.31,12.17A1.4,1.4 0 0,1 15.71,13.57V18.5H18.5M6.88,8.56A1.68,1.68 0 0,0 8.56,6.88C8.56,5.95 7.81,5.19 6.88,5.19A1.69,1.69 0 0,0 5.19,6.88C5.19,7.81 5.95,8.56 6.88,8.56M8.27,18.5V10.13H5.5V18.5H8.27Z\" />\n                                          </svg>\n                                        </a>\n                                        <a [href]=\"'https://instagram.com/'+agent.social.instagram\" target=\"blank\" class=\"social-icon\"> \n                                          <svg class=\"mat-icon\" viewBox=\"0 0 24 24\">\n                                              <path d=\"M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2A5.8,5.8 0 0,1 16.2,22H7.8C4.6,22 2,19.4 2,16.2V7.8A5.8,5.8 0 0,1 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4C4,18.39 5.61,20 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6C20,5.61 18.39,4 16.4,4H7.6M17.25,5.5A1.25,1.25 0 0,1 18.5,6.75A1.25,1.25 0 0,1 17.25,8A1.25,1.25 0 0,1 16,6.75A1.25,1.25 0 0,1 17.25,5.5M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z\" />\n                                          </svg>\n                                        </a> \n                                        <a [href]=\"agent.social.website\" target=\"blank\" class=\"social-icon\"> \n                                          <svg class=\"mat-icon\" viewBox=\"0 0 24 24\">\n                                              <path d=\"M10.59,13.41C11,13.8 11,14.44 10.59,14.83C10.2,15.22 9.56,15.22 9.17,14.83C7.22,12.88 7.22,9.71 9.17,7.76V7.76L12.71,4.22C14.66,2.27 17.83,2.27 19.78,4.22C21.73,6.17 21.73,9.34 19.78,11.29L18.29,12.78C18.3,11.96 18.17,11.14 17.89,10.36L18.36,9.88C19.54,8.71 19.54,6.81 18.36,5.64C17.19,4.46 15.29,4.46 14.12,5.64L10.59,9.17C9.41,10.34 9.41,12.24 10.59,13.41M13.41,9.17C13.8,8.78 14.44,8.78 14.83,9.17C16.78,11.12 16.78,14.29 14.83,16.24V16.24L11.29,19.78C9.34,21.73 6.17,21.73 4.22,19.78C2.27,17.83 2.27,14.66 4.22,12.71L5.71,11.22C5.7,12.04 5.83,12.86 6.11,13.65L5.64,14.12C4.46,15.29 4.46,17.19 5.64,18.36C6.81,19.54 8.71,19.54 9.88,18.36L13.41,14.83C14.59,13.66 14.59,11.76 13.41,10.59C13,10.2 13,9.56 13.41,9.17Z\" />\n                                          </svg>\n                                        </a>  \n                                    </div>\n                                    <div>\n                                        <a [routerLink]=\"['/agents', agent.id]\" mat-button color=\"primary\" class=\"uppercase\">View Profile</a>\n                                    </div> \n                                </mat-card-actions>                              \n                            </mat-card>\n                            \n                        </div>\n                    </div>                      \n                    <button mat-mini-fab color=\"primary\" class=\"swiper-button-prev swipe-arrow\"><mat-icon>keyboard_arrow_left</mat-icon></button>\n                    <button mat-mini-fab color=\"primary\" class=\"swiper-button-next swipe-arrow\"><mat-icon>keyboard_arrow_right</mat-icon></button> \n                </div>\n            </div>\n\n            <div class=\"w-100 text-center mt-5\">\n                <a routerLink=\"/agents\" mat-raised-button color=\"primary\" class=\"uppercase\">Our agents</a>\n            </div>           \n                \n        </div>\n    </div>   \n</div>\n\n ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/our-services/our-services.component.html":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/our-services/our-services.component.html ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"section mt-3\">\n    <div class=\"px-3\">\n        <div class=\"theme-container\">\n            <h1 class=\"section-title\">Our Services</h1> \n\n            <div fxLayout=\"row wrap\" class=\"services-wrapper\">\n                <div fxFlex=\"100\" fxFlex.gt-md=\"25\" fxFlex.gt-sm=\"50\" class=\"p-2\">\n                 \n                    <mat-card fxLayout=\"column\" fxLayoutAlign=\"start center\" class=\"h-100 w-100 text-center\">            \n                        <mat-icon class=\"mat-icon-xlg\" color=\"primary\">location_on</mat-icon>\n                        <h2 class=\"capitalize fw-600 my-3\">Find places anywhere in the world</h2>\n                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum egestas nunc sed ultricies.</p>           \n                    </mat-card>\n                   \n                </div>\n                <div fxFlex=\"100\" fxFlex.gt-md=\"25\" fxFlex.gt-sm=\"50\" class=\"p-2\">\n                 \n                    <mat-card fxLayout=\"column\" fxLayoutAlign=\"start center\" class=\"h-100 w-100 text-center\">            \n                        <mat-icon class=\"mat-icon-xlg\" color=\"primary\">supervisor_account</mat-icon>\n                        <h2 class=\"capitalize fw-600 my-3\">We have agents with experience</h2>\n                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum egestas nunc sed ultricies.</p>             \n                    </mat-card>\n                   \n                </div>\n\n                <div fxFlex=\"100\" fxFlex.gt-md=\"25\" fxFlex.gt-sm=\"50\" class=\"p-2\">\n                 \n                    <mat-card fxLayout=\"column\" fxLayoutAlign=\"start center\" class=\"h-100 w-100 text-center\">            \n                        <mat-icon class=\"mat-icon-xlg\" color=\"primary\">home</mat-icon>\n                        <h2 class=\"capitalize fw-600 my-3\">Buy or rent beautiful properties</h2>\n                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum egestas nunc sed ultricies.</p>             \n                    </mat-card>\n                   \n                </div>\n\n                <div fxFlex=\"100\" fxFlex.gt-md=\"25\" fxFlex.gt-sm=\"50\" class=\"p-2\">\n                 \n                    <mat-card fxLayout=\"column\" fxLayoutAlign=\"start center\" class=\"h-100 w-100 text-center\">            \n                        <mat-icon class=\"mat-icon-xlg\" color=\"primary\">format_list_bulleted</mat-icon>\n                        <h2 class=\"capitalize fw-600 my-3\">With agent account you can list properties</h2>\n                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum egestas nunc sed ultricies.</p>             \n                    </mat-card>\n                   \n                </div>\n\n\n\n\n            </div>\n                \n        </div>\n    </div>   \n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/properties-carousel/properties-carousel.component.html":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/properties-carousel/properties-carousel.component.html ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div *ngIf=\"properties\" class=\"properties-carousel\">   \n    <div class=\"swiper-container h-100 carousel-outer\" [swiper]=\"config\"> \n        <div class=\"swiper-wrapper h-100\">      \n            <div *ngFor=\"let property of properties\" class=\"swiper-slide\">\n                <app-property-item [property]=\"property\" [viewType]=\"'grid'\"></app-property-item>                 \n            </div>\n        </div>                      \n        <button mat-mini-fab color=\"primary\" class=\"prop-prev swiper-button-prev swipe-arrow\"><mat-icon>keyboard_arrow_left</mat-icon></button>\n        <button mat-mini-fab color=\"primary\" class=\"prop-next swiper-button-next swipe-arrow\"><mat-icon>keyboard_arrow_right</mat-icon></button> \n    </div>\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/properties-search-results-filters/properties-search-results-filters.component.html":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/properties-search-results-filters/properties-search-results-filters.component.html ***!
  \*************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<mat-chip-list>\n    <mat-chip *ngIf=\"searchFields?.propertyType\">\n        {{searchFields?.propertyType.name}}        \n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('propertyType')\">cancel</mat-icon>\n    </mat-chip> \n    <mat-chip *ngIf=\"searchFields?.propertyStatus && searchFields?.propertyStatus.length > 0\">\n        <span *ngFor=\"let type of searchFields?.propertyStatus; let last = last;\" class=\"mr-1\">{{type.name}}<span *ngIf=\"!last\">,</span></span>\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('propertyStatus')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.price.from\">\n        Price > {{searchFields?.price.from}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('price.from')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.price.to\">\n        Price < {{searchFields?.price.to}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('price.to')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.city\">\n        {{searchFields?.city.name}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('city')\">cancel</mat-icon>\n    </mat-chip> \n    <mat-chip *ngIf=\"searchFields?.zipCode\">\n        {{searchFields?.zipCode}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('zipCode')\">cancel</mat-icon>\n    </mat-chip>    \n    <mat-chip *ngIf=\"searchFields?.neighborhood && searchFields?.neighborhood.length > 0\">\n        <span *ngFor=\"let item of searchFields?.neighborhood; let last = last;\" class=\"mr-1\">{{item.name}}<span *ngIf=\"!last\">,</span></span>\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('neighborhood')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.street && searchFields?.street.length > 0\">\n        <span *ngFor=\"let item of searchFields?.street; let last = last;\" class=\"mr-1\">{{item.name}}<span *ngIf=\"!last\">,</span></span>\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('street')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.bedrooms.from\">\n        Bedrooms > {{searchFields?.bedrooms.from}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('bedrooms.from')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.bedrooms.to\">\n        Bedrooms < {{searchFields?.bedrooms.to}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('bedrooms.to')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.bathrooms.from\">\n        Bathrooms > {{searchFields?.bathrooms.from}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('bathrooms.from')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.bathrooms.to\">\n        Bathrooms < {{searchFields?.bathrooms.to}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('bathrooms.to')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.floors.from\">\n        Floors > {{searchFields?.floors.from}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('floors.from')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.floors.to\">\n        Floors < {{searchFields?.floors.to}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('floors.to')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.area.from\">\n        Area > {{searchFields?.area.from}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('area.from')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.area.to\">\n        Area < {{searchFields?.area.to}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('area.to')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.yearBuilt.from\">\n        Year Built > {{searchFields?.yearBuilt.from}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('yearBuilt.from')\">cancel</mat-icon>\n    </mat-chip>\n    <mat-chip *ngIf=\"searchFields?.yearBuilt.to\">\n        Year Built < {{searchFields?.yearBuilt.to}}\n        <mat-icon color=\"warn\" matChipRemove (click)=\"remove('yearBuilt.to')\">cancel</mat-icon>\n    </mat-chip>\n\n    <span *ngIf=\"searchFields?.features\"> \n        <span *ngFor=\"let feature of searchFields?.features; index as i\">\n            <mat-chip *ngIf=\"feature.selected\">\n                {{feature.name}} \n                <mat-icon color=\"warn\" matChipRemove (click)=\"remove('features,'+i)\">cancel</mat-icon>\n            </mat-chip>\n        </span>  \n    </span>\n\n</mat-chip-list>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/properties-search/properties-search.component.html":
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/properties-search/properties-search.component.html ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<form [formGroup]=\"form\" class=\"search-wrapper\" [ngClass]=\"'variant-'+variant\">\n\n    <div [fxLayout]=\"(vertical) ? 'column' : 'row wrap'\">\n\n        <div fxFlex=\"100\" fxFlex.gt-sm=\"33.3\" fxFlex.sm=\"50\" class=\"p-2\">                         \n            <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                <mat-label>Neighborhood</mat-label>\n                <mat-select placeholder=\"Select Neighborhood...\" formControlName=\"neighborhood\" multiple (selectionChange)=\"onSelectNeighborhood()\"\n                    [compareWith]=\"comparer\">\n                    <mat-option *ngFor=\"let neighborhood of neighborhoods\" [value]=\"neighborhood\">\n                        {{neighborhood.name}}\n                    </mat-option>\n                </mat-select> \n            </mat-form-field>\n        </div>   \n\n        <div fxFlex=\"100\" fxFlex.gt-sm=\"33.3\" fxFlex.sm=\"50\" class=\"p-2\" formGroupName=\"price\">\n\n            <div fxLayout=\"row wrap\" fxLayoutAlign=\"space-between center\">\n                <div fxFlex=\"45\">\n                    <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                        <mat-label>{{(variant == 1) ? 'Price' : 'Price From'}}</mat-label>\n                        <input matInput autocomplete=\"off\" placeholder=\"From\" formControlName=\"from\" type=\"text\" onlyNumber>                  \n                    </mat-form-field>\n                </div>\n                <div fxFlex=\"10\" class=\"text-center\" [class.pt-2]=\"variant == 2\">\n                    <mat-icon class=\"text-muted\">remove</mat-icon>\n                </div>\n                <div fxFlex=\"45\">\n                    <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                        <mat-label>{{(variant == 1) ? '' : 'Price To'}}</mat-label>\n                        <input matInput autocomplete=\"off\" placeholder=\"To\" formControlName=\"to\" type=\"text\" onlyNumber>                  \n                    </mat-form-field>\n                </div>\n            </div>\n        </div>\n    \n        <div fxFlex=\"100\" fxFlex.gt-sm=\"33.3\" fxFlex.sm=\"50\" class=\"p-2\" formGroupName=\"bedrooms\">\n\n            <div fxLayout=\"row wrap\" fxLayoutAlign=\"space-between center\">\n                <div fxFlex=\"45\">\n                    <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                        <mat-label>{{(variant == 1) ? 'Bedrooms' : 'Bedrooms From'}}</mat-label>\n                        <mat-select placeholder=\"From\" formControlName=\"from\">\n                            <mat-option *ngFor=\"let number of [1,2,3,4,5,6,7,8,9,10]\" [value]=\"number\">\n                                {{number}}\n                            </mat-option>\n                        </mat-select>\n                    </mat-form-field>\n                </div>\n                <div fxFlex=\"10\" class=\"text-center\" [class.pt-2]=\"variant == 2\">\n                    <mat-icon class=\"text-muted\">remove</mat-icon>\n                </div>\n                <div fxFlex=\"45\">\n                    <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                        <mat-label>{{(variant == 1) ? '' : 'Bedrooms To'}}</mat-label>\n                        <mat-select placeholder=\"To\" formControlName=\"to\">\n                            <mat-option *ngFor=\"let number of [1,2,3,4,5,6,7,8,9,10]\" [value]=\"number\">\n                                {{number}}\n                            </mat-option>\n                        </mat-select>\n                    </mat-form-field>\n                </div>\n            </div> \n\n        </div>\n\n        \n        <div *ngIf=\"showMore\" [fxLayout]=\"(vertical) ? 'column' : 'row wrap'\" class=\"w-100\"> \n\n            <div fxFlex=\"100\" fxFlex.gt-sm=\"33.3\" fxFlex.sm=\"50\" class=\"p-2\">\n                <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                    <mat-label>Property Type</mat-label> \n                    <mat-select placeholder=\"Select Property Type\" formControlName=\"propertyType\">\n                        <mat-option *ngFor=\"let propertyType of propertyTypes\" [value]=\"propertyType\">\n                            {{propertyType.name}}\n                        </mat-option>\n                    </mat-select>\n                </mat-form-field>\n            </div>\n\n            <div fxFlex=\"100\" fxFlex.gt-sm=\"33.3\" fxFlex.sm=\"50\" class=\"p-2\">\n                <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                    <mat-label>Property Status</mat-label>\n                    <mat-select placeholder=\"Select Property Status\" formControlName=\"propertyStatus\" multiple>\n                        <mat-option *ngFor=\"let propertyStatus of propertyStatuses\" [value]=\"propertyStatus\">\n                            {{propertyStatus.name}}\n                        </mat-option>\n                    </mat-select>\n                </mat-form-field>\n            </div>\n\n            <div fxFlex=\"100\" fxFlex.gt-sm=\"33.3\" fxFlex.sm=\"50\" class=\"p-2\">                         \n                <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                    <mat-label>City</mat-label>\n                    <mat-select placeholder=\"Select City...\" formControlName=\"city\" (selectionChange)=\"onSelectCity()\">\n                        <mat-option *ngFor=\"let city of cities\" [value]=\"city\">\n                            {{city.name}}\n                        </mat-option>\n                    </mat-select> \n                </mat-form-field>\n            </div>\n\n            <div fxFlex=\"100\" fxFlex.gt-sm=\"33.3\" fxFlex.sm=\"50\" class=\"p-2\">\n                <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                    <mat-label>Zip Code</mat-label>\n                    <input matInput placeholder=\"exp. 98104\" autocomplete=\"off\" formControlName=\"zipCode\">                  \n                </mat-form-field>\n            </div>\n\n            <div fxFlex=\"100\" fxFlex.gt-sm=\"33.3\" fxFlex.sm=\"50\" class=\"p-2\">                         \n                <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                    <mat-label>Street</mat-label>\n                    <mat-select placeholder=\"Select Street...\" formControlName=\"street\" multiple>\n                        <mat-option *ngFor=\"let street of streets | filterStreets : { neighborhoods:form.get('neighborhood').value, cityId:form.get('city').value?.id } \" [value]=\"street\">\n                            {{street.name}}\n                        </mat-option>\n                    </mat-select> \n                </mat-form-field>\n            </div>\n    \n            <div fxFlex=\"100\" fxFlex.gt-sm=\"33.3\" fxFlex.sm=\"50\" class=\"p-2\" formGroupName=\"bathrooms\">\n    \n                <div fxLayout=\"row wrap\" fxLayoutAlign=\"space-between center\">\n                    <div fxFlex=\"45\">\n                        <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                            <mat-label>{{(variant == 1) ? 'Bathrooms' : 'Bathrooms From'}}</mat-label>\n                            <mat-select placeholder=\"From\" formControlName=\"from\">\n                                <mat-option *ngFor=\"let number of [1,2,3,4,5,6,7,8,9,10]\" [value]=\"number\">\n                                    {{number}}\n                                </mat-option>\n                            </mat-select>\n                        </mat-form-field>\n                    </div>\n                    <div fxFlex=\"10\" class=\"text-center\" [class.pt-2]=\"variant == 2\">\n                        <mat-icon class=\"text-muted\">remove</mat-icon>\n                    </div>\n                    <div fxFlex=\"45\">\n                        <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                            <mat-label>{{(variant == 1) ? '' : 'Bathrooms To'}}</mat-label>\n                            <mat-select placeholder=\"To\" formControlName=\"to\">\n                                <mat-option *ngFor=\"let number of [1,2,3,4,5,6,7,8,9,10]\" [value]=\"number\">\n                                    {{number}}\n                                </mat-option>\n                            </mat-select>\n                        </mat-form-field>\n                    </div>\n                </div> \n    \n            </div> \n\n            <div fxFlex=\"100\" fxFlex.gt-sm=\"33.3\" fxFlex.sm=\"50\" class=\"p-2\" formGroupName=\"floors\">\n    \n                <div fxLayout=\"row wrap\" fxLayoutAlign=\"space-between center\">\n                    <div fxFlex=\"45\">\n                        <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                            <mat-label>{{(variant == 1) ? 'Floors' : 'Floors From'}}</mat-label>\n                            <mat-select placeholder=\"From\" formControlName=\"from\">\n                                <mat-option *ngFor=\"let number of [1,2,3,4,5,6,7,8,9,10]\" [value]=\"number\">\n                                    {{number}}\n                                </mat-option>\n                            </mat-select>\n                        </mat-form-field>\n                    </div>\n                    <div fxFlex=\"10\" class=\"text-center\" [class.pt-2]=\"variant == 2\">\n                        <mat-icon class=\"text-muted\">remove</mat-icon>\n                    </div>\n                    <div fxFlex=\"45\">\n                        <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                            <mat-label>{{(variant == 1) ? '' : 'Floors To'}}</mat-label>\n                            <mat-select placeholder=\"To\" formControlName=\"to\">\n                                <mat-option *ngFor=\"let number of [1,2,3,4,5,6,7,8,9,10]\" [value]=\"number\">\n                                    {{number}}\n                                </mat-option>\n                            </mat-select>\n                        </mat-form-field>\n                    </div>\n                </div> \n    \n            </div> \n\n            <div fxFlex=\"100\" fxFlex.gt-sm=\"33.3\" fxFlex.sm=\"50\" class=\"p-2\" formGroupName=\"area\">\n\n                <div fxLayout=\"row wrap\" fxLayoutAlign=\"space-between center\">\n                    <div fxFlex=\"45\">\n                        <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                            <mat-label>{{(variant == 1) ? 'Area' : 'Area From'}}</mat-label>\n                            <input matInput autocomplete=\"off\" placeholder=\"From\" formControlName=\"from\" type=\"text\" onlyNumber>                  \n                        </mat-form-field>\n                    </div>\n                    <div fxFlex=\"10\" class=\"text-center\" [class.pt-2]=\"variant == 2\">\n                        <mat-icon class=\"text-muted\">remove</mat-icon>\n                    </div>\n                    <div fxFlex=\"45\">\n                        <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                            <mat-label>{{(variant == 1) ? '' : 'Area To'}}</mat-label>\n                            <input matInput autocomplete=\"off\" placeholder=\"To\" formControlName=\"to\" type=\"text\" onlyNumber>                  \n                        </mat-form-field>\n                    </div>\n                </div> \n    \n            </div>\n\n            <div fxFlex=\"100\" fxFlex.gt-sm=\"33.3\" fxFlex.sm=\"50\" class=\"p-2\" formGroupName=\"yearBuilt\">\n\n                <div fxLayout=\"row wrap\" fxLayoutAlign=\"space-between center\">\n                    <div fxFlex=\"45\">\n                        <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                            <mat-label>{{(variant == 1) ? 'Year Built' : 'Fear Built From'}}</mat-label>\n                            <input matInput autocomplete=\"off\" placeholder=\"From\" formControlName=\"from\" type=\"text\" onlyNumber maxlength=\"4\">                  \n                        </mat-form-field>\n                    </div>\n                    <div fxFlex=\"10\" class=\"text-center\" [class.pt-2]=\"variant == 2\">\n                        <mat-icon class=\"text-muted\">remove</mat-icon>\n                    </div>\n                    <div fxFlex=\"45\">\n                        <mat-form-field [appearance]=\"getAppearance()\" [floatLabel]=\"getFloatLabel()\">\n                            <mat-label>{{(variant == 1) ? '' : 'Year Built To'}}</mat-label>\n                            <input matInput autocomplete=\"off\" placeholder=\"To\" formControlName=\"to\" type=\"text\" onlyNumber maxlength=\"4\">                  \n                        </mat-form-field>\n                    </div>\n                </div> \n    \n            </div>\n\n            <div fxFlex=\"100\" class=\"mb-2\"> \n                <p class=\"uppercase m-2 fw-500\">Features</p> \n                <div formArrayName=\"features\" [fxLayout]=\"(vertical) ? 'column' : 'row wrap'\">\n                    <div [formGroupName]=\"i\" *ngFor=\"let control of form['controls'].features['controls']; index as i\" class=\"p-2\">\n                        <mat-checkbox formControlName=\"selected\">{{features[i].name}}</mat-checkbox>                         \n                    </div>\n                </div>\n            </div>\n\n        </div>\n\n\n    </div>\n  \n\n    <div fxLayout=\"row\" fxLayoutAlign=\"center center\" class=\"p-2\">       \n      <button mat-raised-button color=\"warn\" class=\"uppercase mx-1\" (click)=\"reset()\">Clear</button>\n      <button *ngIf=\"!vertical\" mat-raised-button color=\"primary\" class=\"uppercase mx-1\" (click)=\"showMoreClicked()\">{{(showMore) ? 'Hide' : 'Advanced'}}</button>      \n      <button *ngIf=\"searchOnBtnClick\" mat-raised-button color=\"primary\" class=\"search-btn mx-1\" (click)=\"search()\"><mat-icon>search</mat-icon> Search</button>\n    </div>\n    \n\n</form>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/properties-toolbar/properties-toolbar.component.html":
/*!*******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/properties-toolbar/properties-toolbar.component.html ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<mat-card fxLayout=\"row\" fxLayout.xs=\"column\" fxLayoutAlign=\"space-between center\" class=\"w-100 p-2 filter-row mat-elevation-z1 text-muted\">\n    <button *ngIf=\"showSidenavToggle\" mat-icon-button (click)=\"sidenavToggle()\">\n        <mat-icon>more_vert</mat-icon>\n    </button>\n    <div>\n        <a mat-button [matMenuTriggerFor]=\"sortMenu\" #sortMenuTrigger=\"matMenuTrigger\">\n            {{sort}}<mat-icon class=\"mat-icon-sm caret\">arrow_drop_down</mat-icon>\n        </a>\n        <mat-menu #sortMenu=\"matMenu\" xPosition=\"before\" overlapTrigger=\"true\">\n            <span (mouseleave)=\"sortMenuTrigger.closeMenu()\">\n                <button mat-menu-item *ngFor=\"let sortItem of sortings\" (click)=\"changeSorting(sortItem)\">\n                    <span>{{sortItem}}</span>\n                </button>\n            </span>\n        </mat-menu>\n    </div>\n    <div fxShow=\"false\" fxShow.gt-xs>\n        <!-- <span *ngIf=\"isHomePage\"> -->\n            <a mat-button [matMenuTriggerFor]=\"countsMenu\" #countsMenuTrigger=\"matMenuTrigger\">\n                Show {{count}}<mat-icon class=\"mat-icon-sm caret\">arrow_drop_down</mat-icon>\n            </a>\n            <mat-menu #countsMenu=\"matMenu\" xPosition=\"before\" overlapTrigger=\"true\">\n                <span (mouseleave)=\"countsMenuTrigger.closeMenu()\">\n                    <button mat-menu-item *ngFor=\"let countItem of counts\" (click)=\"changeCount(countItem)\">\n                        <span>{{countItem}}</span>\n                    </button>\n                </span>\n            </mat-menu>\n        <!-- </span>        -->\n        <button mat-icon-button [color]=\"viewType === 'list' && viewCol === 100 ? 'primary' : 'secondary'\" (click)=\"changeViewType('list', 100)\">\n            <mat-icon>view_list</mat-icon>\n        </button>\n        <button mat-icon-button [color]=\"viewType === 'grid' && viewCol === 50 ? 'primary' : 'secondary'\" (click)=\"changeViewType('grid', 50)\">\n            <svg class=\"mat-icon mat-icon-sm\" viewBox=\"0 0 25 25\">\n                <path d=\"M3,11H11V3H3M3,21H11V13H3M13,21H21V13H13M13,3V11H21V3\" />\n            </svg>\n        </button>\n        <button *ngIf=\"!isHomePage\" [color]=\"(viewType === 'grid' && viewCol === 33.3) || (viewType === 'grid' && viewCol === 25) ? 'primary' : 'secondary'\" mat-icon-button fxShow=\"false\" fxShow.gt-md (click)=\"changeViewType('grid', 33.3)\">\n            <mat-icon>view_module</mat-icon>\n        </button>\n        <button *ngIf=\"isHomePage\" [color]=\"viewType === 'grid' && viewCol === 33.3 ? 'primary' : 'secondary'\" mat-icon-button fxShow=\"false\" fxShow.gt-sm (click)=\"changeViewType('grid', 33.3)\">\n            <mat-icon>view_module</mat-icon>\n        </button>\n        <button *ngIf=\"isHomePage\" [color]=\"viewType === 'grid' && viewCol === 25 ? 'primary' : 'secondary'\" fxShow=\"false\" fxShow.gt-md mat-icon-button (click)=\"changeViewType('grid', 25)\">\n            <mat-icon>view_comfy</mat-icon>\n        </button>\n        \n\n        \n    </div>\n</mat-card>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/property-item/property-item.component.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/property-item/property-item.component.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<mat-card class=\"property-item p-0\" [ngClass]=\"[viewType + '-item', 'column-'+column]\" [class.full-width-page]=\"fullWidthPage\" fxLayout=\"row wrap\">  \n  \n    <div fxFlex=\"100\" fxShrink=\"3\" [fxFlex.gt-sm]=\"(viewType=='list') ? 40 : 100\" [fxFlex.sm]=\"(viewType=='list') ? 50 : 100\" class=\"thumbnail-section\">\n\n        <div fxLayout=\"row wrap\" class=\"property-status\">\n            <span *ngFor=\"let status of property.propertyStatus\" [style.background-color]=\"getStatusBgColor(status)\">{{status}}</span>\n        </div>\n       \n        <div *ngIf=\"property.gallery.length == 1\" class=\"mat-card-image w-100 m-0\">\n            <img [src]=\"property.gallery[0].medium\" (click)=\"openImage(0)\">\n        </div>\n        <div *ngIf=\"property.gallery.length > 1\" class=\"mat-card-image w-100 m-0\">\n            <div class=\"swiper-container\" [swiper]=\"config\">\n                <div class=\"swiper-wrapper\"> \n                    <div *ngFor=\"let image of property.gallery\" class=\"swiper-slide\">\n                        <img [attr.data-src]=\"image.medium\" class=\"swiper-lazy\" (click)=\"openImage(i)\">\n                        <div class=\"swiper-lazy-preloader\"></div>\n                    </div> \n                </div>  \n                <div class=\"swiper-pagination white\"></div>  \n                <button mat-icon-button class=\"swiper-button-prev swipe-arrow\"><mat-icon class=\"mat-icon-lg\">keyboard_arrow_left</mat-icon></button>\n                <button mat-icon-button class=\"swiper-button-next swipe-arrow\"><mat-icon class=\"mat-icon-lg\">keyboard_arrow_right</mat-icon></button>\n            </div>\n        </div>\n\n        <div class=\"control-icons\">\n\t\t\n\t\t\t\n\t\t\n            <button mat-button [disabled]=\"onFavorites()\" (click)=\"addToFavorites()\" matTooltip=\"Add To Favorite\">\n                <mat-icon class=\"mat-icon-sm\">favorite_border</mat-icon>\n            </button>\n            <button mat-button [disabled]=\"onCompare()\" (click)=\"addToCompare()\" matTooltip=\"Add To Compare\">\n                <mat-icon class=\"mat-icon-sm\">compare_arrows</mat-icon>\n            </button>  \n        </div> \n\n    </div>\n    <div fxFlex=\"100\" [fxFlex.gt-sm]=\"(viewType=='list') ? 60 : 100\" [fxFlex.sm]=\"(viewType=='list') ? 50 : 100\" class=\"p-3\">\n\n        <div fxLayout=\"column\" fxLayoutAlign=\"start stretch\" class=\"h-100\">\n            <mat-card-content class=\"mb-0\">\n              \n                <h1 class=\"title\"><a [routerLink]=\"['/properties', property.id]\">{{ (property | lTrans:\"name\":settings.locale) || property?.title}}</a></h1>\n\n                <p fxLayout=\"row\" class=\"address\">\n                    <mat-icon class=\"text-muted\">location_on</mat-icon>\n                    <span>{{property?.neighbourhood?.name || property?.city}}</span>\n                </p>\n\n                <div fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n                    <div>\n                        <h3 *ngIf=\"settings.currency == 'USD'\" class=\"primary-color price\">\n                            <span *ngIf=\"property.priceDollar.sale\">{{property.priceDollar.sale | currency : 'USD' : 'symbol' : '1.0'}}</span>\n                            <span *ngIf=\"property.priceDollar.rent\">{{property.priceDollar.rent | currency : 'USD' : 'symbol' : '1.0'}} /month</span>\n                        </h3>\n                        <h3 *ngIf=\"settings.currency == 'EUR'\" class=\"primary-color price\">\n                            <span *ngIf=\"property.priceEuro.sale\">{{ property?.price_from ? 'From' : '' }}&nbsp;{{property.priceEuro.sale | currency : 'EUR' : 'symbol' : '1.0'}}</span>\n                            <span *ngIf=\"property.priceEuro.rent\">{{property.priceEuro.rent | currency : 'EUR' : 'symbol' : '1.0'}} /month</span>\n                        </h3>\n                        <h3 *ngIf=\"property?.price_on_request\" class=\"primary-color price\">\n                            <span>{{ property?.price_on_request ? 'Price on request' : '' }}</span>\n                        </h3>\n                    </div>\n                    <app-rating [ratingsCount]=\"property.ratingsCount\" [ratingsValue]=\"property.ratingsValue\"></app-rating>\n                </div>\n\n                <div *ngIf=\"viewType=='list' && fullWidthPage\" fxShow=\"false\" fxShow.gt-sm class=\"mt-3\"> \n                    <p>{{property.desc}}</p>\n                </div>\n\n                <div class=\"features mt-3\">                    \n                    <p><span>Property size</span><span>{{property.area.value}} {{property.area.value ? property.area.unit : null}}</span></p>\n                    <p><span>Bedrooms</span><span>{{property?.bedrooms_type ? property?.bedrooms_type + ' ': ''}}{{property.bedrooms}}</span></p>\n                    <p><span>Bathrooms</span><span>{{property?.bathrooms_type ? property?.bathrooms_type + ' ': ''}}{{property.bathrooms}}</span></p>\n                    <p><span>Floors</span><span>{{property.floors}}</span></p>\n                </div> \n\n            </mat-card-content>\n            <div class=\"sticky-footer-helper\" fxFlex=\"grow\"></div>\n            <mat-card-actions class=\"m-0 p-0\" fxLayoutAlign=\"space-between center\"> \n                <p fxLayout=\"row\" class=\"date mb-0\">\n                    <mat-icon class=\"text-muted\">date_range</mat-icon>\n                    <span class=\"mx-2\">{{property.published | date:\"dd MMMM, yyyy\" }}</span>\n                </p>\n                <div>\n                    <a [routerLink]=\"['/properties', property.id]\" mat-stroked-button color=\"primary\" class=\"uppercase\">Details</a>\n                </div> \n            </mat-card-actions> \n        </div>        \n        \n    </div> \n\n</mat-card>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/rating/rating.component.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/rating/rating.component.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div fxLayout=\"row\" fxLayoutAlign=\"start center\" class=\"ratings\" [matTooltip]=\"ratingsCount + ' ratings'\">        \n  <mat-icon *ngFor=\"let star of stars;\" class=\"mat-icon-sm\">{{star}}</mat-icon>\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/testimonials/testimonials.component.html":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/testimonials/testimonials.component.html ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"section testimonials\">\n    <div class=\"px-3\">\n        <div class=\"theme-container\">\n            <h1 class=\"section-title\">What people are saying</h1>\n\n            <div class=\"testimonials-carousel\"> \n                <div class=\"swiper-container h-100\" [swiper]=\"config\"> \n                    <div class=\"swiper-wrapper h-100\">      \n                        <div *ngFor=\"let testimonial of testimonials\" class=\"swiper-slide\">\n                            <div class=\"content text-center\">\n                                <img [attr.data-src]=\"testimonial.image\" class=\"swiper-lazy\">\n                                <div class=\"quote open text-left primary-color\">“</div>\n                                <p class=\"text\">{{testimonial.text}}</p>\n                                <div class=\"quote close text-right primary-color\">”</div> \n                                <h3 class=\"author\">{{testimonial.author}}</h3>\n                                <p>{{testimonial.position}}</p> \n                                <div class=\"swiper-lazy-preloader\"></div>\n                            </div>\n                        </div>\n                    </div> \n                    <div class=\"swiper-pagination\"></div> \n                </div>\n            </div>\n                \n        </div>\n    </div>   \n</div>\n\n ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/contacts/contacts.component.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/contacts/contacts.component.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<span fxLayoutAlign=\"center center\" class=\"item\">\n  <mat-icon [color]=\"iconColor\" [ngClass]=\"'mat-icon-' + iconSize\">call</mat-icon>\n  <span class=\"px-1\">(+100) 123 456 7890</span>\n</span>\n<span *ngIf=\"dividers\" class=\"v-divider\"></span>\n<span fxLayoutAlign=\"center center\" class=\"item\">\n  <mat-icon [color]=\"iconColor\" [ngClass]=\"'mat-icon-' + iconSize\">location_on</mat-icon>\n  <span class=\"px-1\">2903 Avenue Z, Brooklyn, NY, USA</span>\n</span>\n<span *ngIf=\"dividers\" class=\"v-divider\"></span>\n<span fxLayoutAlign=\"center center\" class=\"item\">\n  <mat-icon [color]=\"iconColor\" [ngClass]=\"'mat-icon-' + iconSize\">mail</mat-icon>\n  <span class=\"px-1\">info@homevoxx.com</span>\n</span>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/currency/currency.component.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/currency/currency.component.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<a mat-button [matMenuTriggerFor]=\"currencyMenu\" #currencyMenuTrigger=\"matMenuTrigger\">\n    <span>{{currency}}</span><mat-icon class=\"mat-icon-sm caret\">arrow_drop_down</mat-icon>\n</a>\n<mat-menu #currencyMenu=\"matMenu\" [overlapTrigger]=\"false\" xPosition=\"before\" class=\"app-menu-panel\">\n    <span (mouseleave)=\"currencyMenuTrigger.closeMenu()\">\n        <button mat-menu-item *ngFor=\"let cur of currencies\" (click)=\"changeCurrency(cur)\">\n            <span>{{cur}}</span>\n        </button>\n    </span>\n</mat-menu>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/footer/footer.component.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/footer/footer.component.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<footer>       \n\n    <div class=\"px-3\">\n        <div class=\"theme-container\">\n\n            <!-- <div fxLayout=\"column\" fxLayout.gt-sm=\"row wrap\" fxLayoutAlign=\"center center\" class=\"content border-lighter py-5\">\n                <div fxFlex=\"100\" fxFlex.gt-sm=\"40\" fxLayout=\"column\" fxLayoutAlign=\"center center\"> \n                    <h2 class=\"uppercase\">Subscribe our Newsletter</h2>\n                    <p class=\"desc mb-1\">Stay up to date with our latest news and properties</p>\n                </div>\n                <form [formGroup]=\"subscribeForm\" (ngSubmit)=\"onSubscribeFormSubmit(subscribeForm.value)\" class=\"custom-form\" fxLayout=\"row\" fxFlex=\"100\" fxFlex.gt-sm=\"42.4\" ngClass.sm=\"mt-2\" ngClass.xs=\"mt-2\">\n                    <mat-form-field appearance=\"outline\" floatLabel=\"always\" class=\"subscribe-input\" fxFlex>\n                        <input matInput autocomplete=\"off\" formControlName=\"email\" placeholder=\"Your email address...\">                      \n                    </mat-form-field>\n                    <button mat-flat-button type=\"submit\" class=\"subscribe-btn\" color=\"primary\">Subscribe</button>\n                </form>\n            </div> -->\n\n            <div class=\"py-5 content border-lighter\">\n\n                <div fxLayout=\"row wrap\" fxLayoutAlign=\"space-between\"> \n                    <div fxFlex=\"100\" fxFlex.gt-sm=\"30\" fxFlex.sm=\"45\"> \n                        <a class=\"logo\" routerLink=\"/\"><app-logo></app-logo></a>\n                        <p class=\"mt-5 mb-3 desc\">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nostrum perspiciatis cupiditate numquam odio explicabo accusantium deserunt incidunt.</p>\n                        <p fxLayout=\"row\" fxLayoutAlign=\"start center\" class=\"mt-2\">\n                            <mat-icon color=\"primary\">location_on</mat-icon>\n                            <span class=\"mx-2\">2903 Avenue Z, Brooklyn, NY</span>\n                        </p>\n                        <p fxLayout=\"row\" fxLayoutAlign=\"start center\" class=\"mt-1\">\n                            <mat-icon color=\"primary\">call</mat-icon>\n                            <span class=\"mx-2\">(+100) 123 456 7890</span>\n                        </p>\n                        <p fxLayout=\"row\" fxLayoutAlign=\"start center\" class=\"mt-1\">\n                            <mat-icon color=\"primary\">mail_outline</mat-icon>\n                            <span class=\"mx-2\">contact@homevoxx.com</span>\n                        </p>\n                        <p fxLayout=\"row\" fxLayoutAlign=\"start center\" class=\"mt-1\">\n                            <mat-icon color=\"primary\">schedule</mat-icon>\n                            <span class=\"mx-2\">Mon - Sun / 9:00AM - 8:00PM</span>\n                        </p>\n                        <app-social-icons [iconSize]=\"'lg'\" fxLayout=\"row\" fxLayoutAlign=\"start center\" class=\"desc\"></app-social-icons>                    \n                    </div>\n\n                    <div fxFlex=\"100\" fxFlex.gt-sm=\"30\" fxFlex.sm=\"45\" ngClass.xs=\"pt-5\"> \n                        <h2 class=\"uppercase\">Feedback</h2>\n                        <p class=\"desc\">We want your feedback about everything</p>\n                        <form [formGroup]=\"feedbackForm\" (ngSubmit)=\"onFeedbackFormSubmit(feedbackForm.value)\" class=\"custom-form pt-2\">                            \n                            <mat-form-field appearance=\"outline\" class=\"w-100\">\n                                <mat-label>E-mail</mat-label> \n                                <input matInput autocomplete=\"off\" formControlName=\"email\">\n                                <mat-error *ngIf=\"feedbackForm.controls.email.errors?.required\">Email is required</mat-error>\n                                <mat-error *ngIf=\"feedbackForm.controls.email.hasError('invalidEmail')\">Invalid email address</mat-error>\n                            </mat-form-field>\n                            <mat-form-field appearance=\"outline\" class=\"w-100\">\n                                <mat-label>Message for us</mat-label> \n                                <textarea matInput formControlName=\"message\" rows=\"6\"></textarea> \n                                <mat-error *ngIf=\"feedbackForm.controls.message.errors?.required\">Message is required</mat-error>\n                            </mat-form-field>\n                            <div class=\"w-100 text-center\">\n                                <button mat-flat-button color=\"primary\" class=\"uppercase\" type=\"submit\">Submit</button> \n                            </div> \n                        </form> \n                    </div>\n \n                    <div fxFlex=\"100\" fxFlex.gt-sm=\"30\" ngClass.lt-md=\"pt-5\"> \n                        <h2 class=\"uppercase mb-3\">Our location</h2>\n                        <agm-map [latitude]=\"lat\" [longitude]=\"lng\" [zoom]=\"zoom\" [mapTypeControl]=\"false\" [styles]=\"mapStyles\">\n                            <agm-marker [latitude]=\"lat\" [longitude]=\"lng\" [markerDraggable]=\"false\"></agm-marker>\n                        </agm-map>\n                    </div>\n                </div> \n              \n            </div>\n            \n            <div fxLayout=\"row\" fxLayout.xs=\"column\" fxLayoutAlign=\"space-between center\" class=\"copyright\">\n                <p ngClass.xs=\"mt-1\">Copyright © 2020 All Rights Reserved</p>\n            </div>\n\n        </div>\n    </div>                  \n                \n</footer>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/lang/lang.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/lang/lang.component.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<a mat-button [matMenuTriggerFor]=\"langMenu\" #langMenuTrigger=\"matMenuTrigger\">\n    <img [src]=\"flag.image\" width=\"18\">\n    <span fxShow=\"false\" fxShow.gt-md class=\"uppercase flag-name\">{{flag.name}}</span>\n    <mat-icon class=\"mat-icon-sm caret\">arrow_drop_down</mat-icon>\n</a>\n<mat-menu #langMenu=\"matMenu\" [overlapTrigger]=\"false\" xPosition=\"before\" class=\"app-menu-panel\">\n    <span (mouseleave)=\"langMenuTrigger.closeMenu()\">\n        <button mat-menu-item *ngFor=\"let flag of flags\" (click)=\"changeLang(flag)\">\n            <img [src]=\"flag.image\" width=\"18\" class=\"mat-elevation-z1\"><span class=\"flag-name\">{{flag.name}}</span>\n        </button>\n    </span>\n</mat-menu>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/menu/horizontal-menu/horizontal-menu.component.html":
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/menu/horizontal-menu/horizontal-menu.component.html ***!
  \****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ng-container *ngFor=\"let menuItem of menuItems\">\n\n  <a *ngIf=\"menuItem.routerLink && !menuItem.hasSubMenu\" mat-button [routerLink]=\"[menuItem.routerLink]\" \n    routerLinkActive=\"horizontal-active-link\" [routerLinkActiveOptions]=\"{exact:true}\">\n    <span>{{menuItem.title}}</span>\n  </a>\n\n  <a *ngIf=\"menuItem.href && !menuItem.hasSubMenu\" mat-button \n    [attr.href]=\"menuItem.href || ''\" [attr.target]=\"menuItem.target || ''\">\n    <span>{{menuItem.title}}</span>\n  </a>\n\n  <a *ngIf=\"menuItem.hasSubMenu && menuItem.parentId == 0\" mat-button [matMenuTriggerFor]=\"menu\"> \n    <span>{{menuItem.title}}</span><mat-icon class=\"caret\">arrow_drop_down</mat-icon> \n  </a>\n\n  <a *ngIf=\"menuItem.hasSubMenu && menuItem.parentId != 0\" mat-menu-item [matMenuTriggerFor]=\"menu\"> \n    <span>{{menuItem.title}}</span> \n  </a> \n\n  <mat-menu #menu=\"matMenu\" class=\"horizontal-sub-menu\">\n      <app-horizontal-menu [menuParentId]=\"menuItem.id\"></app-horizontal-menu>\n  </mat-menu>\n    \n</ng-container>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/menu/vertical-menu/vertical-menu.component.html":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/menu/vertical-menu/vertical-menu.component.html ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div *ngFor=\"let menu of menuItems\" class=\"menu-item\">\n  <a *ngIf=\"menu.routerLink && !menu.hasSubMenu\" mat-button\n      fxLayout=\"row\" fxLayoutAlign=\"start center\"\n      [routerLink]=\"[menu.routerLink]\" routerLinkActive=\"active-link\" [routerLinkActiveOptions]=\"{exact:true}\"        \n      (click)=\"onClick(menu.id)\" [id]=\"'menu-item-'+menu.id\">\n      <span class=\"menu-title\">{{menu.title}}</span>\n  </a>\n  <a *ngIf=\"menu.href && !menu.hasSubMenu\" mat-button \n      fxLayout=\"row\" fxLayoutAlign=\"start center\"\n      [attr.href]=\"menu.href || ''\" [attr.target]=\"menu.target || ''\"       \n      (click)=\"onClick(menu.id)\" [id]=\"'menu-item-'+menu.id\">\n      <span class=\"menu-title\">{{menu.title}}</span>\n  </a>\n  <a *ngIf=\"menu.hasSubMenu\" mat-button \n      fxLayout=\"row\" fxLayoutAlign=\"start center\"       \n      (click)=\"onClick(menu.id)\" [id]=\"'menu-item-'+menu.id\">\n      <span class=\"menu-title\">{{menu.title}}</span>\n      <mat-icon class=\"menu-expand-icon transition-2\">arrow_drop_down</mat-icon>\n  </a>\n  <div *ngIf=\"menu.hasSubMenu\" class=\"sub-menu\" [id]=\"'sub-menu-'+menu.id\">\n      <app-vertical-menu [menuParentId]=\"menu.id\"></app-vertical-menu>\n  </div>\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/social-icons/social-icons.component.html":
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/social-icons/social-icons.component.html ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<a href=\"https://www.facebook.com/\" target=\"blank\" class=\"social-icon\">\n  <svg class=\"mat-icon\" viewBox=\"0 0 24 24\" [ngClass]=\"['mat-icon-' + iconSize, 'mat-'+ iconColor]\">\n    <path d=\"M5,3H19A2,2 0 0,1 21,5V19A2,2 0 0,1 19,21H5A2,2 0 0,1 3,19V5A2,2 0 0,1 5,3M18,5H15.5A3.5,3.5 0 0,0 12,8.5V11H10V14H12V21H15V14H18V11H15V9A1,1 0 0,1 16,8H18V5Z\" />\n  </svg>\n</a>\n<a href=\"https://twitter.com/\" target=\"blank\" class=\"social-icon\">\n  <svg class=\"mat-icon\" viewBox=\"0 0 24 24\" [ngClass]=\"['mat-icon-' + iconSize, 'mat-'+ iconColor]\">\n      <path d=\"M5,3H19A2,2 0 0,1 21,5V19A2,2 0 0,1 19,21H5A2,2 0 0,1 3,19V5A2,2 0 0,1 5,3M17.71,9.33C18.19,8.93 18.75,8.45 19,7.92C18.59,8.13 18.1,8.26 17.56,8.33C18.06,7.97 18.47,7.5 18.68,6.86C18.16,7.14 17.63,7.38 16.97,7.5C15.42,5.63 11.71,7.15 12.37,9.95C9.76,9.79 8.17,8.61 6.85,7.16C6.1,8.38 6.75,10.23 7.64,10.74C7.18,10.71 6.83,10.57 6.5,10.41C6.54,11.95 7.39,12.69 8.58,13.09C8.22,13.16 7.82,13.18 7.44,13.12C7.81,14.19 8.58,14.86 9.9,15C9,15.76 7.34,16.29 6,16.08C7.15,16.81 8.46,17.39 10.28,17.31C14.69,17.11 17.64,13.95 17.71,9.33Z\" />\n  </svg> \n</a>\n<a href=\"https://www.linkedin.com/\" target=\"blank\" class=\"social-icon\"> \n  <svg class=\"mat-icon\" viewBox=\"0 0 24 24\" [ngClass]=\"['mat-icon-' + iconSize, 'mat-'+ iconColor]\">\n    <path d=\"M19,3A2,2 0 0,1 21,5V19A2,2 0 0,1 19,21H5A2,2 0 0,1 3,19V5A2,2 0 0,1 5,3H19M18.5,18.5V13.2A3.26,3.26 0 0,0 15.24,9.94C14.39,9.94 13.4,10.46 12.92,11.24V10.13H10.13V18.5H12.92V13.57C12.92,12.8 13.54,12.17 14.31,12.17A1.4,1.4 0 0,1 15.71,13.57V18.5H18.5M6.88,8.56A1.68,1.68 0 0,0 8.56,6.88C8.56,5.95 7.81,5.19 6.88,5.19A1.69,1.69 0 0,0 5.19,6.88C5.19,7.81 5.95,8.56 6.88,8.56M8.27,18.5V10.13H5.5V18.5H8.27Z\" />\n  </svg>\n</a>\n<a href=\"https://plus.google.com/\" target=\"blank\" class=\"social-icon\"> \n  <svg class=\"mat-icon\" viewBox=\"0 0 24 24\" [ngClass]=\"['mat-icon-' + iconSize, 'mat-'+ iconColor]\">\n    <path d=\"M5,3H19A2,2 0 0,1 21,5V19A2,2 0 0,1 19,21H5A2,2 0 0,1 3,19V5A2,2 0 0,1 5,3M19.5,12H18V10.5H17V12H15.5V13H17V14.5H18V13H19.5V12M9.65,11.36V12.9H12.22C12.09,13.54 11.45,14.83 9.65,14.83C8.11,14.83 6.89,13.54 6.89,12C6.89,10.46 8.11,9.17 9.65,9.17C10.55,9.17 11.13,9.56 11.45,9.88L12.67,8.72C11.9,7.95 10.87,7.5 9.65,7.5C7.14,7.5 5.15,9.5 5.15,12C5.15,14.5 7.14,16.5 9.65,16.5C12.22,16.5 13.96,14.7 13.96,12.13C13.96,11.81 13.96,11.61 13.89,11.36H9.65Z\" />\n  </svg>\n</a>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/toolbar1/toolbar1.component.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/toolbar1/toolbar1.component.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<mat-toolbar id=\"top-toolbar\" class=\"top-toolbar\">\n  <div class=\"theme-container\" fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n    <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n      <span fxHide=\"false\" fxHide.gt-sm>\n        <button mat-button (click)=\"sidenavToggle()\">\n          <mat-icon>menu</mat-icon>\n        </button> \n      </span>\n      <app-social-icons fxLayout=\"row\" fxLayoutAlign=\"start center\" fxShow=\"false\" fxShow.gt-md></app-social-icons>         \n    </div>\n    <div fxLayout=\"row\" fxLayoutAlign=\"end center\" class=\"\">\n      <app-currency></app-currency>\n      <app-lang></app-lang>\n      <app-user-menu></app-user-menu>\n    </div>    \n  </div>           \n</mat-toolbar>  \n<mat-toolbar id=\"main-toolbar\" class=\"mat-elevation-z2\"> \n  <div class=\"theme-container\" fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n    <a class=\"logo\" routerLink=\"/\" ><app-logo [isHeader]=true></app-logo> </a> \n    <div fxShow=\"false\" fxShow.gt-sm class=\"horizontal-menu\">            \n        <app-horizontal-menu [menuParentId]=\"0\"></app-horizontal-menu>\n    </div> \n    <div fxLayout=\"row\" fxLayoutAlign=\"start center\">\n      <a routerLink=\"/account/favorites\" mat-icon-button matTooltip=\"Favorites\" fxShow=\"false\" fxShow.gt-md>\n          <mat-icon [matBadge]=\"appService.Data.favorites.length\" \n                    [matBadgeHidden]=\"appService.Data.favorites.length == 0\" \n                    matBadgeSize=\"small\" \n                    matBadgeColor=\"warn\">favorite_border</mat-icon>\n      </a>\n      <a routerLink=\"/compare\" mat-icon-button matTooltip=\"Compare list\" fxShow=\"false\" fxShow.gt-md class=\"mr-3 ml-2\">\n          <mat-icon [matBadge]=\"appService.Data.compareList.length\" \n                    [matBadgeHidden]=\"appService.Data.compareList.length == 0\" \n                    matBadgeSize=\"small\" \n                    matBadgeColor=\"warn\">compare_arrows</mat-icon>\n      </a>  \n\t <app-back-button></app-back-button>\n\n\t  \n      <!-- <a routerLink=\"/submit-property\" mat-mini-fab color=\"primary\" fxHide=\"false\" fxHide.gt-xs><mat-icon>add</mat-icon></a> -->\n      <!-- <a routerLink=\"/submit-property\" mat-raised-button color=\"primary\" fxShow=\"false\" fxShow.gt-xs class=\"uppercase\">submit property</a> -->\n    </div>   \n  </div>     \n</mat-toolbar>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/toolbar2/toolbar2.component.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/toolbar2/toolbar2.component.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<mat-toolbar id=\"top-toolbar\" class=\"top-toolbar\">\n  <mat-toolbar-row  ngClass.xs=\"p-0\">\n    <div class=\"theme-container\" fxLayout=\"row\" fxLayoutAlign=\"center\" fxLayoutAlign.gt-sm=\"end center\" fxLayoutAlign.sm=\"space-between center\">\n      <app-social-icons [iconSize]=\"'lg'\" [iconColor]=\"'primary'\" fxLayout=\"row\" fxLayoutAlign=\"start center\" fxHide=\"false\" fxHide.gt-sm fxHide.xs></app-social-icons>\n      <div fxLayout=\"row\" fxLayoutAlign=\"start center\" fxShow=\"false\" fxShow.xs class=\"bg-primary right-section px-2\">\n        <app-social-icons fxLayout=\"row\" fxLayoutAlign=\"start center\"></app-social-icons>\n      </div>\n      <div fxLayout=\"row\" fxLayoutAlign=\"end center\" class=\"bg-primary right-section\" ngClass.xs=\"w-100\">\n          <app-currency></app-currency>\n          <app-lang></app-lang>\n          <app-user-menu></app-user-menu>\n      </div>    \n    </div>\n  </mat-toolbar-row>\n  <mat-toolbar-row ngClass.xs=\"py-3\">\n    <div class=\"theme-container\" fxLayout=\"row\" fxLayoutAlign=\"center\" fxLayoutAlign.gt-sm=\"space-between center\">\n      <a class=\"logo\" routerLink=\"/\" ><app-logo [isHeader]=true></app-logo></a> \n      <app-social-icons [iconSize]=\"'lg'\" [iconColor]=\"'primary'\" fxLayout=\"row\" fxLayoutAlign=\"end center\" fxShow=\"false\" fxShow.gt-sm></app-social-icons>\n    </div> \n  </mat-toolbar-row>              \n</mat-toolbar>\n<mat-toolbar id=\"main-toolbar\" class=\"mat-elevation-z2\"> \n  <div class=\"theme-container\" fxLayout=\"row\" fxLayoutAlign=\"space-between center\">    \n    <mat-icon class=\"mat-icon-xlg\" fxHide=\"false\" fxHide.gt-sm (click)=\"sidenavToggle()\">menu</mat-icon>\n    <div fxShow=\"false\" fxShow.gt-sm class=\"horizontal-menu\">            \n        <app-horizontal-menu [menuParentId]=\"0\"></app-horizontal-menu>\n    </div>     \n    <div>\n      <a routerLink=\"/account/favorites\" mat-icon-button matTooltip=\"Favorites\" fxShow=\"false\" fxShow.gt-md>\n        <mat-icon [matBadge]=\"appService.Data.favorites.length\" \n                  [matBadgeHidden]=\"appService.Data.favorites.length == 0\" \n                  matBadgeSize=\"small\" \n                  matBadgeColor=\"warn\">favorite_border</mat-icon>\n      </a>\n      <a routerLink=\"/compare\" mat-icon-button matTooltip=\"Compare list\" fxShow=\"false\" fxShow.gt-md class=\"mr-3 ml-2\">\n        <mat-icon [matBadge]=\"appService.Data.compareList.length\" \n                  [matBadgeHidden]=\"appService.Data.compareList.length == 0\" \n                  matBadgeSize=\"small\" \n                  matBadgeColor=\"warn\">compare_arrows</mat-icon>\n      </a>\n      <!-- <a routerLink=\"/submit-property\" mat-mini-fab color=\"accent\" fxHide=\"false\" fxHide.gt-xs><mat-icon>add</mat-icon></a> -->\n      <!-- <a routerLink=\"/submit-property\" mat-raised-button color=\"accent\" fxShow=\"false\" fxShow.gt-xs class=\"uppercase\">submit property</a> -->\n    </div>  \n  </div>     \n</mat-toolbar>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/user-menu/user-menu.component.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/user-menu/user-menu.component.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<a mat-button [matMenuTriggerFor]=\"userMenu\" #userMenuTrigger=\"matMenuTrigger\">\n    <mat-icon class=\"mat-icon-sm\">person</mat-icon>\n    <span fxShow=\"false\" fxShow.gt-sm class=\"mx-1 uppercase\">account</span> \n    <mat-icon class=\"mat-icon-sm caret\">arrow_drop_down</mat-icon>\n</a>\n<mat-menu #userMenu=\"matMenu\" [overlapTrigger]=\"false\" xPosition=\"before\" class=\"app-menu-panel user-menu\">\n    <span (mouseleave)=\"userMenuTrigger.closeMenu()\">\n        <div fxLayout=\"row\" fxLayoutAlign=\"start center\" class=\"user-info\" *ngIf=\"isLoggedIn$ | async\">\n            <img src=\"assets/images/others/user.jpg\" alt=\"user-image\" width=\"50\">\n            <p class=\"m-0\">{{ user?.name }} <br> <small><i>{{ user?.email }}</i></small></p>\n        </div>\n        <div class=\"divider\"></div>\n        <!-- <a mat-menu-item routerLink=\"/submit-property\"> \n            <mat-icon class=\"mat-icon-sm\">add_circle</mat-icon>\n            <span>Submit Property</span> \n        </a> -->\n        <a mat-menu-item routerLink=\"/account/my-properties\" *ngIf=\"isLoggedIn$ | async\"> \n            <mat-icon class=\"mat-icon-sm\">home</mat-icon>\n            <span>My Properties</span> \n        </a>\n        <a mat-menu-item routerLink=\"/account/favorites\" *ngIf=\"isLoggedIn$ | async\"> \n            <mat-icon class=\"mat-icon-sm\">favorite_border</mat-icon>\n            <span [matBadge]=\"appService.Data.favorites.length\" \n                  [matBadgeHidden]=\"appService.Data.favorites.length == 0\"\n                  matBadgeSize=\"small\" \n                  matBadgeColor=\"warn\" \n                  matBadgeOverlap=\"false\">Favorites</span> \n        </a>\n        <a mat-menu-item routerLink=\"/compare\"> \n            <mat-icon class=\"mat-icon-sm\">compare_arrows</mat-icon> \n            <span [matBadge]=\"appService.Data.compareList.length\" \n                  [matBadgeHidden]=\"appService.Data.compareList.length == 0\"\n                  matBadgeSize=\"small\" \n                  matBadgeColor=\"warn\" \n                  matBadgeOverlap=\"false\">Compare</span> \n        </a>\n        <!-- <a mat-menu-item routerLink=\"/\"> \n            <mat-icon class=\"mat-icon-sm\">search</mat-icon>\n            <span>Saved Searches</span> \n        </a> -->\n        <a mat-menu-item routerLink=\"/account/profile\" *ngIf=\"isLoggedIn$ | async\"> \n            <mat-icon class=\"mat-icon-sm\">edit</mat-icon>\n            <span>Edit Profile</span> \n        </a>\n        <a mat-menu-item routerLink=\"/lock-screen\"> \n            <mat-icon class=\"mat-icon-sm\">lock</mat-icon>\n            <span>Lock screen</span> \n        </a>\n        <a mat-menu-item routerLink=\"/faq\"> \n            <mat-icon class=\"mat-icon-sm\">help</mat-icon>\n            <span>Help</span> \n        </a>\n        <div class=\"divider\"></div>\n        <a mat-menu-item (click)=\"onLogout()\" *ngIf=\"isLoggedIn$ | async\"> \n            <mat-icon class=\"mat-icon-sm\">power_settings_new</mat-icon>\n            <span>Sign Out</span> \n        </a>\n        <a mat-menu-item routerLink=\"/login\" *ngIf=\"!(isLoggedIn$ | async)\"> \n            <mat-icon class=\"mat-icon-sm\">login</mat-icon>\n            <span>Login</span> \n        </a>\n        <a mat-menu-item routerLink=\"/register\" *ngIf=\"!(isLoggedIn$ | async)\"> \n            <mat-icon class=\"mat-icon-sm\">perm_identity</mat-icon>\n            <span>Register</span> \n        </a>\n    </span>\n</mat-menu>  ");

/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.settings */ "./src/app/app.settings.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./services/auth.service */ "./src/app/services/auth.service.ts");
/* harmony import */ var _services_user_helper_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./services/user-helper.service */ "./src/app/services/user-helper.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};






let AppComponent = class AppComponent {
    constructor(appSettings, authService, userHelperService, router, platformId) {
        this.appSettings = appSettings;
        this.authService = authService;
        this.userHelperService = userHelperService;
        this.router = router;
        this.platformId = platformId;
        this.settings = this.appSettings.settings;
    }
    ngOnInit() {
        if (this.userHelperService.id()) {
            return this.authService.loggedIn.next(true);
        }
        return this.authService.loggedIn.next(false);
    }
    ngAfterViewInit() {
        this.router.events.subscribe(event => {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationEnd"]) {
                setTimeout(() => {
                    if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
                        window.scrollTo(0, 0);
                    }
                });
            }
        });
    }
};
AppComponent.ctorParameters = () => [
    { type: _app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"] },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] },
    { type: _services_user_helper_service__WEBPACK_IMPORTED_MODULE_5__["UserHelperService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: Object, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["PLATFORM_ID"],] }] }
];
AppComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-root',
        template: __importDefault(__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"],
        _services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"],
        _services_user_helper_service__WEBPACK_IMPORTED_MODULE_5__["UserHelperService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        Object])
], AppComponent);



/***/ }),

/***/ "./src/app/app.models.ts":
/*!*******************************!*\
  !*** ./src/app/app.models.ts ***!
  \*******************************/
/*! exports provided: Meta, PropertiesResponse, PropertyResponse, Property, Area, Ground, Living, AdditionalFeature, Location, Price, Gallery, Plan, Video, Pagination, User, Neighbourhood */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Meta", function() { return Meta; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PropertiesResponse", function() { return PropertiesResponse; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PropertyResponse", function() { return PropertyResponse; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Property", function() { return Property; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Area", function() { return Area; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Ground", function() { return Ground; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Living", function() { return Living; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdditionalFeature", function() { return AdditionalFeature; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Location", function() { return Location; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Price", function() { return Price; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Gallery", function() { return Gallery; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Plan", function() { return Plan; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Video", function() { return Video; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Pagination", function() { return Pagination; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Neighbourhood", function() { return Neighbourhood; });
class Meta {
    constructor(current_page, from, last_page, path, per_page, to, total) {
        this.current_page = current_page;
        this.from = from;
        this.last_page = last_page;
        this.path = path;
        this.per_page = per_page;
        this.to = to;
        this.total = total;
    }
}
class PropertiesResponse {
    constructor(data, meta) {
        this.data = data;
        this.meta = meta;
    }
}
class PropertyResponse {
    constructor(data) {
        this.data = data;
    }
}
class Property {
    constructor(id, title, desc, propertyType, propertyStatus, city, zipCode, neighborhood, street, location, formattedAddress, features, lFeatures, featured, priceDollar, priceEuro, bedrooms, bathrooms, floors, garages, area, ground, living, yearBuilt, ratingsCount, ratingsValue, additionalFeatures, gallery, plans, videos, published, lastUpdate, reference, direction, region, klass, views, description, url, name, neighbourhood_id, neighbourhood, terrace, price_text, price_on_request, price_type, area_text, ground_text, living_type, living_text, bedrooms_type, bedrooms_text, bathrooms_type, bathrooms_text, frequency, price_from, price_per_meter, factor, rentAverage) {
        this.id = id;
        this.title = title;
        this.desc = desc;
        this.propertyType = propertyType;
        this.propertyStatus = propertyStatus;
        this.city = city;
        this.zipCode = zipCode;
        this.neighborhood = neighborhood;
        this.street = street;
        this.location = location;
        this.formattedAddress = formattedAddress;
        this.features = features;
        this.lFeatures = lFeatures;
        this.featured = featured;
        this.priceDollar = priceDollar;
        this.priceEuro = priceEuro;
        this.bedrooms = bedrooms;
        this.bathrooms = bathrooms;
        this.floors = floors;
        this.garages = garages;
        this.area = area;
        this.ground = ground;
        this.living = living;
        this.yearBuilt = yearBuilt;
        this.ratingsCount = ratingsCount;
        this.ratingsValue = ratingsValue;
        this.additionalFeatures = additionalFeatures;
        this.gallery = gallery;
        this.plans = plans;
        this.videos = videos;
        this.published = published;
        this.lastUpdate = lastUpdate;
        this.reference = reference;
        this.direction = direction;
        this.region = region;
        this.klass = klass;
        this.views = views;
        this.description = description;
        this.url = url;
        this.name = name;
        this.neighbourhood_id = neighbourhood_id;
        this.neighbourhood = neighbourhood;
        this.terrace = terrace;
        this.price_text = price_text;
        this.price_on_request = price_on_request;
        this.price_type = price_type;
        this.area_text = area_text;
        this.ground_text = ground_text;
        this.living_type = living_type;
        this.living_text = living_text;
        this.bedrooms_type = bedrooms_type;
        this.bedrooms_text = bedrooms_text;
        this.bathrooms_type = bathrooms_type;
        this.bathrooms_text = bathrooms_text;
        this.frequency = frequency;
        this.price_from = price_from;
        this.price_per_meter = price_per_meter;
        this.factor = factor;
        this.rentAverage = rentAverage;
    }
}
// export class Property {
//     public id: number;
//     public title: string; 
//     public desc: string;
//     public propertyType: string;
//     public propertyStatus: string[];
//     public city: string;
//     public zipCode: string;
//     public neighborhood: string[];
//     public street: string[];
//     public location: Location;
//     public formattedAddress: string;
//     public features: string[];
//     public featured: boolean;
//     public priceDollar: Price;
//     public priceEuro: Price;
//     public bedrooms: number;
//     public bathrooms: number;
//     public floors: number;
//     public area: Area;
//     public yearBuilt: number;
//     public ratingsCount: number;
//     public ratingsValue: number;
//     public additionalFeatures: AdditionalFeature[];
//     public gallery: Gallery[];
//     public plans: Plan[];
//     public videos: Video[];
//     public published: string;
//     public lastUpdate: string;
//     public views: number
// }
class Area {
    constructor(value, unit) {
        this.value = value;
        this.unit = unit;
    }
}
class Ground {
    constructor(value, unit) {
        this.value = value;
        this.unit = unit;
    }
}
class Living {
    constructor(value, unit) {
        this.value = value;
        this.unit = unit;
    }
}
class AdditionalFeature {
    constructor(id, name, value) {
        this.id = id;
        this.name = name;
        this.value = value;
    }
}
class Location {
    constructor(id, lat, lng) {
        this.id = id;
        this.lat = lat;
        this.lng = lng;
    }
}
class Price {
}
class Gallery {
    constructor(id, small, medium, big) {
        this.id = id;
        this.small = small;
        this.medium = medium;
        this.big = big;
    }
}
class Plan {
    constructor(id, name, desc, area, rooms, baths, image) {
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.area = area;
        this.rooms = rooms;
        this.baths = baths;
        this.image = image;
    }
}
class Video {
    constructor(id, name, link) {
        this.id = id;
        this.name = name;
        this.link = link;
    }
}
class Pagination {
    constructor(page, perPage, prePage, nextPage, total, totalPages) {
        this.page = page;
        this.perPage = perPage;
        this.prePage = prePage;
        this.nextPage = nextPage;
        this.total = total;
        this.totalPages = totalPages;
    }
}
class User {
    constructor(id, name, email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }
}
class Neighbourhood {
    constructor(id, name, cityId) {
        this.id = id;
        this.name = name;
        this.cityId = cityId;
    }
}


/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/animations.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var ngx_progressbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-progressbar */ "./node_modules/ngx-progressbar/__ivy_ngcc__/fesm2015/ngx-progressbar.js");
/* harmony import */ var ngx_progressbar_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-progressbar/http */ "./node_modules/ngx-progressbar/__ivy_ngcc__/fesm2015/ngx-progressbar-http.js");
/* harmony import */ var _agm_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @agm/core */ "./node_modules/@agm/core/__ivy_ngcc__/fesm2015/agm-core.js");
/* harmony import */ var ngx_embed_video__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-embed-video */ "./node_modules/ngx-embed-video/__ivy_ngcc__/dist/index.js");
/* harmony import */ var ngx_embed_video__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(ngx_embed_video__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var ngx_input_file__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-input-file */ "./node_modules/ngx-input-file/__ivy_ngcc__/fesm2015/ngx-input-file.js");
/* harmony import */ var ngx_hotjar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-hotjar */ "./node_modules/ngx-hotjar/__ivy_ngcc__/fesm2015/ngx-hotjar.js");
/* harmony import */ var ngx_google_analytics__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-google-analytics */ "./node_modules/ngx-google-analytics/__ivy_ngcc__/fesm2015/ngx-google-analytics.js");
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/cdk/overlay */ "./node_modules/@angular/cdk/__ivy_ngcc__/fesm2015/overlay.js");
/* harmony import */ var _theme_utils_custom_overlay_container__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./theme/utils/custom-overlay-container */ "./src/app/theme/utils/custom-overlay-container.ts");
/* harmony import */ var _app_routing__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./app.routing */ "./src/app/app.routing.ts");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./shared/shared.module */ "./src/app/shared/shared.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_settings__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./app.settings */ "./src/app/app.settings.ts");
/* harmony import */ var _theme_utils_app_interceptor__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./theme/utils/app-interceptor */ "./src/app/theme/utils/app-interceptor.ts");
/* harmony import */ var _pages_pages_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./pages/pages.component */ "./src/app/pages/pages.component.ts");
/* harmony import */ var _pages_not_found_not_found_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./pages/not-found/not-found.component */ "./src/app/pages/not-found/not-found.component.ts");
/* harmony import */ var _theme_components_toolbar1_toolbar1_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./theme/components/toolbar1/toolbar1.component */ "./src/app/theme/components/toolbar1/toolbar1.component.ts");
/* harmony import */ var _theme_components_toolbar2_toolbar2_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./theme/components/toolbar2/toolbar2.component */ "./src/app/theme/components/toolbar2/toolbar2.component.ts");
/* harmony import */ var _theme_components_user_menu_user_menu_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./theme/components/user-menu/user-menu.component */ "./src/app/theme/components/user-menu/user-menu.component.ts");
/* harmony import */ var _theme_components_currency_currency_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./theme/components/currency/currency.component */ "./src/app/theme/components/currency/currency.component.ts");
/* harmony import */ var _theme_components_lang_lang_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./theme/components/lang/lang.component */ "./src/app/theme/components/lang/lang.component.ts");
/* harmony import */ var _theme_components_social_icons_social_icons_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./theme/components/social-icons/social-icons.component */ "./src/app/theme/components/social-icons/social-icons.component.ts");
/* harmony import */ var _theme_components_contacts_contacts_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./theme/components/contacts/contacts.component */ "./src/app/theme/components/contacts/contacts.component.ts");
/* harmony import */ var _theme_components_menu_horizontal_menu_horizontal_menu_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./theme/components/menu/horizontal-menu/horizontal-menu.component */ "./src/app/theme/components/menu/horizontal-menu/horizontal-menu.component.ts");
/* harmony import */ var _theme_components_menu_vertical_menu_vertical_menu_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./theme/components/menu/vertical-menu/vertical-menu.component */ "./src/app/theme/components/menu/vertical-menu/vertical-menu.component.ts");
/* harmony import */ var _theme_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./theme/components/footer/footer.component */ "./src/app/theme/components/footer/footer.component.ts");
/* harmony import */ var _pages_lock_screen_lock_screen_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./pages/lock-screen/lock-screen.component */ "./src/app/pages/lock-screen/lock-screen.component.ts");
/* harmony import */ var _services_user_helper_service__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./services/user-helper.service */ "./src/app/services/user-helper.service.ts");
/* harmony import */ var _services_auth_guard_service__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./services/auth-guard.service */ "./src/app/services/auth-guard.service.ts");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./services/auth.service */ "./src/app/services/auth.service.ts");
/* harmony import */ var _services_guest_guard_service__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./services/guest-guard.service */ "./src/app/services/guest-guard.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var ngx_lightbox__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ngx-lightbox */ "./node_modules/ngx-lightbox/__ivy_ngcc__/index.js");
/* harmony import */ var ngx_lightbox__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(ngx_lightbox__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @angular/service-worker */ "./node_modules/@angular/service-worker/__ivy_ngcc__/fesm2015/service-worker.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












const config = {
    fileAccept: '*'
};



























let AppModule = class AppModule {
};
AppModule = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _app_component__WEBPACK_IMPORTED_MODULE_16__["AppComponent"],
            _pages_pages_component__WEBPACK_IMPORTED_MODULE_19__["PagesComponent"],
            _pages_not_found_not_found_component__WEBPACK_IMPORTED_MODULE_20__["NotFoundComponent"],
            _theme_components_user_menu_user_menu_component__WEBPACK_IMPORTED_MODULE_23__["UserMenuComponent"],
            _theme_components_currency_currency_component__WEBPACK_IMPORTED_MODULE_24__["CurrencyComponent"],
            _theme_components_lang_lang_component__WEBPACK_IMPORTED_MODULE_25__["LangComponent"],
            _theme_components_social_icons_social_icons_component__WEBPACK_IMPORTED_MODULE_26__["SocialIconsComponent"],
            _theme_components_contacts_contacts_component__WEBPACK_IMPORTED_MODULE_27__["ContactsComponent"],
            _theme_components_toolbar1_toolbar1_component__WEBPACK_IMPORTED_MODULE_21__["Toolbar1Component"],
            _theme_components_toolbar2_toolbar2_component__WEBPACK_IMPORTED_MODULE_22__["Toolbar2Component"],
            _theme_components_menu_horizontal_menu_horizontal_menu_component__WEBPACK_IMPORTED_MODULE_28__["HorizontalMenuComponent"],
            _theme_components_menu_vertical_menu_vertical_menu_component__WEBPACK_IMPORTED_MODULE_29__["VerticalMenuComponent"],
            _theme_components_footer_footer_component__WEBPACK_IMPORTED_MODULE_30__["FooterComponent"],
            _pages_lock_screen_lock_screen_component__WEBPACK_IMPORTED_MODULE_31__["LockScreenComponent"]
        ],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"].withServerTransition({ appId: 'my-app' }),
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__["BrowserAnimationsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
            _agm_core__WEBPACK_IMPORTED_MODULE_7__["AgmCoreModule"].forRoot({
                apiKey: 'AIzaSyA1rF9bttCxRmsNdZYjW7FzIoyrul5jb-s',
                libraries: ["places"]
            }),
            ngx_embed_video__WEBPACK_IMPORTED_MODULE_8__["EmbedVideo"].forRoot(),
            ngx_progressbar__WEBPACK_IMPORTED_MODULE_5__["NgProgressModule"],
            ngx_progressbar_http__WEBPACK_IMPORTED_MODULE_6__["NgProgressHttpModule"],
            ngx_input_file__WEBPACK_IMPORTED_MODULE_9__["InputFileModule"].forRoot(config),
            ngx_hotjar__WEBPACK_IMPORTED_MODULE_10__["NgxHotjarModule"].forRoot(_environments_environment__WEBPACK_IMPORTED_MODULE_36__["environment"].hj),
            ngx_hotjar__WEBPACK_IMPORTED_MODULE_10__["NgxHotjarRouterModule"],
            ngx_google_analytics__WEBPACK_IMPORTED_MODULE_11__["NgxGoogleAnalyticsModule"].forRoot(_environments_environment__WEBPACK_IMPORTED_MODULE_36__["environment"].ga),
            ngx_google_analytics__WEBPACK_IMPORTED_MODULE_11__["NgxGoogleAnalyticsRouterModule"],
            _app_routing__WEBPACK_IMPORTED_MODULE_14__["AppRoutingModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_15__["SharedModule"],
            ngx_lightbox__WEBPACK_IMPORTED_MODULE_37__["LightboxModule"],
            _angular_service_worker__WEBPACK_IMPORTED_MODULE_38__["ServiceWorkerModule"].register('ngsw-worker.js', { enabled: _environments_environment__WEBPACK_IMPORTED_MODULE_36__["environment"].production })
        ],
        providers: [
            _app_settings__WEBPACK_IMPORTED_MODULE_17__["AppSettings"],
            _services_auth_service__WEBPACK_IMPORTED_MODULE_34__["AuthService"],
            _services_auth_guard_service__WEBPACK_IMPORTED_MODULE_33__["AuthGuardService"],
            _services_guest_guard_service__WEBPACK_IMPORTED_MODULE_35__["GuestGuardService"],
            _services_user_helper_service__WEBPACK_IMPORTED_MODULE_32__["UserHelperService"],
            { provide: _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_12__["OverlayContainer"], useClass: _theme_utils_custom_overlay_container__WEBPACK_IMPORTED_MODULE_13__["CustomOverlayContainer"] },
            { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HTTP_INTERCEPTORS"], useClass: _theme_utils_app_interceptor__WEBPACK_IMPORTED_MODULE_18__["AppInterceptor"], multi: true }
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_16__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/app.routing.ts":
/*!********************************!*\
  !*** ./src/app/app.routing.ts ***!
  \********************************/
/*! exports provided: routes, AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _pages_pages_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/pages.component */ "./src/app/pages/pages.component.ts");
/* harmony import */ var _pages_not_found_not_found_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/not-found/not-found.component */ "./src/app/pages/not-found/not-found.component.ts");
/* harmony import */ var _pages_lock_screen_lock_screen_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/lock-screen/lock-screen.component */ "./src/app/pages/lock-screen/lock-screen.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





const routes = [
    {
        path: '',
        component: _pages_pages_component__WEBPACK_IMPORTED_MODULE_2__["PagesComponent"], children: [
            //{ path: '', redirectTo: '/landing', pathMatch: 'full' },
            { path: '', loadChildren: () => __webpack_require__.e(/*! import() | pages-home-home-module */ "pages-home-home-module").then(__webpack_require__.bind(null, /*! ./pages/home/home.module */ "./src/app/pages/home/home.module.ts")).then(m => m.HomeModule) },
            { path: 'about', loadChildren: () => __webpack_require__.e(/*! import() | pages-about-about-module */ "pages-about-about-module").then(__webpack_require__.bind(null, /*! ./pages/about/about.module */ "./src/app/pages/about/about.module.ts")).then(m => m.AboutModule) },
            { path: 'contact', loadChildren: () => __webpack_require__.e(/*! import() | pages-contact-contact-module */ "pages-contact-contact-module").then(__webpack_require__.bind(null, /*! ./pages/contact/contact.module */ "./src/app/pages/contact/contact.module.ts")).then(m => m.ContactModule) },
            { path: 'properties', loadChildren: () => __webpack_require__.e(/*! import() | pages-properties-properties-module */ "pages-properties-properties-module").then(__webpack_require__.bind(null, /*! ./pages/properties/properties.module */ "./src/app/pages/properties/properties.module.ts")).then(m => m.PropertiesModule) },
            { path: 'agents', loadChildren: () => __webpack_require__.e(/*! import() | pages-agents-agents-module */ "pages-agents-agents-module").then(__webpack_require__.bind(null, /*! ./pages/agents/agents.module */ "./src/app/pages/agents/agents.module.ts")).then(m => m.AgentsModule) },
            { path: 'compare', loadChildren: () => __webpack_require__.e(/*! import() | pages-compare-compare-module */ "pages-compare-compare-module").then(__webpack_require__.bind(null, /*! ./pages/compare/compare.module */ "./src/app/pages/compare/compare.module.ts")).then(m => m.CompareModule) },
            { path: 'pricing', loadChildren: () => __webpack_require__.e(/*! import() | pages-pricing-pricing-module */ "pages-pricing-pricing-module").then(__webpack_require__.bind(null, /*! ./pages/pricing/pricing.module */ "./src/app/pages/pricing/pricing.module.ts")).then(m => m.PricingModule) },
            { path: 'faq', loadChildren: () => __webpack_require__.e(/*! import() | pages-faq-faq-module */ "pages-faq-faq-module").then(__webpack_require__.bind(null, /*! ./pages/faq/faq.module */ "./src/app/pages/faq/faq.module.ts")).then(m => m.FaqModule) },
            { path: 'login', loadChildren: () => __webpack_require__.e(/*! import() | pages-login-login-module */ "pages-login-login-module").then(__webpack_require__.bind(null, /*! ./pages/login/login.module */ "./src/app/pages/login/login.module.ts")).then(m => m.LoginModule) },
            { path: 'password/email', loadChildren: () => __webpack_require__.e(/*! import() | pages-sendResetLinkEmail-sendResetLinkEmail-module */ "pages-sendResetLinkEmail-sendResetLinkEmail-module").then(__webpack_require__.bind(null, /*! ./pages/sendResetLinkEmail/sendResetLinkEmail.module */ "./src/app/pages/sendResetLinkEmail/sendResetLinkEmail.module.ts")).then(m => m.SendResetLinkEmailModule) },
            { path: 'password/reset', loadChildren: () => __webpack_require__.e(/*! import() | pages-resetPassword-resetPassword-module */ "pages-resetPassword-resetPassword-module").then(__webpack_require__.bind(null, /*! ./pages/resetPassword/resetPassword.module */ "./src/app/pages/resetPassword/resetPassword.module.ts")).then(m => m.ResetPasswordModule) },
            { path: 'register', loadChildren: () => __webpack_require__.e(/*! import() | pages-register-register-module */ "pages-register-register-module").then(__webpack_require__.bind(null, /*! ./pages/register/register.module */ "./src/app/pages/register/register.module.ts")).then(m => m.RegisterModule) },
            { path: 'terms-conditions', loadChildren: () => __webpack_require__.e(/*! import() | pages-terms-conditions-terms-conditions-module */ "pages-terms-conditions-terms-conditions-module").then(__webpack_require__.bind(null, /*! ./pages/terms-conditions/terms-conditions.module */ "./src/app/pages/terms-conditions/terms-conditions.module.ts")).then(m => m.TermsConditionsModule) },
            { path: 'account', loadChildren: () => __webpack_require__.e(/*! import() | pages-account-account-module */ "pages-account-account-module").then(__webpack_require__.bind(null, /*! ./pages/account/account.module */ "./src/app/pages/account/account.module.ts")).then(m => m.AccountModule) },
            { path: 'submit-property', loadChildren: () => __webpack_require__.e(/*! import() | pages-submit-property-submit-property-module */ "pages-submit-property-submit-property-module").then(__webpack_require__.bind(null, /*! ./pages/submit-property/submit-property.module */ "./src/app/pages/submit-property/submit-property.module.ts")).then(m => m.SubmitPropertyModule) }
        ]
    },
    { path: 'landing', loadChildren: () => __webpack_require__.e(/*! import() | pages-landing-landing-module */ "pages-landing-landing-module").then(__webpack_require__.bind(null, /*! ./pages/landing/landing.module */ "./src/app/pages/landing/landing.module.ts")).then(m => m.LandingModule) },
    { path: 'lock-screen', component: _pages_lock_screen_lock_screen_component__WEBPACK_IMPORTED_MODULE_4__["LockScreenComponent"] },
    { path: '**', component: _pages_not_found_not_found_component__WEBPACK_IMPORTED_MODULE_3__["NotFoundComponent"] }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes, {
                preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_1__["PreloadAllModules"],
                initialNavigation: 'enabled' // for one load page, without reload
                // useHash: true
            })
        ],
        exports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]
        ]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.service.ts":
/*!********************************!*\
  !*** ./src/app/app.service.ts ***!
  \********************************/
/*! exports provided: Data, AppService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Data", function() { return Data; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppService", function() { return AppService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/bottom-sheet */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/bottom-sheet.js");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/snack-bar */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/snack-bar.js");
/* harmony import */ var _app_settings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.settings */ "./src/app/app.settings.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! qs */ "./node_modules/qs/lib/index.js");
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(qs__WEBPACK_IMPORTED_MODULE_7__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








class Data {
    constructor(properties, compareList, favorites, locations) {
        this.properties = properties;
        this.compareList = compareList;
        this.favorites = favorites;
        this.locations = locations;
    }
}
let AppService = class AppService {
    constructor(http, bottomSheet, snackBar, appSettings, platformId) {
        this.http = http;
        this.bottomSheet = bottomSheet;
        this.snackBar = snackBar;
        this.appSettings = appSettings;
        this.platformId = platformId;
        this.Data = new Data([], // properties
        [], // compareList
        [], // favorites
        [] // locations
        );
        this.url = "http://localhost:4200/assets/data/";
        this.apiUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl;
        this.apiKey = 'AIzaSyA1rF9bttCxRmsNdZYjW7FzIoyrul5jb-s';
        this.url = _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].selfApiUrl + "/assets/data/";
    }
    getProperties(searchFields, sort, page, length) {
        page = page || 1;
        length = length || 8;
        sort = sort || '';
        const params = this.getPropertyParams(searchFields);
        return this.http.get(this.apiUrl +
            '/api/properties?page=' + page +
            '&length=' + length +
            '&sort=' + sort +
            '&' + Object(qs__WEBPACK_IMPORTED_MODULE_7__["stringify"])(params));
    }
    getPropertyParams(searchFields) {
        var _a, _b;
        if (!searchFields) {
            return;
        }
        return {
            area: searchFields.area,
            bathrooms: searchFields.bathrooms,
            bedrooms: searchFields.bedrooms,
            city: searchFields.city,
            amenities: (_a = searchFields.features) === null || _a === void 0 ? void 0 : _a.filter(feature => feature.selected).map(feature => feature.id),
            garages: searchFields.garages,
            floors: searchFields.floors,
            neighbourhoods: (_b = searchFields.neighborhood) === null || _b === void 0 ? void 0 : _b.map(neighborhood => neighborhood.id),
            price: searchFields.price,
            propertyStatus: searchFields.propertyStatus,
            type: searchFields.propertyType,
            street: searchFields.street,
            yearBuilt: searchFields.yearBuilt,
            zipCode: searchFields.zipCode
        };
    }
    // public getPropertyById(id): Observable<Property>{
    //   return this.http.get<Property>(this.url + 'property-' + id + '.json');
    // }
    getPropertyById(id) {
        return this.http.get(this.apiUrl + '/api/properties/' + id);
    }
    getFeaturedProperties() {
        return this.http.get(this.apiUrl + '/api/properties/featured?page=1&length=5');
    }
    getNewThisWeekProperties() {
        return this.http.get(this.apiUrl + '/api/properties/new-this-week?page=1&length=5');
    }
    getRelatedProperties(id) {
        return this.http.get(this.apiUrl + '/api/properties/' + id + '/related?page=1&length=5');
    }
    getPropertiesByAgentId(agentId) {
        return this.http.get(this.url + 'properties-agentid-' + agentId + '.json');
    }
    getLocations() {
        return this.http.get(this.url + 'locations.json');
    }
    getAddress(lat = 40.714224, lng = -73.961452) {
        return this.http.get('https://maps.googleapis.com/maps/api/geocode/json?latlng=' + lat + ',' + lng + '&key=' + this.apiKey);
    }
    getLatLng(address) {
        return this.http.get('https://maps.googleapis.com/maps/api/geocode/json?key=' + this.apiKey + '&address=' + address);
    }
    getFullAddress(lat = 40.714224, lng = -73.961452) {
        return this.http.get('https://maps.googleapis.com/maps/api/geocode/json?latlng=' + lat + ',' + lng + '&key=' + this.apiKey).subscribe(data => {
            return data['results'][0]['formatted_address'];
        });
    }
    addToCompare(property, component, direction) {
        if (!this.Data.compareList.filter(item => item.id == property.id)[0]) {
            this.Data.compareList.push(property);
            this.bottomSheet.open(component, {
                direction: direction
            }).afterDismissed().subscribe(isRedirect => {
                if (isRedirect) {
                    if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_5__["isPlatformBrowser"])(this.platformId)) {
                        window.scrollTo(0, 0);
                    }
                }
            });
        }
    }
    addToFavorites(property, direction) {
        if (!this.Data.favorites.filter(item => item.id == property.id)[0]) {
            this.Data.favorites.push(property);
            this.snackBar.open('The property "' + property.title + '" has been added to favorites.', '×', {
                verticalPosition: 'top',
                duration: 3000,
                direction: direction
            });
        }
    }
    getPropertyTypes() {
        return [
            { id: 1, name: 'Office' },
            { id: 2, name: 'House' },
            { id: 3, name: 'Apartment' }
        ];
    }
    getPropertyStatuses() {
        return [
            { id: 1, name: 'For Sale' },
            { id: 2, name: 'For Rent' },
            { id: 3, name: 'Open House' },
            { id: 4, name: 'No Fees' },
            { id: 5, name: 'Hot Offer' },
            { id: 6, name: 'Sold' }
        ];
    }
    getCities() {
        return [
            { id: 1, name: 'New York' },
            { id: 2, name: 'Chicago' },
            { id: 3, name: 'Los Angeles' },
            { id: 4, name: 'Seattle' }
        ];
    }
    getNeighborhoods() {
        return [
            { id: 238, name: 'Alaior', cityId: null },
            { id: 79, name: 'Alaró', cityId: null },
            { id: 70, name: 'Alcudia', cityId: null },
            { id: 188, name: 'Alcúdia / Alcanada', cityId: null },
            { id: 174, name: 'Alcudia / Bon Aire', cityId: null },
            { id: 225, name: 'Alcúdia / Port d\'Alcúdia', cityId: null },
            { id: 141, name: 'Alcudia / Son Fé', cityId: null },
            { id: 40, name: 'Algaida', cityId: null },
            { id: 14, name: 'Andratx', cityId: null },
            { id: 137, name: 'Andratx / Port d\'Andratx', cityId: null },
            { id: 142, name: 'Andratx / Puerto de Andratx', cityId: null },
            { id: 165, name: 'Andratx / Sant Elm', cityId: null },
            { id: 240, name: 'Arenal', cityId: null },
            { id: 49, name: 'Artá', cityId: null },
            { id: 150, name: 'Artà / Betlem', cityId: null },
            { id: 163, name: 'Arta / Son Catiu', cityId: null },
            { id: 135, name: 'Bahia Azul', cityId: null },
            { id: 176, name: 'Bahia Grande', cityId: null },
            { id: 50, name: 'Banyalbufar', cityId: null },
            { id: 1, name: 'Bendinat', cityId: null },
            { id: 245, name: 'Betlem', cityId: null },
            { id: 159, name: 'Biniali', cityId: null },
            { id: 99, name: 'Binissalem', cityId: null },
            { id: 68, name: 'Bonaire', cityId: null },
            { id: 173, name: 'Bonanova', cityId: null },
            { id: 242, name: 'Búger', cityId: null },
            { id: 92, name: 'Bunyola', cityId: null },
            { id: 199, name: 'Caimari', cityId: null },
            { id: 66, name: 'Cala Blava', cityId: null },
            { id: 231, name: 'Cala D Or', cityId: null },
            { id: 56, name: 'Cala d\'Or', cityId: null },
            { id: 41, name: 'Cala Llombards', cityId: null },
            { id: 223, name: 'Cala Mandia', cityId: null },
            { id: 186, name: 'Cala Mayor', cityId: null },
            { id: 239, name: 'Cala Millor', cityId: null },
            { id: 62, name: 'Cala Mondragó', cityId: null },
            { id: 136, name: 'Cala Murada', cityId: null },
            { id: 37, name: 'Cala Pi', cityId: null },
            { id: 226, name: 'Cala Tuent', cityId: null },
            { id: 151, name: 'Cala Viñas', cityId: null },
            { id: 13, name: 'Cala Vinyas', cityId: null },
            { id: 18, name: 'Calviá', cityId: null },
            { id: 23, name: 'Calvía – Son Font', cityId: null },
            { id: 139, name: 'Calvià / Bendinat', cityId: null },
            { id: 143, name: 'Calvià / Costa d\'en Blanes', cityId: null },
            { id: 172, name: 'Calvià / Costa de la Calma', cityId: null },
            { id: 219, name: 'Calvià / Costa den Blanes', cityId: null },
            { id: 190, name: 'Calvià / el Toro', cityId: null },
            { id: 162, name: 'Calvià / Illetas', cityId: null },
            { id: 180, name: 'Calvià / Illetes', cityId: null },
            { id: 201, name: 'Calvià / Magaluf', cityId: null },
            { id: 148, name: 'Calvià / Palmanova', cityId: null },
            { id: 152, name: 'Calvià / Peguera', cityId: null },
            { id: 192, name: 'Calvià / Portals Nous', cityId: null },
            { id: 194, name: 'Calvià / Santa Ponça', cityId: null },
            { id: 170, name: 'Calvià / Santa Ponsa', cityId: null },
            { id: 210, name: 'Calvià / Sol de Mallorca', cityId: null },
            { id: 5, name: 'Camp de Mar', cityId: null },
            { id: 115, name: 'Campanet', cityId: null },
            { id: 57, name: 'Campos', cityId: null },
            { id: 178, name: 'Campos / sa Ràpita', cityId: null },
            { id: 230, name: 'Can Pastilla', cityId: null },
            { id: 122, name: 'Can Picafort', cityId: null },
            { id: 32, name: 'Canyamel', cityId: null },
            { id: 17, name: 'Capdella', cityId: null },
            { id: 54, name: 'Capdepera', cityId: null },
            { id: 220, name: 'Capdepera / Cala Rajada', cityId: null },
            { id: 153, name: 'Capdepera / Costa de Canyamel', cityId: null },
            { id: 2, name: 'Cas Catalá', cityId: null },
            { id: 145, name: 'Ciudad Jardin', cityId: null },
            { id: 236, name: 'Ciutadella de Menorca', cityId: null },
            { id: 232, name: 'Colonia de Sant Jordi', cityId: null },
            { id: 187, name: 'Colonia de Sant Pere', cityId: null },
            { id: 107, name: 'Colonia Sant Jordi', cityId: null },
            { id: 114, name: 'Consell', cityId: null },
            { id: 3, name: 'Costa d\'en Blanes', cityId: null },
            { id: 16, name: 'Costa de la Calma', cityId: null },
            { id: 193, name: 'Costa de los Pinos', cityId: null },
            { id: 205, name: 'Costa den Blanes', cityId: null },
            { id: 118, name: 'Costitx', cityId: null },
            { id: 169, name: 'Crestatx', cityId: null },
            { id: 109, name: 'Deiá', cityId: null },
            { id: 229, name: 'El Arenal', cityId: null },
            { id: 147, name: 'El Molinar', cityId: null },
            { id: 78, name: 'El Toro', cityId: null },
            { id: 7, name: 'El Toro - Port Adriano', cityId: null },
            { id: 207, name: 'Es Capdellà', cityId: null },
            { id: 233, name: 'Es Castell', cityId: null },
            { id: 36, name: 'Es Llombards', cityId: null },
            { id: 237, name: 'Es Mercadal', cityId: null },
            { id: 191, name: 'Escorca', cityId: null },
            { id: 146, name: 'Esporlas', cityId: null },
            { id: 55, name: 'Esporles', cityId: null },
            { id: 214, name: 'Establiments', cityId: null },
            { id: 126, name: 'Estellencs', cityId: null },
            { id: 38, name: 'Felanitx', cityId: null },
            { id: 164, name: 'Fornalutx', cityId: null },
            { id: 113, name: 'Galilea', cityId: null },
            { id: 10, name: 'Génova', cityId: null },
            { id: 91, name: 'Ibiza', cityId: null },
            { id: 29, name: 'Illetas', cityId: null },
            { id: 61, name: 'Inca', cityId: null },
            { id: 156, name: 'La Bonanova', cityId: null },
            { id: 112, name: 'La Rapita', cityId: null },
            { id: 88, name: 'Lloret de Vistalegre', cityId: null },
            { id: 44, name: 'Lloseta', cityId: null },
            { id: 65, name: 'Llubi', cityId: null },
            { id: 224, name: 'Llucalcari', cityId: null },
            { id: 39, name: 'Llucmajor', cityId: null },
            { id: 197, name: 'Llucmajor / Cala Blava', cityId: null },
            { id: 166, name: 'Llucmajor / Las Palmeras', cityId: null },
            { id: 167, name: 'Llucmajor / s\'Arenal', cityId: null },
            { id: 198, name: 'Llucmajor, Las Palmeras', cityId: null },
            { id: 218, name: 'Llucmayor', cityId: null },
            { id: 120, name: 'Magalluf', cityId: null },
            { id: 24, name: 'Magaluf', cityId: null },
            { id: 234, name: 'Mahon', cityId: null },
            { id: 53, name: 'Manacor', cityId: null },
            { id: 213, name: 'Manacor / Colonia de Sant Pere', cityId: null },
            { id: 203, name: 'Manacor / Son Macià', cityId: null },
            { id: 134, name: 'Mancor de la Vall', cityId: null },
            { id: 241, name: 'Maria de la Salut', cityId: null },
            { id: 171, name: 'Marivent', cityId: null },
            { id: 59, name: 'Marratxi', cityId: null },
            { id: 46, name: 'Montuiri', cityId: null },
            { id: 35, name: 'Muro', cityId: null },
            { id: 182, name: 'Muro / Playa de Muro', cityId: null },
            { id: 144, name: 'Nova Santa Ponsa', cityId: null },
            { id: 117, name: 'Orient', cityId: null },
            { id: 15, name: 'Paguera', cityId: null },
            { id: 4, name: 'Palma', cityId: null },
            { id: 97, name: 'Palma - Avenidas', cityId: null },
            { id: 106, name: 'Palma - Bonanova', cityId: null },
            { id: 90, name: 'Palma - Cala Estancia', cityId: null },
            { id: 121, name: 'Palma - Cala Major', cityId: null },
            { id: 132, name: 'Palma - Can Pastilla', cityId: null },
            { id: 74, name: 'Palma - Casco Antiguo', cityId: null },
            { id: 93, name: 'Palma - Coll d\'en Rabassa', cityId: null },
            { id: 110, name: 'Palma - El Terreno', cityId: null },
            { id: 108, name: 'Palma - Establiments', cityId: null },
            { id: 105, name: 'Palma - Génova', cityId: null },
            { id: 116, name: 'Palma - Jaime III', cityId: null },
            { id: 82, name: 'Palma - Las Maravillas', cityId: null },
            { id: 98, name: 'Palma - Palma', cityId: null },
            { id: 77, name: 'Palma - Paseo Maritimo', cityId: null },
            { id: 87, name: 'Palma - Pont d\'Inca', cityId: null },
            { id: 75, name: 'Palma - Portixol', cityId: null },
            { id: 81, name: 'Palma - Porto Pi', cityId: null },
            { id: 85, name: 'Palma - Puntiró', cityId: null },
            { id: 133, name: 'Palma - Sa Teulera', cityId: null },
            { id: 73, name: 'Palma - San Agustín', cityId: null },
            { id: 72, name: 'Palma - Santa Catalina', cityId: null },
            { id: 84, name: 'Palma - Secar de la Real', cityId: null },
            { id: 103, name: 'Palma - Son Espanyolet', cityId: null },
            { id: 129, name: 'Palma - Son Quint', cityId: null },
            { id: 124, name: 'Palma - Son Rapinya', cityId: null },
            { id: 96, name: 'Palma - Son Roca', cityId: null },
            { id: 94, name: 'Palma - Son Sardina', cityId: null },
            { id: 9, name: 'Palma - Son Vida', cityId: null },
            { id: 149, name: 'Palma de Mallorca', cityId: null },
            { id: 22, name: 'Palmanova', cityId: null },
            { id: 76, name: 'Paraiso de Bonaire', cityId: null },
            { id: 104, name: 'Petra', cityId: null },
            { id: 216, name: 'Pina', cityId: null },
            { id: 125, name: 'Pollença', cityId: null },
            { id: 168, name: 'Pollensa', cityId: null },
            { id: 211, name: 'Pollensa / El Vilar', cityId: null },
            { id: 183, name: 'Pollensa / La Font', cityId: null },
            { id: 217, name: 'Pollensa / Ternelles / La Font', cityId: null },
            { id: 47, name: 'Porreres', cityId: null },
            { id: 131, name: 'Port Adriano', cityId: null },
            { id: 6, name: 'Port Andratx', cityId: null },
            { id: 246, name: 'Port de Pollença', cityId: null },
            { id: 195, name: 'Portals', cityId: null },
            { id: 19, name: 'Portals Nous', cityId: null },
            { id: 208, name: 'Portitxol', cityId: null },
            { id: 89, name: 'Porto Colom', cityId: null },
            { id: 102, name: 'Porto Cristo', cityId: null },
            { id: 119, name: 'Porto Petro', cityId: null },
            { id: 181, name: 'Portocolom', cityId: null },
            { id: 34, name: 'Portocristo', cityId: null },
            { id: 221, name: 'Portopetro', cityId: null },
            { id: 71, name: 'Puerto Andratx', cityId: null },
            { id: 209, name: 'Puerto Andratx, La Mola', cityId: null },
            { id: 204, name: 'Puerto Andrax', cityId: null },
            { id: 202, name: 'Puerto de Alcudia', cityId: null },
            { id: 138, name: 'Puerto de Andratx', cityId: null },
            { id: 154, name: 'Puerto de Pollensa', cityId: null },
            { id: 184, name: 'Puerto de Soller', cityId: null },
            { id: 101, name: 'Puerto Pollensa', cityId: null },
            { id: 123, name: 'Puerto Portals', cityId: null },
            { id: 31, name: 'Puig de Ros', cityId: null },
            { id: 58, name: 'Puigpunyent', cityId: null },
            { id: 21, name: 'Puntiro', cityId: null },
            { id: 228, name: 'S\'Arenal', cityId: null },
            { id: 25, name: 'S\'Arraco', cityId: null },
            { id: 222, name: 's\'Espinagar', cityId: null },
            { id: 45, name: 'S\'Illot', cityId: null },
            { id: 189, name: 'Sa Cabaneta', cityId: null },
            { id: 212, name: 'Sa Coma', cityId: null },
            { id: 160, name: 'Sa coma de Bunyola', cityId: null },
            { id: 227, name: 'Sa Pobla', cityId: null },
            { id: 179, name: 'Sa Pobla / Crestatx', cityId: null },
            { id: 42, name: 'Sa Ràpita', cityId: null },
            { id: 28, name: 'Sa Torre', cityId: null },
            { id: 243, name: 'Salines  - ses', cityId: null },
            { id: 26, name: 'San Agustin', cityId: null },
            { id: 158, name: 'San Augustin', cityId: null },
            { id: 12, name: 'San Telmo', cityId: null },
            { id: 130, name: 'Sant Joan', cityId: null },
            { id: 196, name: 'Sant Llorenç', cityId: null },
            { id: 235, name: 'Sant Lluis', cityId: null },
            { id: 185, name: 'Santa Catalina', cityId: null },
            { id: 100, name: 'Santa Eugenia', cityId: null },
            { id: 63, name: 'Santa Margalida', cityId: null },
            { id: 155, name: 'Santa Margarita', cityId: null },
            { id: 64, name: 'Santa Maria', cityId: null },
            { id: 83, name: 'Santa Maria del Cami', cityId: null },
            { id: 215, name: 'Santa Ponça', cityId: null },
            { id: 8, name: 'Santa Ponsa', cityId: null },
            { id: 43, name: 'Santanyí', cityId: null },
            { id: 200, name: 'Santanyi / Cala d\'Or', cityId: null },
            { id: 33, name: 'Selva', cityId: null },
            { id: 48, name: 'Sencelles', cityId: null },
            { id: 128, name: 'Ses Alqueries', cityId: null },
            { id: 175, name: 'Ses Rotgetes de Canet', cityId: null },
            { id: 69, name: 'Ses Salines', cityId: null },
            { id: 60, name: 'Sineu', cityId: null },
            { id: 11, name: 'Sol de Mallorca', cityId: null },
            { id: 80, name: 'Sóller', cityId: null },
            { id: 157, name: 'Son Anglada', cityId: null },
            { id: 161, name: 'Son Caliu', cityId: null },
            { id: 127, name: 'Son Ferrer', cityId: null },
            { id: 177, name: 'Son Ferriol', cityId: null },
            { id: 111, name: 'Son Font', cityId: null },
            { id: 52, name: 'Son Gual', cityId: null },
            { id: 206, name: 'Son Macia', cityId: null },
            { id: 244, name: 'Son Serra De Marina', cityId: null },
            { id: 67, name: 'Son Servera', cityId: null },
            { id: 30, name: 'Son Veri Nou', cityId: null },
            { id: 140, name: 'Son Vida', cityId: null },
            { id: 27, name: 'Tolleric', cityId: null },
            { id: 20, name: 'Torrenova', cityId: null },
            { id: 95, name: 'Valldemossa', cityId: null },
            { id: 51, name: 'Vilafranca', cityId: null },
            { id: 86, name: 'Vilafranca de Bonany', cityId: null }
        ];
    }
    getStreets() {
        return [
            { id: 1, name: 'Astoria Street #1', cityId: 1, neighborhoodId: 1 },
            { id: 2, name: 'Astoria Street #2', cityId: 1, neighborhoodId: 1 },
            { id: 3, name: 'Midtown Street #1', cityId: 1, neighborhoodId: 2 },
            { id: 4, name: 'Midtown Street #2', cityId: 1, neighborhoodId: 2 },
            { id: 5, name: 'Chinatown Street #1', cityId: 1, neighborhoodId: 3 },
            { id: 6, name: 'Chinatown Street #2', cityId: 1, neighborhoodId: 3 },
            { id: 7, name: 'Austin Street #1', cityId: 2, neighborhoodId: 4 },
            { id: 8, name: 'Austin Street #2', cityId: 2, neighborhoodId: 4 },
            { id: 9, name: 'Englewood Street #1', cityId: 2, neighborhoodId: 5 },
            { id: 10, name: 'Englewood Street #2', cityId: 2, neighborhoodId: 5 },
            { id: 11, name: 'Riverdale Street #1', cityId: 2, neighborhoodId: 6 },
            { id: 12, name: 'Riverdale Street #2', cityId: 2, neighborhoodId: 6 },
            { id: 13, name: 'Hollywood Street #1', cityId: 3, neighborhoodId: 7 },
            { id: 14, name: 'Hollywood Street #2', cityId: 3, neighborhoodId: 7 },
            { id: 15, name: 'Sherman Oaks Street #1', cityId: 3, neighborhoodId: 8 },
            { id: 16, name: 'Sherman Oaks Street #2', cityId: 3, neighborhoodId: 8 },
            { id: 17, name: 'Highland Park Street #1', cityId: 3, neighborhoodId: 9 },
            { id: 18, name: 'Highland Park Street #2', cityId: 3, neighborhoodId: 9 },
            { id: 19, name: 'Belltown Street #1', cityId: 4, neighborhoodId: 10 },
            { id: 20, name: 'Belltown Street #2', cityId: 4, neighborhoodId: 10 },
            { id: 21, name: 'Queen Anne Street #1', cityId: 4, neighborhoodId: 11 },
            { id: 22, name: 'Queen Anne Street #2', cityId: 4, neighborhoodId: 11 },
            { id: 23, name: 'Green Lake Street #1', cityId: 4, neighborhoodId: 12 },
            { id: 24, name: 'Green Lake Street #2', cityId: 4, neighborhoodId: 12 }
        ];
    }
    getFeatures() {
        return [
            { id: 1, name: 'Air Conditioning', selected: false },
            { id: 2, name: 'Barbeque', selected: false },
            { id: 3, name: 'Dryer', selected: false },
            { id: 4, name: 'Microwave', selected: false },
            { id: 5, name: 'Refrigerator', selected: false },
            { id: 6, name: 'TV Cable', selected: false },
            { id: 7, name: 'Sauna', selected: false },
            { id: 8, name: 'WiFi', selected: false },
            { id: 9, name: 'Fireplace', selected: false },
            { id: 10, name: 'Swimming Pool', selected: false },
            { id: 11, name: 'Gym', selected: false },
        ];
    }
    getHomeCarouselSlides() {
        return this.http.get(this.url + 'slides.json');
    }
    filterData(data, params, sort, page, perPage) {
        if (params) {
            if (params.propertyType) {
                data = data.filter(property => property.propertyType == params.propertyType.name);
            }
            if (params.propertyStatus && params.propertyStatus.length) {
                let statuses = [];
                params.propertyStatus.forEach(status => { statuses.push(status.name); });
                let properties = [];
                data.filter(property => property.propertyStatus.forEach(status => {
                    if (statuses.indexOf(status) > -1) {
                        if (!properties.includes(property)) {
                            properties.push(property);
                        }
                    }
                }));
                data = properties;
            }
            if (params.price) {
                if (this.appSettings.settings.currency == 'USD') {
                    if (params.price.from) {
                        data = data.filter(property => {
                            if (property.priceDollar.sale && property.priceDollar.sale >= params.price.from) {
                                return true;
                            }
                            if (property.priceDollar.rent && property.priceDollar.rent >= params.price.from) {
                                return true;
                            }
                            return false;
                        });
                    }
                    if (params.price.to) {
                        data = data.filter(property => {
                            if (property.priceDollar.sale && property.priceDollar.sale <= params.price.to) {
                                return true;
                            }
                            if (property.priceDollar.rent && property.priceDollar.rent <= params.price.to) {
                                return true;
                            }
                            return false;
                        });
                    }
                }
                if (this.appSettings.settings.currency == 'EUR') {
                    if (params.price.from) {
                        data = data.filter(property => {
                            if (property.priceEuro.sale && property.priceEuro.sale >= params.price.from) {
                                return true;
                            }
                            if (property.priceEuro.rent && property.priceEuro.rent >= params.price.from) {
                                return true;
                            }
                            return false;
                        });
                    }
                    if (params.price.to) {
                        data = data.filter(property => {
                            if (property.priceEuro.sale && property.priceEuro.sale <= params.price.to) {
                                return true;
                            }
                            if (property.priceEuro.rent && property.priceEuro.rent <= params.price.to) {
                                return true;
                            }
                            return false;
                        });
                    }
                }
            }
            if (params.city) {
                data = data.filter(property => property.city == params.city.name);
            }
            if (params.zipCode) {
                data = data.filter(property => property.zipCode == params.zipCode);
            }
            if (params.neighborhood && params.neighborhood.length) {
                let neighborhoods = [];
                params.neighborhood.forEach(item => { neighborhoods.push(item.name); });
                let properties = [];
                data.filter(property => property.neighborhood.forEach(item => {
                    if (neighborhoods.indexOf(item) > -1) {
                        if (!properties.includes(property)) {
                            properties.push(property);
                        }
                    }
                }));
                data = properties;
            }
            if (params.street && params.street.length) {
                let streets = [];
                params.street.forEach(item => { streets.push(item.name); });
                let properties = [];
                data.filter(property => property.street.forEach(item => {
                    if (streets.indexOf(item) > -1) {
                        if (!properties.includes(property)) {
                            properties.push(property);
                        }
                    }
                }));
                data = properties;
            }
            if (params.bedrooms) {
                if (params.bedrooms.from) {
                    data = data.filter(property => property.bedrooms >= params.bedrooms.from);
                }
                if (params.bedrooms.to) {
                    data = data.filter(property => property.bedrooms <= params.bedrooms.to);
                }
            }
            if (params.bathrooms) {
                if (params.bathrooms.from) {
                    data = data.filter(property => property.bathrooms >= params.bathrooms.from);
                }
                if (params.bathrooms.to) {
                    data = data.filter(property => property.bathrooms <= params.bathrooms.to);
                }
            }
            if (params.garages) {
                if (params.garages.from) {
                    data = data.filter(property => property.garages >= params.garages.from);
                }
                if (params.garages.to) {
                    data = data.filter(property => property.garages <= params.garages.to);
                }
            }
            if (params.area) {
                if (params.area.from) {
                    data = data.filter(property => property.area.value >= params.area.from);
                }
                if (params.area.to) {
                    data = data.filter(property => property.area.value <= params.area.to);
                }
            }
            if (params.yearBuilt) {
                if (params.yearBuilt.from) {
                    data = data.filter(property => property.yearBuilt >= params.yearBuilt.from);
                }
                if (params.yearBuilt.to) {
                    data = data.filter(property => property.yearBuilt <= params.yearBuilt.to);
                }
            }
            if (params.features) {
                let arr = [];
                params.features.forEach(feature => {
                    if (feature.selected)
                        arr.push(feature.name);
                });
                if (arr.length > 0) {
                    let properties = [];
                    data.filter(property => property.features.forEach(feature => {
                        if (arr.indexOf(feature) > -1) {
                            if (!properties.includes(property)) {
                                properties.push(property);
                            }
                        }
                    }));
                    data = properties;
                }
            }
        }
        // console.log(data)
        //for show more properties mock data 
        for (var index = 0; index < 2; index++) {
            data = data.concat(data);
        }
        this.sortData(sort, data);
        return this.paginator(data, page, perPage);
    }
    sortData(sort, data) {
        if (sort) {
            switch (sort) {
                case 'Newest':
                    data = data.sort((a, b) => { return new Date(b.published) - new Date(a.published); });
                    break;
                case 'Oldest':
                    data = data.sort((a, b) => { return new Date(a.published) - new Date(b.published); });
                    break;
                case 'Popular':
                    data = data.sort((a, b) => {
                        if (a.ratingsValue / a.ratingsCount < b.ratingsValue / b.ratingsCount) {
                            return 1;
                        }
                        if (a.ratingsValue / a.ratingsCount > b.ratingsValue / b.ratingsCount) {
                            return -1;
                        }
                        return 0;
                    });
                    break;
                case 'Price (Low to High)':
                    if (this.appSettings.settings.currency == 'USD') {
                        data = data.sort((a, b) => {
                            if ((a.priceDollar.sale || a.priceDollar.rent) > (b.priceDollar.sale || b.priceDollar.rent)) {
                                return 1;
                            }
                            if ((a.priceDollar.sale || a.priceDollar.rent) < (b.priceDollar.sale || b.priceDollar.rent)) {
                                return -1;
                            }
                            return 0;
                        });
                    }
                    if (this.appSettings.settings.currency == 'EUR') {
                        data = data.sort((a, b) => {
                            if ((a.priceEuro.sale || a.priceEuro.rent) > (b.priceEuro.sale || b.v.rent)) {
                                return 1;
                            }
                            if ((a.priceEuro.sale || a.priceEuro.rent) < (b.priceEuro.sale || b.priceEuro.rent)) {
                                return -1;
                            }
                            return 0;
                        });
                    }
                    break;
                case 'Price (High to Low)':
                    if (this.appSettings.settings.currency == 'USD') {
                        data = data.sort((a, b) => {
                            if ((a.priceDollar.sale || a.priceDollar.rent) < (b.priceDollar.sale || b.priceDollar.rent)) {
                                return 1;
                            }
                            if ((a.priceDollar.sale || a.priceDollar.rent) > (b.priceDollar.sale || b.priceDollar.rent)) {
                                return -1;
                            }
                            return 0;
                        });
                    }
                    if (this.appSettings.settings.currency == 'EUR') {
                        data = data.sort((a, b) => {
                            if ((a.priceEuro.sale || a.priceEuro.rent) < (b.priceEuro.sale || b.v.rent)) {
                                return 1;
                            }
                            if ((a.priceEuro.sale || a.priceEuro.rent) > (b.priceEuro.sale || b.priceEuro.rent)) {
                                return -1;
                            }
                            return 0;
                        });
                    }
                    break;
                default:
                    break;
            }
        }
        return data;
    }
    paginator(items, page, perPage) {
        var page = page || 1, perPage = perPage || 4, offset = (page - 1) * perPage, paginatedItems = items.slice(offset).slice(0, perPage), totalPages = Math.ceil(items.length / perPage);
        return {
            data: paginatedItems,
            pagination: {
                page: page,
                perPage: perPage,
                prePage: page - 1 ? page - 1 : null,
                nextPage: (totalPages > page) ? page + 1 : null,
                total: items.length,
                totalPages: totalPages,
            }
        };
    }
    getTestimonials() {
        return [
            {
                text: 'Donec molestie turpis ut mollis efficitur. Nam fringilla libero vel dictum vulputate. In malesuada, ligula non ornare consequat, augue nibh luctus nisl, et lobortis justo ipsum nec velit. Praesent lacinia quam ut nulla gravida, at viverra libero euismod. Sed tincidunt tempus augue vitae malesuada. Vestibulum eu lectus nisi. Aliquam erat volutpat.',
                author: 'Mr. Adam Sandler',
                position: 'General Director',
                image: 'assets/images/profile/adam.jpg'
            },
            {
                text: 'Donec molestie turpis ut mollis efficitur. Nam fringilla libero vel dictum vulputate. In malesuada, ligula non ornare consequat, augue nibh luctus nisl, et lobortis justo ipsum nec velit. Praesent lacinia quam ut nulla gravida, at viverra libero euismod. Sed tincidunt tempus augue vitae malesuada. Vestibulum eu lectus nisi. Aliquam erat volutpat.',
                author: 'Ashley Ahlberg',
                position: 'Housewife',
                image: 'assets/images/profile/ashley.jpg'
            },
            {
                text: 'Donec molestie turpis ut mollis efficitur. Nam fringilla libero vel dictum vulputate. In malesuada, ligula non ornare consequat, augue nibh luctus nisl, et lobortis justo ipsum nec velit. Praesent lacinia quam ut nulla gravida, at viverra libero euismod. Sed tincidunt tempus augue vitae malesuada. Vestibulum eu lectus nisi. Aliquam erat volutpat.',
                author: 'Bruno Vespa',
                position: 'Blogger',
                image: 'assets/images/profile/bruno.jpg'
            },
            {
                text: 'Donec molestie turpis ut mollis efficitur. Nam fringilla libero vel dictum vulputate. In malesuada, ligula non ornare consequat, augue nibh luctus nisl, et lobortis justo ipsum nec velit. Praesent lacinia quam ut nulla gravida, at viverra libero euismod. Sed tincidunt tempus augue vitae malesuada. Vestibulum eu lectus nisi. Aliquam erat volutpat.',
                author: 'Mrs. Julia Aniston',
                position: 'Marketing Manager',
                image: 'assets/images/profile/julia.jpg'
            }
        ];
    }
    getAgents() {
        return [
            {
                id: 1,
                fullName: 'Lusia Manuel',
                desc: 'Phasellus sed metus leo. Donec laoreet, lacus ut suscipit convallis, erat enim eleifend nulla, at sagittis enim urna et lacus.',
                organization: 'Homevoxx',
                email: 'lusia.m@homevoxx.com',
                phone: '(224) 267-1346',
                social: {
                    facebook: 'lusia',
                    twitter: 'lusia',
                    linkedin: 'lusia',
                    instagram: 'lusia',
                    website: 'https://lusia.manuel.com'
                },
                ratingsCount: 6,
                ratingsValue: 480,
                image: 'assets/images/agents/a-1.jpg'
            },
            {
                id: 2,
                fullName: 'Andy Warhol',
                desc: 'Phasellus sed metus leo. Donec laoreet, lacus ut suscipit convallis, erat enim eleifend nulla, at sagittis enim urna et lacus.',
                organization: 'Homevoxx',
                email: 'andy.w@homevoxx.com',
                phone: '(212) 457-2308',
                social: {
                    facebook: '',
                    twitter: '',
                    linkedin: '',
                    instagram: '',
                    website: 'https://andy.warhol.com'
                },
                ratingsCount: 4,
                ratingsValue: 400,
                image: 'assets/images/agents/a-2.jpg'
            },
            {
                id: 3,
                fullName: 'Tereza Stiles',
                desc: 'Phasellus sed metus leo. Donec laoreet, lacus ut suscipit convallis, erat enim eleifend nulla, at sagittis enim urna et lacus.',
                organization: 'Homevoxx',
                email: 'tereza.s@homevoxx.com',
                phone: '(214) 617-2614',
                social: {
                    facebook: '',
                    twitter: '',
                    linkedin: '',
                    instagram: '',
                    website: 'https://tereza.stiles.com'
                },
                ratingsCount: 4,
                ratingsValue: 380,
                image: 'assets/images/agents/a-3.jpg'
            },
            {
                id: 4,
                fullName: 'Michael Blair',
                desc: 'Phasellus sed metus leo. Donec laoreet, lacus ut suscipit convallis, erat enim eleifend nulla, at sagittis enim urna et lacus.',
                organization: 'Homevoxx',
                email: 'michael.b@homevoxx.com',
                phone: '(267) 388-1637',
                social: {
                    facebook: '',
                    twitter: '',
                    linkedin: '',
                    instagram: '',
                    website: 'https://michael.blair.com'
                },
                ratingsCount: 6,
                ratingsValue: 480,
                image: 'assets/images/agents/a-4.jpg'
            },
            {
                id: 5,
                fullName: 'Michelle Ormond',
                desc: 'Phasellus sed metus leo. Donec laoreet, lacus ut suscipit convallis, erat enim eleifend nulla, at sagittis enim urna et lacus.',
                organization: 'Homevoxx',
                email: 'michelle.o@homevoxx.com',
                phone: '(267) 388-1637',
                social: {
                    facebook: '',
                    twitter: '',
                    linkedin: '',
                    instagram: '',
                    website: 'https://michelle.ormond.com'
                },
                ratingsCount: 6,
                ratingsValue: 480,
                image: 'assets/images/agents/a-5.jpg'
            }
        ];
    }
    getClients() {
        return [
            { name: 'aloha', image: 'assets/images/clients/aloha.png' },
            { name: 'dream', image: 'assets/images/clients/dream.png' },
            { name: 'congrats', image: 'assets/images/clients/congrats.png' },
            { name: 'best', image: 'assets/images/clients/best.png' },
            { name: 'original', image: 'assets/images/clients/original.png' },
            { name: 'retro', image: 'assets/images/clients/retro.png' },
            { name: 'king', image: 'assets/images/clients/king.png' },
            { name: 'love', image: 'assets/images/clients/love.png' },
            { name: 'the', image: 'assets/images/clients/the.png' },
            { name: 'easter', image: 'assets/images/clients/easter.png' },
            { name: 'with', image: 'assets/images/clients/with.png' },
            { name: 'special', image: 'assets/images/clients/special.png' },
            { name: 'bravo', image: 'assets/images/clients/bravo.png' }
        ];
    }
};
AppService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
    { type: _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_2__["MatBottomSheet"] },
    { type: _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__["MatSnackBar"] },
    { type: _app_settings__WEBPACK_IMPORTED_MODULE_4__["AppSettings"] },
    { type: Object, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["PLATFORM_ID"],] }] }
];
AppService = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
        providedIn: 'root'
    }),
    __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
        _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_2__["MatBottomSheet"],
        _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_3__["MatSnackBar"],
        _app_settings__WEBPACK_IMPORTED_MODULE_4__["AppSettings"],
        Object])
], AppService);



/***/ }),

/***/ "./src/app/app.settings.ts":
/*!*********************************!*\
  !*** ./src/app/app.settings.ts ***!
  \*********************************/
/*! exports provided: Settings, AppSettings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Settings", function() { return Settings; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppSettings", function() { return AppSettings; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

class Settings {
    constructor(name, theme, toolbar, stickyMenuToolbar, header, rtl, searchPanelVariant, searchOnBtnClick, currency, locale, 
    // additional options
    mainToolbarFixed, contentOffsetToTop, headerBgImage, loadMore) {
        this.name = name;
        this.theme = theme;
        this.toolbar = toolbar;
        this.stickyMenuToolbar = stickyMenuToolbar;
        this.header = header;
        this.rtl = rtl;
        this.searchPanelVariant = searchPanelVariant;
        this.searchOnBtnClick = searchOnBtnClick;
        this.currency = currency;
        this.locale = locale;
        this.mainToolbarFixed = mainToolbarFixed;
        this.contentOffsetToTop = contentOffsetToTop;
        this.headerBgImage = headerBgImage;
        this.loadMore = loadMore;
    }
}
let AppSettings = class AppSettings {
    constructor() {
        this.settings = new Settings('Homevoxx', // theme name
        'blue', // blue, green, red, pink, purple, grey, orange-dark
        1, // 1 or 2
        true, // true = sticky, false = not sticky
        'image', // default, image, carousel
        false, // true = rtl, false = ltr
        1, //  1, 2  or 3
        false, //  true = search on button click
        'EUR', // USD, EUR
        'en', // en, de, fr, ru
        // NOTE:  don't change additional options values, they used for theme performance
        false, false, false, {
            start: false,
            step: 1,
            load: false,
            page: 1,
            complete: false,
            result: 0
        });
    }
};
AppSettings = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])()
], AppSettings);



/***/ }),

/***/ "./src/app/pages/lock-screen/lock-screen.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/pages/lock-screen/lock-screen.component.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".lock-screen {\n  position: relative;\n}\n.lock-screen:before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  z-index: -1;\n  width: 100%;\n  height: 100%;\n  background-image: url('default-bg.png');\n  background-repeat: repeat;\n  background-size: 350px;\n  background-position: center;\n  opacity: 1;\n}\n.lock-screen form {\n  position: relative;\n}\n.lock-screen form .name {\n  position: absolute;\n  top: -2px;\n  right: 0;\n  text-transform: uppercase;\n  font-weight: 600;\n}\n.lock-screen form img {\n  border-radius: 50%;\n  width: 90px;\n  height: 90px;\n  border: 8px solid #fff;\n}\n.lock-screen form input {\n  background: #fff;\n  padding: 16px 44px 16px 16px;\n  width: 140px;\n  margin-left: -6px;\n  border: 0;\n  border-top-right-radius: 3px;\n  border-bottom-right-radius: 3px;\n  text-align: center;\n  outline: none;\n  box-shadow: 4px 0px 4px -2px rgba(0, 0, 0, 0.2), 4px 3px 4px 0px rgba(0, 0, 0, 0.14), 4px 1px 4px 0px rgba(0, 0, 0, 0.12);\n}\n.lock-screen form a {\n  position: absolute;\n  bottom: -8px;\n  right: -8px;\n  margin: 0;\n  font-size: 13px;\n}\n.lock-screen form button.submit {\n  margin-left: -44px;\n}\n.lock-screen p.time {\n  font-size: 48px;\n  margin-top: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbG9jay1zY3JlZW4vbG9jay1zY3JlZW4uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtBQUNKO0FBQUk7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxNQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsdUNBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0EsMkJBQUE7RUFDQSxVQUFBO0FBRVI7QUFBSTtFQUNJLGtCQUFBO0FBRVI7QUFEUTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0FBR1o7QUFEUTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtBQUdaO0FBRFE7RUFDSSxnQkFBQTtFQUNBLDRCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsU0FBQTtFQUNBLDRCQUFBO0VBQ0EsK0JBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSx5SEFBQTtBQUdaO0FBQ1E7RUFDSSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7QUFDWjtBQUNRO0VBQ0ksa0JBQUE7QUFDWjtBQUVJO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0FBQVIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9sb2NrLXNjcmVlbi9sb2NrLXNjcmVlbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sb2NrLXNjcmVlbntcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgJjpiZWZvcmV7ICAgICAgICBcbiAgICAgICAgY29udGVudDogJyc7ICAgICAgICBcbiAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XG4gICAgICAgIHRvcDogMDtcbiAgICAgICAgei1pbmRleDotMTtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogMTAwJTsgIFxuICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uLy4uL2Fzc2V0cy9pbWFnZXMvb3RoZXJzL2RlZmF1bHQtYmcucG5nJyk7XG4gICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiByZXBlYXQ7XG4gICAgICAgIGJhY2tncm91bmQtc2l6ZTogMzUwcHg7XG4gICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgICAgICAgb3BhY2l0eTogMTsgXG4gICAgfSBcbiAgICBmb3Jte1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIC5uYW1le1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgdG9wOiAtMnB4O1xuICAgICAgICAgICAgcmlnaHQ6IDA7XG4gICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgICAgfVxuICAgICAgICBpbWd7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgICB3aWR0aDogOTBweDtcbiAgICAgICAgICAgIGhlaWdodDogOTBweDtcbiAgICAgICAgICAgIGJvcmRlcjogOHB4IHNvbGlkICNmZmY7XG4gICAgICAgIH1cbiAgICAgICAgaW5wdXR7IFxuICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICAgICAgICAgIHBhZGRpbmc6IDE2cHggNDRweCAxNnB4IDE2cHg7XG4gICAgICAgICAgICB3aWR0aDogMTQwcHg7IFxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IC02cHg7XG4gICAgICAgICAgICBib3JkZXI6IDA7XG4gICAgICAgICAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogM3B4O1xuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDNweDtcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgICAgIG91dGxpbmU6IG5vbmU7XG4gICAgICAgICAgICBib3gtc2hhZG93OiA0cHggMHB4IDRweCAtMnB4IHJnYmEoMCwgMCwgMCwgMC4yKSwgXG4gICAgICAgICAgICAgICAgICAgICAgICA0cHggM3B4IDRweCAwcHggcmdiYSgwLCAwLCAwLCAwLjE0KSxcbiAgICAgICAgICAgICAgICAgICAgICAgIDRweCAxcHggNHB4IDBweCByZ2JhKDAsIDAsIDAsIDAuMTIpO1xuICAgICAgICB9XG4gICAgICAgIGF7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICBib3R0b206IC04cHg7XG4gICAgICAgICAgICByaWdodDogLThweDtcbiAgICAgICAgICAgIG1hcmdpbjogMDsgXG4gICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAgIH0gICAgICAgIFxuICAgICAgICBidXR0b24uc3VibWl0e1xuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IC00NHB4O1xuICAgICAgICB9XG4gICAgfVxuICAgIHAudGltZXtcbiAgICAgICAgZm9udC1zaXplOiA0OHB4OyBcbiAgICAgICAgbWFyZ2luLXRvcDogMTZweDsgIFxuICAgIH0gXG59ICJdfQ== */");

/***/ }),

/***/ "./src/app/pages/lock-screen/lock-screen.component.ts":
/*!************************************************************!*\
  !*** ./src/app/pages/lock-screen/lock-screen.component.ts ***!
  \************************************************************/
/*! exports provided: LockScreenComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LockScreenComponent", function() { return LockScreenComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



let LockScreenComponent = class LockScreenComponent {
    constructor(fb, router) {
        this.fb = fb;
        this.router = router;
        this.date = new Date();
    }
    ngOnInit() {
        this.timerInterval = setInterval(() => {
            this.date = new Date();
        }, 1000);
        this.form = this.fb.group({
            password: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3)])]
        });
    }
    ngAfterViewInit() {
        document.getElementById('preloader').classList.add('hide');
    }
    ngOnDestroy() {
        clearInterval(this.timerInterval);
    }
    onSubmit(values) {
        if (this.form.valid) {
            this.router.navigate(['/']);
        }
    }
};
LockScreenComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
];
LockScreenComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-lock-screen',
        template: __importDefault(__webpack_require__(/*! raw-loader!./lock-screen.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/lock-screen/lock-screen.component.html")).default,
        encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewEncapsulation"].None,
        styles: [__importDefault(__webpack_require__(/*! ./lock-screen.component.scss */ "./src/app/pages/lock-screen/lock-screen.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
], LockScreenComponent);



/***/ }),

/***/ "./src/app/pages/not-found/not-found.component.scss":
/*!**********************************************************!*\
  !*** ./src/app/pages/not-found/not-found.component.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".box {\n  border-radius: 0;\n}\n.box .box-header {\n  height: 180px;\n}\n.box .box-header .error {\n  font-size: 48px;\n  margin-bottom: 12px;\n}\n.box .box-content {\n  position: relative;\n  height: 180px;\n}\n.box .box-content .box-content-inner {\n  position: absolute;\n  top: -34px;\n  left: 34px;\n  right: 34px;\n  height: 180px;\n}\n.box .box-content .box-content-header {\n  font-size: 16px;\n  text-transform: uppercase;\n  font-weight: 500;\n}\n.box .box-content .box-content-header.server-error {\n  margin-bottom: 36px;\n}\n.box .box-content .box-text {\n  margin-bottom: 10px;\n  text-align: center;\n}\n.box .box-content .box-text::last-child {\n  margin-bottom: 15px;\n}\n.box .box-content .box-footer {\n  position: relative;\n  bottom: 16px;\n}\n.box .box-content .box-footer button {\n  min-width: 70px;\n  margin: 0 2px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbm90LWZvdW5kL25vdC1mb3VuZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0FBQ0o7QUFBSTtFQUNJLGFBQUE7QUFFUjtBQURRO0VBQ0ksZUFBQTtFQUNBLG1CQUFBO0FBR1o7QUFBSTtFQUNJLGtCQUFBO0VBQ0EsYUFBQTtBQUVSO0FBRFE7RUFDSSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7QUFHWjtBQURRO0VBQ0ksZUFBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7QUFHWjtBQUZZO0VBQ0ksbUJBQUE7QUFJaEI7QUFEUTtFQUNJLG1CQUFBO0VBQ0Esa0JBQUE7QUFHWjtBQUZZO0VBQ0ksbUJBQUE7QUFJaEI7QUFEUTtFQUNJLGtCQUFBO0VBQ0EsWUFBQTtBQUdaO0FBRlk7RUFDSSxlQUFBO0VBQ0EsYUFBQTtBQUloQiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL25vdC1mb3VuZC9ub3QtZm91bmQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYm94e1xuICAgIGJvcmRlci1yYWRpdXM6IDA7XG4gICAgLmJveC1oZWFkZXJ7XG4gICAgICAgIGhlaWdodDogMTgwcHg7XG4gICAgICAgIC5lcnJvcntcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogNDhweDtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEycHg7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLmJveC1jb250ZW50e1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIGhlaWdodDogMTgwcHg7ICAgICBcbiAgICAgICAgLmJveC1jb250ZW50LWlubmVye1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgdG9wOiAtMzRweDtcbiAgICAgICAgICAgIGxlZnQ6IDM0cHg7XG4gICAgICAgICAgICByaWdodDogMzRweDtcbiAgICAgICAgICAgIGhlaWdodDogMTgwcHg7XG4gICAgICAgIH1cbiAgICAgICAgLmJveC1jb250ZW50LWhlYWRlcntcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDsgXG4gICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6NTAwO1xuICAgICAgICAgICAgJi5zZXJ2ZXItZXJyb3J7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMzZweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAuYm94LXRleHR7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICAgICAgJjo6bGFzdC1jaGlsZHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC5ib3gtZm9vdGVye1xuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAgICAgYm90dG9tOiAxNnB4O1xuICAgICAgICAgICAgYnV0dG9ue1xuICAgICAgICAgICAgICAgIG1pbi13aWR0aDogNzBweDtcbiAgICAgICAgICAgICAgICBtYXJnaW46IDAgMnB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/not-found/not-found.component.ts":
/*!********************************************************!*\
  !*** ./src/app/pages/not-found/not-found.component.ts ***!
  \********************************************************/
/*! exports provided: NotFoundComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotFoundComponent", function() { return NotFoundComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let NotFoundComponent = class NotFoundComponent {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    goHome() {
        this.router.navigate(['/']);
    }
    ngAfterViewInit() {
        document.getElementById('preloader').classList.add('hide');
    }
};
NotFoundComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
];
NotFoundComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-not-found',
        template: __importDefault(__webpack_require__(/*! raw-loader!./not-found.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/not-found/not-found.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./not-found.component.scss */ "./src/app/pages/not-found/not-found.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
], NotFoundComponent);



/***/ }),

/***/ "./src/app/pages/pages.component.scss":
/*!********************************************!*\
  !*** ./src/app/pages/pages.component.scss ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".sidenav {\n  position: fixed;\n  z-index: 999999;\n  width: 250px;\n  padding: 8px 16px;\n  bottom: 0;\n  top: 0;\n}\n.sidenav .close {\n  margin-left: 178px;\n}\n.sidenav .divider {\n  margin: 8px 0;\n}\n.sidenav .vertical-menu-wrapper {\n  height: calc(100% - 122px);\n}\n.options {\n  position: fixed;\n  width: 270px;\n  z-index: 999999;\n}\n.options .op-header {\n  height: 64px;\n  padding: 0 14px;\n}\n.options .control {\n  padding: 6px 14px;\n}\n.options .control div {\n  padding: 6px 0;\n}\n.options .control h4 {\n  border-bottom: 1px solid #ccc;\n  margin: 12px 0 6px 0;\n}\n.options .control .skin-primary {\n  width: 24px;\n  height: 24px;\n  padding: 0;\n  overflow: hidden;\n  cursor: pointer;\n}\n.options .control .skin-primary .skin-secondary {\n  width: 0;\n  height: 0;\n  padding: 0;\n  border-bottom: 24px solid;\n  border-left: 24px solid transparent;\n}\n.options .control .skin-primary.blue {\n  background-color: #1976d2;\n  border: 1px solid #1976d2;\n}\n.options .control .skin-primary.green {\n  background-color: #689f38;\n  border: 1px solid #689f38;\n}\n.options .control .skin-primary.red {\n  background-color: #d32f2f;\n  border: 1px solid #d32f2f;\n}\n.options .control .skin-primary.pink {\n  background-color: #c2185b;\n  border: 1px solid #c2185b;\n}\n.options .control .skin-primary.purple {\n  background-color: #7b1fa2;\n  border: 1px solid #7b1fa2;\n}\n.options .control .skin-primary.grey {\n  background-color: #455a64;\n  border: 1px solid #455a64;\n}\n.options .control .skin-primary.orange-dark {\n  background-color: #f4511e;\n  border: 1px solid #f4511e;\n}\n.options .control .skin-primary.orange-dark .skin-secondary {\n  border-bottom-color: #303030;\n}\n.options .mat-radio-group {\n  display: inline-flex;\n  flex-direction: column;\n}\n.options .mat-radio-group .mat-radio-button {\n  margin: 2px 0;\n}\n.options .mat-slide-toggle {\n  height: auto;\n}\n.options .ps {\n  height: calc(100% - 64px);\n}\n.op-image {\n  box-shadow: 0 0 2px #ccc;\n  border: 2px solid;\n  border-color: transparent;\n  cursor: pointer;\n  transition: 0.2s;\n}\n.options-icon {\n  position: fixed;\n  top: 200px;\n  right: 0;\n  width: 40px;\n  height: 40px;\n  background: rgba(0, 0, 0, 0.7);\n  color: #fff;\n  cursor: pointer;\n  z-index: 99999;\n}\n.options-icon .mat-icon {\n  -webkit-animation: spin 8s linear infinite;\n  animation: spin 8s linear infinite;\n}\n@-webkit-keyframes spin {\n  100% {\n    -webkit-transform: rotate(360deg);\n  }\n}\n@keyframes spin {\n  100% {\n    transform: rotate(360deg);\n  }\n}\n.back-to-top {\n  position: fixed;\n  width: 40px;\n  height: 40px;\n  cursor: pointer;\n  z-index: 999999;\n  right: 20px;\n  bottom: 20px;\n  opacity: 0.5;\n  color: #fff;\n  background-color: rgba(0, 0, 0, 0.75);\n  border-radius: 50%;\n  transition: 0.3s;\n}\n.back-to-top:hover {\n  opacity: 0.9;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcGFnZXMuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3RoZW1lL3N0eWxlcy9fdmFyaWFibGVzLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDSSxlQUFBO0VBQ0EsZUFBQTtFQUNBLFlDSWlCO0VESGpCLGlCQUFBO0VBQ0EsU0FBQTtFQUNBLE1BQUE7QUFESjtBQUVJO0VBQ0ksa0JBQUE7QUFBUjtBQUVJO0VBQ0ksYUFBQTtBQUFSO0FBRUk7RUFDSSwwQkFBQTtBQUFSO0FBSUE7RUFDSSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUFESjtBQUVJO0VBQ0ksWUFBQTtFQUNBLGVBQUE7QUFBUjtBQUVJO0VBQ0ksaUJBQUE7QUFBUjtBQUNRO0VBQ0ksY0FBQTtBQUNaO0FBQ1E7RUFDSSw2QkFBQTtFQUNBLG9CQUFBO0FBQ1o7QUFDUTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUNaO0FBQVk7RUFDSSxRQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSx5QkFBQTtFQUNBLG1DQUFBO0FBRWhCO0FBQVk7RUFDSSx5QkFBQTtFQUNBLHlCQUFBO0FBRWhCO0FBQVk7RUFDSSx5QkFBQTtFQUNBLHlCQUFBO0FBRWhCO0FBQVk7RUFDSSx5QkFBQTtFQUNBLHlCQUFBO0FBRWhCO0FBQVk7RUFDSSx5QkFBQTtFQUNBLHlCQUFBO0FBRWhCO0FBQVk7RUFDSSx5QkFBQTtFQUNBLHlCQUFBO0FBRWhCO0FBQVk7RUFDSSx5QkFBQTtFQUNBLHlCQUFBO0FBRWhCO0FBQVk7RUFDSSx5QkFBQTtFQUNBLHlCQUFBO0FBRWhCO0FBRGdCO0VBQ0ksNEJBQUE7QUFHcEI7QUFFSTtFQUNJLG9CQUFBO0VBQ0Esc0JBQUE7QUFBUjtBQUNRO0VBQ0ksYUFBQTtBQUNaO0FBRUk7RUFDSSxZQUFBO0FBQVI7QUFFSTtFQUNFLHlCQUFBO0FBQU47QUFHQTtFQUNJLHdCQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQUFKO0FBRUE7RUFDSSxlQUFBO0VBQ0EsVUFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLDhCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FBQ0o7QUFBSTtFQUNJLDBDQUFBO0VBRUEsa0NBQUE7QUFFUjtBQU9BO0VBQ0k7SUFDSSxpQ0FBQTtFQUNOO0FBQ0Y7QUFDQTtFQUNJO0lBQ0kseUJBQUE7RUFDTjtBQUNGO0FBRUE7RUFDSSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxxQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFBSjtBQUNJO0VBQ0ksWUFBQTtBQUNSIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvcGFnZXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0IFwiLi4vdGhlbWUvc3R5bGVzL3ZhcmlhYmxlc1wiO1xuXG4uc2lkZW5hdntcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgei1pbmRleDogOTk5OTk5O1xuICAgIHdpZHRoOiAkbWFpbi1zaWRlbmF2LXdpZHRoO1xuICAgIHBhZGRpbmc6IDhweCAxNnB4O1xuICAgIGJvdHRvbTogMDtcbiAgICB0b3A6IDA7XG4gICAgLmNsb3Nle1xuICAgICAgICBtYXJnaW4tbGVmdDogMTc4cHg7XG4gICAgfVxuICAgIC5kaXZpZGVye1xuICAgICAgICBtYXJnaW46IDhweCAwO1xuICAgIH1cbiAgICAudmVydGljYWwtbWVudS13cmFwcGVye1xuICAgICAgICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDEyMnB4KTtcbiAgICB9XG59XG5cbi5vcHRpb25ze1xuICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICB3aWR0aDogMjcwcHg7XG4gICAgei1pbmRleDogOTk5OTk5O1xuICAgIC5vcC1oZWFkZXJ7XG4gICAgICAgIGhlaWdodDogNjRweDtcbiAgICAgICAgcGFkZGluZzogMCAxNHB4O1xuICAgIH1cbiAgICAuY29udHJvbHtcbiAgICAgICAgcGFkZGluZzogNnB4IDE0cHg7XG4gICAgICAgIGRpdntcbiAgICAgICAgICAgIHBhZGRpbmc6IDZweCAwO1xuICAgICAgICB9XG4gICAgICAgIGg0e1xuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjY2M7XG4gICAgICAgICAgICBtYXJnaW46IDEycHggMCA2cHggMDtcbiAgICAgICAgfSAgICAgICAgXG4gICAgICAgIC5za2luLXByaW1hcnl7XG4gICAgICAgICAgICB3aWR0aDogMjRweDtcbiAgICAgICAgICAgIGhlaWdodDogMjRweDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuOyAgICAgICAgICAgIFxuICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyOyAgXG4gICAgICAgICAgICAuc2tpbi1zZWNvbmRhcnl7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDA7IFxuICAgICAgICAgICAgICAgIGhlaWdodDogMDsgXG4gICAgICAgICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiAyNHB4IHNvbGlkOyBcbiAgICAgICAgICAgICAgICBib3JkZXItbGVmdDogMjRweCBzb2xpZCB0cmFuc3BhcmVudDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgICYuYmx1ZXtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTk3NmQyO1xuICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICMxOTc2ZDI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAmLmdyZWVue1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICM2ODlmMzg7XG4gICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgIzY4OWYzODtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgICYucmVke1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNkMzJmMmY7XG4gICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2QzMmYyZjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgICYucGlua3tcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYzIxODViO1xuICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNjMjE4NWI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAmLnB1cnBsZXtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjN2IxZmEyO1xuICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICM3YjFmYTI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAmLmdyZXl7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzQ1NWE2NDtcbiAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjNDU1YTY0O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgJi5vcmFuZ2UtZGFya3tcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjQ1MTFlO1xuICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNmNDUxMWU7XG4gICAgICAgICAgICAgICAgLnNraW4tc2Vjb25kYXJ5e1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tLWNvbG9yOiAjMzAzMDMwO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICAubWF0LXJhZGlvLWdyb3Vwe1xuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgLm1hdC1yYWRpby1idXR0b257XG4gICAgICAgICAgICBtYXJnaW46IDJweCAwO1xuICAgICAgICB9XG4gICAgfVxuICAgIC5tYXQtc2xpZGUtdG9nZ2xle1xuICAgICAgICBoZWlnaHQ6IGF1dG87XG4gICAgfVxuICAgIC5wc3tcbiAgICAgIGhlaWdodDogY2FsYygxMDAlIC0gNjRweCk7XG4gICAgfVxufVxuLm9wLWltYWdle1xuICAgIGJveC1zaGFkb3c6IDAgMCAycHggI2NjYztcbiAgICBib3JkZXI6IDJweCBzb2xpZDtcbiAgICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB0cmFuc2l0aW9uOiAwLjJzO1xufVxuLm9wdGlvbnMtaWNvbntcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgdG9wOiAyMDBweDtcbiAgICByaWdodDogMDtcbiAgICB3aWR0aDogNDBweDtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgYmFja2dyb3VuZDogcmdiYSgwLDAsMCwuNyk7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHotaW5kZXg6IDk5OTk5O1xuICAgIC5tYXQtaWNvbntcbiAgICAgICAgLXdlYmtpdC1hbmltYXRpb246IHNwaW4gOHMgbGluZWFyIGluZmluaXRlO1xuICAgICAgICAtbW96LWFuaW1hdGlvbjogc3BpbiA4cyBsaW5lYXIgaW5maW5pdGU7XG4gICAgICAgIGFuaW1hdGlvbjogc3BpbiA4cyBsaW5lYXIgaW5maW5pdGU7XG4gICAgfVxufVxuXG5ALW1vei1rZXlmcmFtZXMgc3BpbiB7IFxuICAgIDEwMCUgeyBcbiAgICAgICAgLW1vei10cmFuc2Zvcm06IHJvdGF0ZSgzNjBkZWcpOyBcbiAgICB9IFxufVxuQC13ZWJraXQta2V5ZnJhbWVzIHNwaW4geyBcbiAgICAxMDAlIHsgXG4gICAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoMzYwZGVnKTsgXG4gICAgfSBcbn1cbkBrZXlmcmFtZXMgc3BpbiB7IFxuICAgIDEwMCUgeyBcbiAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMzYwZGVnKTtcbiAgICB9XG59XG5cbi5iYWNrLXRvLXRvcHtcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgd2lkdGg6IDQwcHg7XG4gICAgaGVpZ2h0OiA0MHB4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB6LWluZGV4OiA5OTk5OTk7XG4gICAgcmlnaHQ6IDIwcHg7XG4gICAgYm90dG9tOiAyMHB4O1xuICAgIG9wYWNpdHk6IC41O1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwwLDAsLjc1KTtcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgdHJhbnNpdGlvbjogMC4zczsgICAgXG4gICAgJjpob3ZlcntcbiAgICAgICAgb3BhY2l0eTogMC45O1xuICAgIH0gICAgXG59XG5cblxuIiwiJGZvbnQtZmFtaWx5OiAnTW9udHNlcnJhdCc7XG4kdGhlbWUtbWF4LXdpZHRoOiAxMzAwcHg7XG4kdG9wLXRvb2xiYXItaGVpZ2h0OiAzNnB4O1xuJG1haW4tdG9vbGJhci1oZWlnaHQ6IDcycHg7XG4kdXNlci1tZW51LXdpZHRoOiAyMjBweDtcbiRoZWFkZXItaW1hZ2UtbWluLWhlaWdodDogMzIwcHg7XG4kaGVhZGVyLWNhcm91c2VsLWhlaWdodDogNDYwcHg7XG4kbWFpbi1jb250ZW50LWhlYWRlci1vZmZzZXQtdG8tdG9wOiA4MHB4O1xuXG4kbWFpbi1zaWRlbmF2LXdpZHRoOiAyNTBweDtcbiRzZWFyY2gtc2lkZW5hdi13aWR0aDogMjg4cHg7Il19 */");

/***/ }),

/***/ "./src/app/pages/pages.component.ts":
/*!******************************************!*\
  !*** ./src/app/pages/pages.component.ts ***!
  \******************************************/
/*! exports provided: PagesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagesComponent", function() { return PagesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _app_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app.settings */ "./src/app/app.settings.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




let PagesComponent = class PagesComponent {
    constructor(appSettings, router, platformId) {
        this.appSettings = appSettings;
        this.router = router;
        this.platformId = platformId;
        this.toolbarTypes = [1, 2];
        this.headerTypes = ['default', 'image', 'carousel'];
        this.searchPanelVariants = [1, 2, 3];
        this.headerFixed = false;
        this.showBackToTop = false;
        this.scrolledCount = 0;
        this.settings = this.appSettings.settings;
    }
    ngOnInit() {
        this.toolbarTypeOption = this.settings.toolbar;
        this.headerTypeOption = this.settings.header;
        this.searchPanelVariantOption = this.settings.searchPanelVariant;
    }
    changeTheme(theme) {
        this.settings.theme = theme;
    }
    chooseToolbarType() {
        this.settings.toolbar = this.toolbarTypeOption;
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
            window.scrollTo(0, 0);
        }
    }
    chooseHeaderType() {
        this.settings.header = this.headerTypeOption;
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
            window.scrollTo(0, 0);
        }
        this.router.navigate(['/']);
    }
    chooseSearchPanelVariant() {
        this.settings.searchPanelVariant = this.searchPanelVariantOption;
    }
    onWindowScroll() {
        const scrollTop = Math.max(window.pageYOffset, document.documentElement.scrollTop, document.body.scrollTop);
        (scrollTop > 300) ? this.showBackToTop = true : this.showBackToTop = false;
        if (this.settings.stickyMenuToolbar) {
            let top_toolbar = document.getElementById('top-toolbar');
            if (top_toolbar) {
                if (scrollTop >= top_toolbar.clientHeight) {
                    this.settings.mainToolbarFixed = true;
                }
                else {
                    this.settings.mainToolbarFixed = false;
                }
            }
        }
        // let load_more = document.getElementById('load-more');
        // if(load_more){
        //   if(window.innerHeight > load_more.getBoundingClientRect().top + 120){ 
        //     if(!this.settings.loadMore.complete){
        //       if(this.settings.loadMore.start){        
        //         if(this.scrolledCount < this.settings.loadMore.step){  
        //           this.scrolledCount++; 
        //           if(!this.settings.loadMore.load){ 
        //             this.settings.loadMore.load = true; 
        //           }
        //         }
        //         else{
        //           this.settings.loadMore.start = false;
        //           this.scrolledCount = 0;
        //         }
        //       }  
        //     }              
        //   }
        // }
    }
    scrollToTop() {
        var scrollDuration = 200;
        var scrollStep = -window.pageYOffset / (scrollDuration / 20);
        var scrollInterval = setInterval(() => {
            if (window.pageYOffset != 0) {
                window.scrollBy(0, scrollStep);
            }
            else {
                clearInterval(scrollInterval);
            }
        }, 10);
        if (window.innerWidth <= 768) {
            setTimeout(() => {
                if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
                    window.scrollTo(0, 0);
                }
            });
        }
    }
    ngAfterViewInit() {
        document.getElementById('preloader').classList.add('hide');
        this.router.events.subscribe(event => {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_1__["NavigationEnd"]) {
                this.sidenav.close();
                this.settings.mainToolbarFixed = false;
                setTimeout(() => {
                    if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_3__["isPlatformBrowser"])(this.platformId)) {
                        window.scrollTo(0, 0);
                    }
                });
            }
        });
    }
};
PagesComponent.ctorParameters = () => [
    { type: _app_settings__WEBPACK_IMPORTED_MODULE_2__["AppSettings"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
    { type: Object, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["PLATFORM_ID"],] }] }
];
PagesComponent.propDecorators = {
    sidenav: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"], args: ['sidenav',] }],
    onWindowScroll: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"], args: ['window:scroll',] }]
};
PagesComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-pages',
        template: __importDefault(__webpack_require__(/*! raw-loader!./pages.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pages.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./pages.component.scss */ "./src/app/pages/pages.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_app_settings__WEBPACK_IMPORTED_MODULE_2__["AppSettings"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
        Object])
], PagesComponent);



/***/ }),

/***/ "./src/app/services/auth-guard.service.ts":
/*!************************************************!*\
  !*** ./src/app/services/auth-guard.service.ts ***!
  \************************************************/
/*! exports provided: AuthGuardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuardService", function() { return AuthGuardService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth.service */ "./src/app/services/auth.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




let AuthGuardService = class AuthGuardService {
    constructor(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    canActivate(next, state) {
        return this.authService.isLoggedIn.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((isLoggedIn) => {
            if (!isLoggedIn) {
                this.router.navigate(['/login']);
                return false;
            }
            return true;
        }));
    }
};
AuthGuardService.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
];
AuthGuardService = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
    __metadata("design:paramtypes", [_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
], AuthGuardService);



/***/ }),

/***/ "./src/app/services/auth.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




let AuthService = class AuthService {
    /**
     * Constructor
     * @param http The http client object
     */
    constructor(http) {
        this.http = http;
        // Variables
        this.loggedIn = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"](false);
        this.authUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + '/api/v1/user-login';
        this.sendResetLinkEmailUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + '/api/v1/password/email';
        this.resetUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + '/api/v1/password/reset';
        this.apiUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + '/api/v1';
        this.options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                Accept: 'application/json',
                'Content-Type': 'application/json'
            })
        };
    }
    get isLoggedIn() {
        return this.loggedIn.asObservable();
    }
    /**
     * Get an access token
     * @param e The email address
     * @param p The password string
     */
    login(e, p) {
        return this.http.post(this.authUrl, {
            email: e,
            password: p
        }, this.options);
    }
    /**
     * Send reset password link
     * @param e The email address
     */
    sendResetLinkEmail(e) {
        return this.http.post(this.sendResetLinkEmailUrl, {
            email: e
        }, this.options);
    }
    /**
     * Reset password
     * @param t The token
     * @param e The email address
     * @param p The password
     * @param pc The password_confirmation
     */
    reset(t, e, p, pc) {
        return this.http.post(this.resetUrl, {
            token: t,
            email: e,
            password: p,
            password_confirmation: pc,
        }, this.options);
    }
    /**
     * Get an access token
     * @param n The name
     * @param e The email address
     * @param p The password string
     * @param pc The password_confirmation string
     */
    register(n, e, p, pc) {
        return this.http.post(this.apiUrl + '/user-register', {
            name: n,
            email: e,
            password: p,
            password_confirmation: pc
        }, this.options);
    }
    /**
     * Revoke the authenticated user token
     */
    logout() {
        this.options.headers.append('Authorization', 'Bearer ' + localStorage.getItem('access_token'));
        return this.http.delete(this.apiUrl + '/logout', this.options);
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
];
AuthService = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
        providedIn: 'root'
    }),
    __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
], AuthService);



/***/ }),

/***/ "./src/app/services/guest-guard.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/guest-guard.service.ts ***!
  \*************************************************/
/*! exports provided: GuestGuardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GuestGuardService", function() { return GuestGuardService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth.service */ "./src/app/services/auth.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




let GuestGuardService = class GuestGuardService {
    constructor(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    canActivate(next, state) {
        return this.authService.isLoggedIn.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((isLoggedIn) => {
            if (isLoggedIn) {
                this.router.navigate(['/']);
                return false;
            }
            return true;
        }));
    }
};
GuestGuardService.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
];
GuestGuardService = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
    __metadata("design:paramtypes", [_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
], GuestGuardService);



/***/ }),

/***/ "./src/app/services/temporary-storage.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/services/temporary-storage.service.ts ***!
  \*******************************************************/
/*! exports provided: TemporaryStorageService, TemporaryStorageFacet */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TemporaryStorageService", function() { return TemporaryStorageService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TemporaryStorageFacet", function() { return TemporaryStorageFacet; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// Import the core angular services.


let TemporaryStorageService = class TemporaryStorageService {
    // I initialize the temporary storage service, which can act as a sort of "flash
    // memory", persisting data across page-refreshes (if the underlying technologies
    // are available).
    constructor(zone) {
        // Since the type of storage may vary from browser to browser, I'm wrapping the
        // different technologies in abstractions that all expose the same, simple API.
        this.storage = (window.sessionStorage)
            ? new SessionStorageWrapper(zone)
            : new InMemoryWrapper();
    }
    // ---
    // PUBLIC METHODS.
    // ---
    // I provide a Facet of the temporary storage associated with the given key. A facet
    // provides a simplified interaction model for a calling context that wants to get
    // a slice of the temporary storage for a given UI, interact with it briefly, and
    // then clear it when its done using it.
    forKey(key) {
        return (new TemporaryStorageFacet(key, this.storage));
    }
    // I get the data associated with the given key.
    get(key) {
        return (this.storage.get(key));
    }
    // I remove the data associated with the given key.
    remove(key) {
        this.storage.remove(key);
    }
    // I store the given value with the given key.
    set(key, value) {
        this.storage.set(key, value);
    }
};
TemporaryStorageService.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"] }
];
TemporaryStorageService = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
        providedIn: "root"
    }),
    __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]])
], TemporaryStorageService);

// ----------------------------------------------------------------------------------- //
// ----------------------------------------------------------------------------------- //
class TemporaryStorageFacet {
    // I initialize the temporary storage facet that is locked-in to the given key.
    constructor(key, storage) {
        this.key = key;
        this.storage = storage;
    }
    // ---
    // PUBLC METHODS.
    // ---
    // I get the data associated with the locked-in key; or, null if the data has not
    // been defined (set).
    get() {
        return (this.storage.get(this.key));
    }
    // I remove the data associated with the locked-in key.
    remove() {
        this.storage.remove(this.key);
    }
    // I store the given value with the locked-in key.
    set(value) {
        this.storage.set(this.key, value);
    }
}
// ----------------------------------------------------------------------------------- //
// ----------------------------------------------------------------------------------- //
class SessionStorageWrapper {
    // I initialize an SessionStorage API implementation of the storage wrapper.
    constructor(zone) {
        this.zone = zone;
        this.cache = Object.create(null);
        this.storageKey = "temp_session_storage";
        // The Debounce duration is the trade-off between processing and consistency.
        // Since the SessionStorage API is synchronous, we don't necessarily want to
        // write to it whenever the cache is updated. Instead, we'll use a timerID to reach
        // a moment of inactivity; and then, serialize and persist the data.
        this.debounceDuration = 1000; // 1-second.
        this.timerID = null;
        // NOTE: Since the SessionStorage API is browser-TAB-specific, we can read the
        // persisted data into memory on load; and, then use the in-memory cache as a
        // buffer in order to cut-down on synchronous processing.
        this.loadFromCache();
    }
    // ---
    // PUBLIC METHODS.
    // ---
    // I get the value associated with the given key; or null if the key is undefined.
    get(key) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            return ((_a = this.cache[key]) !== null && _a !== void 0 ? _a : null);
        });
    }
    // I remove any value associated with the given key.
    remove(key) {
        if (key in this.cache) {
            delete (this.cache[key]);
            this.persistToCache();
        }
    }
    // I store the given value with the given key.
    set(key, value) {
        this.cache[key] = value;
        this.persistToCache();
    }
    // ---
    // PRIVATE METHOD.
    // ---
    // I debounce invocations of the given callback outside of the Angular zone.
    debounceOutsideNgZone(callback) {
        this.zone.runOutsideAngular(() => {
            clearTimeout(this.timerID);
            this.timerID = setTimeout(() => {
                this.timerID = null;
                callback();
            }, this.debounceDuration);
        });
    }
    // I load the SessionStorage payload into the internal cache so that we don't need
    // to read from the SessionStorage whenever the .get() method is called.
    loadFromCache() {
        try {
            var serializedCache = sessionStorage.getItem(this.storageKey);
            if (serializedCache) {
                Object.assign(this.cache, JSON.parse(serializedCache));
            }
        }
        catch (error) {
            console.warn("SessionStorageWrapper was unable to read from SessionStorage API.");
            console.error(error);
        }
    }
    // I serialize and persist the cache to the SessionStorage, using debouncing.
    persistToCache() {
        // Since we don't want a change-detection digest to run as part of our internal
        // timer (we have no view-models that will change in response to this action),
        // let's wire-it-up outside of the core Angular Zone.
        this.debounceOutsideNgZone(() => {
            console.warn("Flushing to SessionStorage API.");
            // Even if SessionStorage exists (which is why this Class was
            // instantiated), interacting with it may still lead to runtime errors.
            // --
            // From MDN: If localStorage does exist, there is still no guarantee that
            // localStorage is actually available, as various browsers offer settings
            // that disable localStorage. So a browser may support localStorage, but
            // not make it available to the scripts on the page. For example, Safari
            // browser in Private Browsing mode gives us an empty localStorage object
            // with a quota of zero, effectively making it unusable. Conversely, we
            // might get a legitimate QuotaExceededError, which means that we've used
            // up all available storage space, but storage is actually available.
            try {
                sessionStorage.setItem(this.storageKey, JSON.stringify(this.cache));
            }
            catch (error) {
                console.warn("SessionStorageWrapper was unable to write to SessionStorage API.");
                console.error(error);
            }
        });
    }
}
// ----------------------------------------------------------------------------------- //
// ----------------------------------------------------------------------------------- //
class InMemoryWrapper {
    // I initialize an in-memory implementation of the storage wrapper.
    constructor() {
        this.cache = Object.create(null);
    }
    // ---
    // PUBLIC METHODS.
    // ---
    // I get the value associated with the given key; or null if the key is undefined.
    get(key) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            return ((_a = this.cache[key]) !== null && _a !== void 0 ? _a : null);
        });
    }
    // I remove any value associated with the given key.
    remove(key) {
        delete (this.cache[key]);
    }
    // I store the given value with the given key.
    set(key, value) {
        this.cache[key] = value;
    }
}


/***/ }),

/***/ "./src/app/services/user-helper.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/user-helper.service.ts ***!
  \*************************************************/
/*! exports provided: UserHelperService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserHelperService", function() { return UserHelperService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

let UserHelperService = class UserHelperService {
    /**
     * Constructor
     */
    constructor() { }
    /**
     * Decode a JWT token
     *
     * @param token The token to decode
     */
    decode(token) {
        if (token !== null || token !== undefined) {
            const base64Url = token.split('.')[1];
            if (base64Url === null || base64Url === undefined) {
                return null;
            }
            const base64 = base64Url.replace('-', '+').replace('_', '/');
            return JSON.parse(window.atob(base64));
        }
        else {
            return null;
        }
    }
    /**
     * Get an attribute value from the access token
     *
     * @param attribute The attribute's key
     */
    attr(attribute) {
        const token = localStorage.getItem('access_token');
        const user = localStorage.getItem('user');
        if (token === null || token === undefined || token === 'undefined') {
            return null;
        }
        const decoded = this.decode(token);
        let parsedUser;
        try {
            parsedUser = JSON.parse(user);
        }
        catch (e) {
            parsedUser = null;
        }
        if (decoded !== null && (attribute in decoded)) {
            return decoded[attribute];
        }
        if (parsedUser !== null && (attribute in parsedUser)) {
            return parsedUser[attribute];
        }
        return null;
    }
    /**
     * Get authenticated user's id
     */
    id() {
        return +this.attr('id');
    }
    /**
     * Get authenticated user's name
     */
    name() {
        return this.attr('name');
    }
    /**
     * Get authenticated user's email
     */
    email() {
        return this.attr('email');
    }
    /**
     * Get authenticated user
     */
    user() {
        return {
            id: this.id(),
            name: this.name(),
            email: this.email()
        };
    }
};
UserHelperService.ctorParameters = () => [];
UserHelperService = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
        providedIn: 'root'
    }),
    __metadata("design:paramtypes", [])
], UserHelperService);



/***/ }),

/***/ "./src/app/shared/back-button/back-button.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/shared/back-button/back-button.component.ts ***!
  \*************************************************************/
/*! exports provided: BackButtonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BackButtonComponent", function() { return BackButtonComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app.settings */ "./src/app/app.settings.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



let BackButtonComponent = class BackButtonComponent {
    constructor(appSettings, location) {
        this.appSettings = appSettings;
        this.location = location;
        this.isHeader = false;
        this.showBack = false;
        this.settings = this.appSettings.settings;
    }
    goBack() {
        this.location.back();
    }
};
BackButtonComponent.ctorParameters = () => [
    { type: _app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_2__["Location"] }
];
BackButtonComponent.propDecorators = {
    showBack: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['showBack',] }]
};
BackButtonComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-back-button',
        template: __importDefault(__webpack_require__(/*! raw-loader!./back-button.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/back-button/back-button.component.html")).default
    }),
    __metadata("design:paramtypes", [_app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["Location"]])
], BackButtonComponent);



/***/ }),

/***/ "./src/app/shared/clients/clients.component.scss":
/*!*******************************************************!*\
  !*** ./src/app/shared/clients/clients.component.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".clients-carousel {\n  position: relative;\n  padding: 8px 0;\n  margin-top: 30px;\n  margin-bottom: 20px;\n}\n.clients-carousel .swiper-container {\n  padding: 8px 2px;\n  margin: 0 14px;\n}\n.clients-carousel .swiper-container .client-item {\n  height: 88px;\n  display: flex;\n  align-items: center;\n}\n.clients-carousel .swiper-container .client-item img {\n  max-width: 100%;\n  max-height: 100%;\n  margin: 0 auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2NsaWVudHMvY2xpZW50cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFDSjtBQUFJO0VBQ0ksZ0JBQUE7RUFDQSxjQUFBO0FBRVI7QUFEUTtFQUNJLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFHWjtBQUZZO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQUloQiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9jbGllbnRzL2NsaWVudHMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2xpZW50cy1jYXJvdXNlbHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgcGFkZGluZzogOHB4IDA7XG4gICAgbWFyZ2luLXRvcDogMzBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICAgIC5zd2lwZXItY29udGFpbmVye1xuICAgICAgICBwYWRkaW5nOiA4cHggMnB4O1xuICAgICAgICBtYXJnaW46IDAgMTRweDtcbiAgICAgICAgLmNsaWVudC1pdGVte1xuICAgICAgICAgICAgaGVpZ2h0OiA4OHB4O1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICBpbWd7XG4gICAgICAgICAgICAgICAgbWF4LXdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgIG1heC1oZWlnaHQ6IDEwMCU7XG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwIGF1dG87XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gICAgICAgIFxuICAgIH1cbn0iXX0= */");

/***/ }),

/***/ "./src/app/shared/clients/clients.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/shared/clients/clients.component.ts ***!
  \*****************************************************/
/*! exports provided: ClientsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClientsComponent", function() { return ClientsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/app.service */ "./src/app/app.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let ClientsComponent = class ClientsComponent {
    constructor(appService) {
        this.appService = appService;
        this.config = {};
    }
    ngOnInit() {
        this.clients = this.appService.getClients();
    }
    ngAfterViewInit() {
        this.config = {
            observer: true,
            slidesPerView: 7,
            spaceBetween: 16,
            keyboard: true,
            navigation: false,
            pagination: false,
            grabCursor: true,
            loop: false,
            preloadImages: false,
            lazy: true,
            autoplay: {
                delay: 6000,
                disableOnInteraction: false
            },
            speed: 500,
            effect: "slide",
            breakpoints: {
                320: {
                    slidesPerView: 1
                },
                480: {
                    slidesPerView: 2
                },
                600: {
                    slidesPerView: 3,
                },
                960: {
                    slidesPerView: 4,
                },
                1280: {
                    slidesPerView: 5,
                },
                1500: {
                    slidesPerView: 6,
                }
            }
        };
    }
};
ClientsComponent.ctorParameters = () => [
    { type: src_app_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"] }
];
ClientsComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-clients',
        template: __importDefault(__webpack_require__(/*! raw-loader!./clients.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/clients/clients.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./clients.component.scss */ "./src/app/shared/clients/clients.component.scss")).default]
    }),
    __metadata("design:paramtypes", [src_app_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]])
], ClientsComponent);



/***/ }),

/***/ "./src/app/shared/comments/comments.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/shared/comments/comments.component.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9jb21tZW50cy9jb21tZW50cy5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/shared/comments/comments.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/shared/comments/comments.component.ts ***!
  \*******************************************************/
/*! exports provided: CommentsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommentsComponent", function() { return CommentsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var src_app_theme_utils_app_validators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/theme/utils/app-validators */ "./src/app/theme/utils/app-validators.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



let CommentsComponent = class CommentsComponent {
    constructor(fb) {
        this.fb = fb;
        this.reviews = [
            {
                author: 'Bruno Vespa',
                avatar: 'assets/images/avatars/avatar-1.png',
                tooltip: 'Dissatisfied',
                icon: 'sentiment_dissatisfied',
                date: '13 January, 2018 at 7:09',
                text: 'Integer id eros et mi fringilla imperdiet. In dictum turpis eget magna viverra condimentum. Ut malesuada interdum ultrices. Proin tristique sem pellentesque, posuere dui in, maximus magna. Aenean vehicula, tortor gravida elementum tincidunt, justo lorem vestibulum ex, eget egestas arcu tellus in magna.'
            },
            {
                author: 'Julia Aniston',
                avatar: 'assets/images/avatars/avatar-2.png',
                tooltip: 'Very Satisfied',
                icon: 'sentiment_very_satisfied',
                date: '04 February, 2018 at 10:22',
                text: 'Nulla accumsan, lacus sed suscipit rutrum, turpis augue accumsan metus, in accumsan urna mi vehicula lorem. Pellentesque semper nibh vitae augue placerat finibus. Nulla sed porttitor nunc, quis tristique sem. Quisque in varius nisl. Integer turpis lorem, ultricies sed sem nec, commodo molestie arcu. Nulla finibus ex tortor, et suscipit magna semper consectetur. Cras sit amet metus dui. Maecenas eget dui at ex varius malesuada vel non felis.'
            },
            {
                author: 'Andy Warhol',
                avatar: 'assets/images/avatars/avatar-3.png',
                tooltip: 'Neutral',
                icon: 'sentiment_neutral',
                date: '14 February, 2018 at 11:10',
                text: 'Pellentesque hendrerit vel turpis aliquam placerat. Suspendisse ullamcorper congue feugiat. Etiam gravida metus ac massa posuere venenatis. Pellentesque vehicula lobortis dolor, ac pretium dolor maximus quis. Fusce vitae iaculis mauris, quis posuere ex. Mauris vitae convallis nibh. Etiam eget enim at orci interdum maximus nec in ante.'
            }
        ];
        this.ratings = [
            { title: 'Very Dissatisfied', icon: 'sentiment_very_dissatisfied', percentage: 20, selected: false },
            { title: 'Dissatisfied', icon: 'sentiment_dissatisfied', percentage: 40, selected: false },
            { title: 'Neutral', icon: 'sentiment_neutral', percentage: 60, selected: false },
            { title: 'Satisfied', icon: 'sentiment_satisfied', percentage: 80, selected: false },
            { title: 'Very Satisfied', icon: 'sentiment_very_satisfied', percentage: 100, selected: false }
        ];
    }
    ngOnInit() {
        this.commentForm = this.fb.group({
            review: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required],
            name: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].minLength(4)])],
            email: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, src_app_theme_utils_app_validators__WEBPACK_IMPORTED_MODULE_2__["emailValidator"]])],
            rate: null,
            propertyId: this.propertyId
        });
    }
    onCommentFormSubmit(values) {
        if (this.commentForm.valid) {
            console.log(values);
            if (values.rate) {
                //property.ratingsCount++,
                //property.ratingsValue = property.ratingsValue + values.rate,
            }
        }
    }
    rate(rating) {
        this.ratings.filter(r => r.selected = false);
        this.ratings.filter(r => r.percentage == rating.percentage)[0].selected = true;
        this.commentForm.controls.rate.setValue(rating.percentage);
    }
};
CommentsComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"] }
];
CommentsComponent.propDecorators = {
    propertyId: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['propertyId',] }]
};
CommentsComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-comments',
        template: __importDefault(__webpack_require__(/*! raw-loader!./comments.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/comments/comments.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./comments.component.scss */ "./src/app/shared/comments/comments.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]])
], CommentsComponent);



/***/ }),

/***/ "./src/app/shared/compare-overview/compare-overview.component.scss":
/*!*************************************************************************!*\
  !*** ./src/app/shared/compare-overview/compare-overview.component.scss ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9jb21wYXJlLW92ZXJ2aWV3L2NvbXBhcmUtb3ZlcnZpZXcuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/shared/compare-overview/compare-overview.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/shared/compare-overview/compare-overview.component.ts ***!
  \***********************************************************************/
/*! exports provided: CompareOverviewComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompareOverviewComponent", function() { return CompareOverviewComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/bottom-sheet */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/bottom-sheet.js");
/* harmony import */ var _app_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../app.settings */ "./src/app/app.settings.ts");
/* harmony import */ var src_app_app_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/app.service */ "./src/app/app.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




let CompareOverviewComponent = class CompareOverviewComponent {
    constructor(appService, appSettings, bottomSheetRef) {
        this.appService = appService;
        this.appSettings = appSettings;
        this.bottomSheetRef = bottomSheetRef;
        this.settings = this.appSettings.settings;
    }
    ngOnInit() {
        this.properties = this.appService.Data.compareList;
    }
    hideSheet(isRedirect) {
        this.bottomSheetRef.dismiss(isRedirect);
    }
    remove(property, event) {
        const index = this.appService.Data.compareList.indexOf(property);
        if (index !== -1) {
            this.appService.Data.compareList.splice(index, 1);
        }
        if (this.appService.Data.compareList.length == 0) {
            this.hideSheet(false);
        }
        event.preventDefault();
    }
};
CompareOverviewComponent.ctorParameters = () => [
    { type: src_app_app_service__WEBPACK_IMPORTED_MODULE_3__["AppService"] },
    { type: _app_settings__WEBPACK_IMPORTED_MODULE_2__["AppSettings"] },
    { type: _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_1__["MatBottomSheetRef"] }
];
CompareOverviewComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-compare-overview',
        template: __importDefault(__webpack_require__(/*! raw-loader!./compare-overview.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/compare-overview/compare-overview.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./compare-overview.component.scss */ "./src/app/shared/compare-overview/compare-overview.component.scss")).default]
    }),
    __metadata("design:paramtypes", [src_app_app_service__WEBPACK_IMPORTED_MODULE_3__["AppService"],
        _app_settings__WEBPACK_IMPORTED_MODULE_2__["AppSettings"],
        _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_1__["MatBottomSheetRef"]])
], CompareOverviewComponent);



/***/ }),

/***/ "./src/app/shared/get-in-touch/get-in-touch.component.scss":
/*!*****************************************************************!*\
  !*** ./src/app/shared/get-in-touch/get-in-touch.component.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".get-in-touch {\n  position: relative;\n  margin-top: 80px;\n}\n.get-in-touch img {\n  max-width: 200px;\n  position: absolute;\n  bottom: 0;\n}\n.get-in-touch .content {\n  padding-left: 200px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2dldC1pbi10b3VjaC9nZXQtaW4tdG91Y2guY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLGdCQUFBO0FBQ0o7QUFBSTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0FBRVI7QUFBSTtFQUNJLG1CQUFBO0FBRVIiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvZ2V0LWluLXRvdWNoL2dldC1pbi10b3VjaC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5nZXQtaW4tdG91Y2h7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIG1hcmdpbi10b3A6IDgwcHg7XG4gICAgaW1ne1xuICAgICAgICBtYXgtd2lkdGg6IDIwMHB4OyBcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlOyBcbiAgICAgICAgYm90dG9tOiAwO1xuICAgIH1cbiAgICAuY29udGVudHtcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAyMDBweDtcbiAgICB9XG59Il19 */");

/***/ }),

/***/ "./src/app/shared/get-in-touch/get-in-touch.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/shared/get-in-touch/get-in-touch.component.ts ***!
  \***************************************************************/
/*! exports provided: GetInTouchComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetInTouchComponent", function() { return GetInTouchComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

let GetInTouchComponent = class GetInTouchComponent {
    constructor() { }
    ngOnInit() {
    }
};
GetInTouchComponent.ctorParameters = () => [];
GetInTouchComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-get-in-touch',
        template: __importDefault(__webpack_require__(/*! raw-loader!./get-in-touch.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/get-in-touch/get-in-touch.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./get-in-touch.component.scss */ "./src/app/shared/get-in-touch/get-in-touch.component.scss")).default]
    }),
    __metadata("design:paramtypes", [])
], GetInTouchComponent);



/***/ }),

/***/ "./src/app/shared/header-carousel/header-carousel.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/shared/header-carousel/header-carousel.component.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".header-carousel {\n  height: 460px;\n}\n.header-carousel .slide-item {\n  height: 100%;\n  background-size: cover;\n  background-position: center;\n}\n.header-carousel .swiper-lazy-preloader {\n  top: 15%;\n}\n.header-carousel .slide-info {\n  position: absolute;\n  height: 100%;\n  width: 100%;\n  top: 0;\n  z-index: 2;\n}\n.header-carousel .slide-info .mat-card {\n  text-align: center;\n  min-width: 450px;\n  transition: 0.4s;\n  margin: 0 16px;\n}\n.header-carousel .slide-info .mat-card .slide-title {\n  font-size: 32px;\n  line-height: 32px;\n  margin-bottom: 16px;\n  text-transform: uppercase;\n}\n.header-carousel .slide-info .mat-card .location {\n  font-size: 18px;\n  font-style: italic;\n  margin-bottom: 24px;\n  font-weight: 500;\n}\n.header-carousel .slide-info .mat-card .price {\n  font-size: 24px;\n  min-width: 200px;\n  padding: 8px 16px;\n}\n.header-carousel.offset-bottom {\n  height: 540px;\n}\n.header-carousel.offset-bottom .slide-info {\n  padding-bottom: 80px;\n}\n@media screen and (max-width: 599px) {\n  .header-carousel {\n    height: 340px;\n  }\n  .header-carousel.offset-bottom {\n    height: 420px;\n  }\n  .header-carousel .slide-info .mat-card {\n    min-width: 240px;\n  }\n  .header-carousel .slide-info .mat-card .slide-title {\n    font-size: 24px;\n    line-height: 24px;\n    margin-bottom: 16px;\n  }\n  .header-carousel .slide-info .mat-card .location {\n    font-size: 14px;\n    margin-bottom: 19px;\n    align-items: start !important;\n  }\n  .header-carousel .slide-info .mat-card .price {\n    font-size: 14px;\n    min-width: 120px;\n    padding: unset;\n  }\n}\n@media screen and (min-width: 600px) and (max-width: 959px) {\n  .header-carousel {\n    height: 380px;\n  }\n  .header-carousel.offset-bottom {\n    height: 460px;\n  }\n  .header-carousel .slide-info .mat-card {\n    min-width: 400px;\n  }\n  .header-carousel .slide-info .mat-card .slide-title {\n    font-size: 28px;\n    line-height: 28px;\n    margin-bottom: 16px;\n  }\n  .header-carousel .slide-info .mat-card .location {\n    font-size: 16px;\n    margin-bottom: 24px;\n  }\n  .header-carousel .slide-info .mat-card .price {\n    font-size: 20px;\n    min-width: 160px;\n    padding: 4px 12px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2hlYWRlci1jYXJvdXNlbC9oZWFkZXItY2Fyb3VzZWwuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3RoZW1lL3N0eWxlcy9fdmFyaWFibGVzLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDSSxhQ0dxQjtBREp6QjtBQUVJO0VBQ0ksWUFBQTtFQUNBLHNCQUFBO0VBQ0EsMkJBQUE7QUFBUjtBQUVJO0VBQ0ksUUFBQTtBQUFSO0FBRUk7RUFDSSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsTUFBQTtFQUNBLFVBQUE7QUFBUjtBQUNRO0VBQ0ksa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQUNaO0FBQVk7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0FBRWhCO0FBQVk7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBRWhCO0FBQVk7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQUVoQjtBQUVJO0VBQ0ksYUFBQTtBQUFSO0FBQ1E7RUFDSSxvQkN0Q3dCO0FEdUNwQztBQUtBO0VBQ0k7SUFFSSxhQUFBO0VBSE47RUFJTTtJQUNJLGFBQUE7RUFGVjtFQUtVO0lBQ0ksZ0JBQUE7RUFIZDtFQUljO0lBQ0ksZUFBQTtJQUNBLGlCQUFBO0lBQ0EsbUJBQUE7RUFGbEI7RUFJYztJQUNJLGVBQUE7SUFDQSxtQkFBQTtJQUNBLDZCQUFBO0VBRmxCO0VBSWM7SUFDSSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0VBRmxCO0FBQ0Y7QUFTQTtFQUNJO0lBRUksYUFBQTtFQVJOO0VBU007SUFDSSxhQUFBO0VBUFY7RUFVVTtJQUNJLGdCQUFBO0VBUmQ7RUFTYztJQUNJLGVBQUE7SUFDQSxpQkFBQTtJQUNBLG1CQUFBO0VBUGxCO0VBU2M7SUFDSSxlQUFBO0lBQ0EsbUJBQUE7RUFQbEI7RUFTYztJQUNJLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGlCQUFBO0VBUGxCO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvaGVhZGVyLWNhcm91c2VsL2hlYWRlci1jYXJvdXNlbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgXCIuLi8uLi90aGVtZS9zdHlsZXMvdmFyaWFibGVzXCI7XG5cbi5oZWFkZXItY2Fyb3VzZWx7IFxuICAgIGhlaWdodDogJGhlYWRlci1jYXJvdXNlbC1oZWlnaHQ7XG4gICAgLnNsaWRlLWl0ZW17XG4gICAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyOyAgICAgIFxuICAgIH1cbiAgICAuc3dpcGVyLWxhenktcHJlbG9hZGVye1xuICAgICAgICB0b3A6IDE1JTtcbiAgICB9XG4gICAgLnNsaWRlLWluZm97XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgdG9wOiAwOyAgICBcbiAgICAgICAgei1pbmRleDogMjtcbiAgICAgICAgLm1hdC1jYXJke1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICAgICAgbWluLXdpZHRoOiA0NTBweDsgICAgICAgICAgIFxuICAgICAgICAgICAgdHJhbnNpdGlvbjogMC40cztcbiAgICAgICAgICAgIG1hcmdpbjogMCAxNnB4OyAgICAgICAgICAgIFxuICAgICAgICAgICAgLnNsaWRlLXRpdGxleyAgIFxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMzJweDtcbiAgICAgICAgICAgICAgICBsaW5lLWhlaWdodDogMzJweDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICAgICAgICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAubG9jYXRpb257XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgICAgICAgICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAyNHB4O1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAucHJpY2V7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xuICAgICAgICAgICAgICAgIG1pbi13aWR0aDogMjAwcHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZzogOHB4IDE2cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgJi5vZmZzZXQtYm90dG9te1xuICAgICAgICBoZWlnaHQ6ICRoZWFkZXItY2Fyb3VzZWwtaGVpZ2h0ICsgJG1haW4tY29udGVudC1oZWFkZXItb2Zmc2V0LXRvLXRvcDsgICAgICAgIFxuICAgICAgICAuc2xpZGUtaW5mb3tcbiAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAkbWFpbi1jb250ZW50LWhlYWRlci1vZmZzZXQtdG8tdG9wO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4vLyB4c1xuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTk5cHgpIHtcbiAgICAuaGVhZGVyLWNhcm91c2VseyBcbiAgICAgICAgLy8gaGVpZ2h0OiAzMjBweDtcbiAgICAgICAgaGVpZ2h0OiAkaGVhZGVyLWNhcm91c2VsLWhlaWdodCAtIDEyMHB4O1xuICAgICAgICAmLm9mZnNldC1ib3R0b217XG4gICAgICAgICAgICBoZWlnaHQ6ICRoZWFkZXItY2Fyb3VzZWwtaGVpZ2h0ICsgJG1haW4tY29udGVudC1oZWFkZXItb2Zmc2V0LXRvLXRvcCAtIDEyMHB4O1xuICAgICAgICB9IFxuICAgICAgICAuc2xpZGUtaW5mb3sgXG4gICAgICAgICAgICAubWF0LWNhcmR7XG4gICAgICAgICAgICAgICAgbWluLXdpZHRoOiAyNDBweDtcbiAgICAgICAgICAgICAgICAuc2xpZGUtdGl0bGV7ICAgXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICAgICAgICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC5sb2NhdGlvbntcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxOXB4O1xuICAgICAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogc3RhcnQgIWltcG9ydGFudDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLnByaWNle1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgICAgIG1pbi13aWR0aDogMTIwcHg7XG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IHVuc2V0O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cblxuLy8gc21cbkBtZWRpYSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDYwMHB4KSBhbmQgKG1heC13aWR0aDogOTU5cHgpIHsgIFxuICAgIC5oZWFkZXItY2Fyb3VzZWx7IFxuICAgICAgICAvLyBoZWlnaHQ6IDM2MHB4O1xuICAgICAgICBoZWlnaHQ6ICRoZWFkZXItY2Fyb3VzZWwtaGVpZ2h0IC0gODBweDtcbiAgICAgICAgJi5vZmZzZXQtYm90dG9te1xuICAgICAgICAgICAgaGVpZ2h0OiAkaGVhZGVyLWNhcm91c2VsLWhlaWdodCArICRtYWluLWNvbnRlbnQtaGVhZGVyLW9mZnNldC10by10b3AgLSA4MHB4O1xuICAgICAgICB9ICAgICAgICBcbiAgICAgICAgLnNsaWRlLWluZm97IFxuICAgICAgICAgICAgLm1hdC1jYXJke1xuICAgICAgICAgICAgICAgIG1pbi13aWR0aDogNDAwcHg7XG4gICAgICAgICAgICAgICAgLnNsaWRlLXRpdGxleyAgIFxuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDI4cHg7XG4gICAgICAgICAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAyOHB4O1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAubG9jYXRpb257XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMjRweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLnByaWNle1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgICAgICAgICAgICAgIG1pbi13aWR0aDogMTYwcHg7XG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDRweCAxMnB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0iLCIkZm9udC1mYW1pbHk6ICdNb250c2VycmF0JztcbiR0aGVtZS1tYXgtd2lkdGg6IDEzMDBweDtcbiR0b3AtdG9vbGJhci1oZWlnaHQ6IDM2cHg7XG4kbWFpbi10b29sYmFyLWhlaWdodDogNzJweDtcbiR1c2VyLW1lbnUtd2lkdGg6IDIyMHB4O1xuJGhlYWRlci1pbWFnZS1taW4taGVpZ2h0OiAzMjBweDtcbiRoZWFkZXItY2Fyb3VzZWwtaGVpZ2h0OiA0NjBweDtcbiRtYWluLWNvbnRlbnQtaGVhZGVyLW9mZnNldC10by10b3A6IDgwcHg7XG5cbiRtYWluLXNpZGVuYXYtd2lkdGg6IDI1MHB4O1xuJHNlYXJjaC1zaWRlbmF2LXdpZHRoOiAyODhweDsiXX0= */");

/***/ }),

/***/ "./src/app/shared/header-carousel/header-carousel.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/shared/header-carousel/header-carousel.component.ts ***!
  \*********************************************************************/
/*! exports provided: HeaderCarouselComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderCarouselComponent", function() { return HeaderCarouselComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app.settings */ "./src/app/app.settings.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let HeaderCarouselComponent = class HeaderCarouselComponent {
    constructor(appSettings) {
        this.appSettings = appSettings;
        this.slides = [];
        this.config = {};
        this.settings = this.appSettings.settings;
    }
    ngOnInit() {
        if (this.contentOffsetToTop)
            this.settings.contentOffsetToTop = this.contentOffsetToTop;
    }
    ngAfterViewInit() {
        this.initCarousel();
    }
    ngOnChanges() {
        if (this.slides.length > 0) {
            this.currentSlide = this.slides[0];
        }
    }
    initCarousel() {
        this.config = {
            slidesPerView: 1,
            spaceBetween: 0,
            keyboard: true,
            navigation: true,
            pagination: false,
            grabCursor: true,
            loop: true,
            preloadImages: false,
            lazy: true,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false
            },
            speed: 500,
            effect: "slide"
        };
    }
    ngOnDestroy() {
        this.settings.contentOffsetToTop = false;
    }
    onIndexChange(index) {
        this.currentSlide = this.slides[index];
    }
};
HeaderCarouselComponent.ctorParameters = () => [
    { type: _app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"] }
];
HeaderCarouselComponent.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['slides',] }],
    contentOffsetToTop: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['contentOffsetToTop',] }]
};
HeaderCarouselComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-header-carousel',
        template: __importDefault(__webpack_require__(/*! raw-loader!./header-carousel.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/header-carousel/header-carousel.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./header-carousel.component.scss */ "./src/app/shared/header-carousel/header-carousel.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"]])
], HeaderCarouselComponent);



/***/ }),

/***/ "./src/app/shared/header-image/header-image.component.scss":
/*!*****************************************************************!*\
  !*** ./src/app/shared/header-image/header-image.component.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".header-image-wrapper {\n  position: relative;\n  overflow: hidden;\n  margin-top: -72px;\n  padding-top: 36px;\n}\n.header-image-wrapper .header-image-content {\n  position: relative;\n  min-height: 320px;\n  color: #fff;\n  z-index: 1;\n}\n.header-image-wrapper .header-image-content.offset-bottom {\n  padding-bottom: 80px;\n  min-height: 400px;\n}\n.header-image-wrapper .header-image-content.home-page {\n  min-height: 480px;\n}\n.header-image-wrapper .header-image-content .title {\n  font-size: 48px;\n  text-transform: uppercase;\n  padding: 0 16px;\n  text-align: center;\n}\n.header-image-wrapper .header-image-content .desc {\n  margin: 0;\n  font-size: 24px;\n  font-style: italic;\n  padding: 0 16px;\n  text-align: center;\n}\n.header-image-wrapper .header-image-content .mat-raised-button {\n  color: rgba(0, 0, 0, 0.87);\n  background-color: white;\n  text-transform: uppercase;\n  margin: 0 4px;\n}\n.header-image-wrapper .mask {\n  background: rgba(0, 0, 0, 0.7);\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  overflow: hidden;\n  top: 0;\n  left: 0;\n  z-index: 1;\n}\n.header-image-wrapper .bg {\n  width: 110%;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  background-size: cover;\n  background-repeat: no-repeat;\n  background-position: center;\n}\n.header-image-wrapper .bg-anime {\n  -webkit-animation-name: MOVE-BG;\n  -webkit-animation-duration: 15s;\n  -webkit-animation-timing-function: ease-in-out;\n  -webkit-animation-iteration-count: infinite;\n  -webkit-animation-direction: alternate;\n  -moz-animation-name: MOVE-BG;\n  -moz-animation-duration: 15s;\n  -moz-animation-timing-function: ease-in-out;\n  -moz-animation-iteration-count: infinite;\n  -moz-animation-direction: alternate;\n  -ms-animation-name: MOVE-BG;\n  -ms-animation-duration: 15s;\n  -ms-animation-timing-function: ease-in-out;\n  -ms-animation-iteration-count: infinite;\n  -ms-animation-direction: alternate;\n  animation-name: MOVE-BG;\n  animation-duration: 15s;\n  animation-timing-function: ease-in-out;\n  animation-iteration-count: infinite;\n  animation-direction: alternate;\n}\n@-webkit-keyframes MOVE-BG {\n  from {\n    -webkit-transform: translateX(0);\n  }\n  to {\n    -webkit-transform: translateX(-7%);\n  }\n}\n@keyframes MOVE-BG {\n  from {\n    transform: translateX(0);\n  }\n  to {\n    transform: translateX(-7%);\n  }\n}\n.header-image-wrapper[dir=rtl] .bg-anime {\n  -webkit-animation-name: MOVE-BG-RTL;\n  animation-name: MOVE-BG-RTL;\n}\n@-webkit-keyframes MOVE-BG-RTL {\n  from {\n    -webkit-transform: translateX(0);\n  }\n  to {\n    -webkit-transform: translateX(7%);\n  }\n}\n@keyframes MOVE-BG-RTL {\n  from {\n    transform: translateX(0);\n  }\n  to {\n    transform: translateX(7%);\n  }\n}\n@media screen and (max-width: 599px) {\n  .header-image-wrapper .header-image-content {\n    min-height: 240px;\n  }\n  .header-image-wrapper .header-image-content.offset-bottom {\n    min-height: 320px;\n  }\n  .header-image-wrapper .header-image-content.home-page {\n    min-height: 400px;\n  }\n  .header-image-wrapper .header-image-content .title {\n    font-size: 24px;\n  }\n  .header-image-wrapper .header-image-content .desc {\n    font-size: 16px;\n  }\n}\n@media screen and (min-width: 600px) and (max-width: 959px) {\n  .header-image-wrapper .header-image-content {\n    min-height: 280px;\n  }\n  .header-image-wrapper .header-image-content.offset-bottom {\n    min-height: 360px;\n  }\n  .header-image-wrapper .header-image-content.home-page {\n    min-height: 440px;\n  }\n  .header-image-wrapper .header-image-content .title {\n    font-size: 36px;\n  }\n  .header-image-wrapper .header-image-content .desc {\n    font-size: 18px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2hlYWRlci1pbWFnZS9oZWFkZXItaW1hZ2UuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3RoZW1lL3N0eWxlcy9fdmFyaWFibGVzLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDSSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQURKO0FBRUk7RUFDSSxrQkFBQTtFQUNBLGlCQ0prQjtFREtsQixXQUFBO0VBQ0EsVUFBQTtBQUFSO0FBQ1E7RUFDSSxvQkNOd0I7RURPeEIsaUJBQUE7QUFDWjtBQUNRO0VBQ0ksaUJBQUE7QUFDWjtBQUNRO0VBQ0ksZUFBQTtFQUNBLHlCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBQ1o7QUFDUTtFQUNJLFNBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFDWjtBQUNRO0VBQ0ksMEJBQUE7RUFDQSx1QkFBQTtFQUNBLHlCQUFBO0VBQ0EsYUFBQTtBQUNaO0FBRUk7RUFDSSw4QkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsVUFBQTtBQUFSO0FBRUk7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLE1BQUE7RUFDQSxTQUFBO0VBQ0Esc0JBQUE7RUFDQSw0QkFBQTtFQUNBLDJCQUFBO0FBQVI7QUFFSTtFQUNJLCtCQUFBO0VBQ0EsK0JBQUE7RUFDQSw4Q0FBQTtFQUNBLDJDQUFBO0VBQ0Esc0NBQUE7RUFDQSw0QkFBQTtFQUNBLDRCQUFBO0VBQ0EsMkNBQUE7RUFDQSx3Q0FBQTtFQUNBLG1DQUFBO0VBQ0EsMkJBQUE7RUFDQSwyQkFBQTtFQUNBLDBDQUFBO0VBQ0EsdUNBQUE7RUFDQSxrQ0FBQTtFQUNBLHVCQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsOEJBQUE7QUFBUjtBQUlBO0VBQTZCO0lBQU8sZ0NBQUE7RUFDbEM7RUFEc0U7SUFBSyxrQ0FBQTtFQUkzRTtBQUNGO0FBRkE7RUFBcUI7SUFBTyx3QkFBQTtFQXNCMUI7RUF0QnNEO0lBQUssMEJBQUE7RUF5QjNEO0FBQ0Y7QUF2Qkk7RUFDSSxtQ0FBQTtFQUdBLDJCQUFBO0FBeUJSO0FBckJBO0VBQWlDO0lBQU8sZ0NBQUE7RUEwQnRDO0VBMUIwRTtJQUFLLGlDQUFBO0VBNkIvRTtBQUNGO0FBM0JBO0VBQXlCO0lBQU8sd0JBQUE7RUErQzlCO0VBL0MwRDtJQUFLLHlCQUFBO0VBa0QvRDtBQUNGO0FBaERBO0VBRVE7SUFDSSxpQkFBQTtFQWlEVjtFQWhEVTtJQUNJLGlCQUFBO0VBa0RkO0VBaERVO0lBQ0ksaUJBQUE7RUFrRGQ7RUFoRFU7SUFDSSxlQUFBO0VBa0RkO0VBaERVO0lBQ0ksZUFBQTtFQWtEZDtBQUNGO0FBNUNBO0VBRVE7SUFDSSxpQkFBQTtFQTZDVjtFQTVDVTtJQUNJLGlCQUFBO0VBOENkO0VBNUNVO0lBQ0ksaUJBQUE7RUE4Q2Q7RUE1Q1U7SUFDSSxlQUFBO0VBOENkO0VBNUNVO0lBQ0ksZUFBQTtFQThDZDtBQUNGIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkL2hlYWRlci1pbWFnZS9oZWFkZXItaW1hZ2UuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0IFwiLi4vLi4vdGhlbWUvc3R5bGVzL3ZhcmlhYmxlc1wiO1xuXG4uaGVhZGVyLWltYWdlLXdyYXBwZXJ7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgbWFyZ2luLXRvcDogLSRtYWluLXRvb2xiYXItaGVpZ2h0O1xuICAgIHBhZGRpbmctdG9wOiAkbWFpbi10b29sYmFyLWhlaWdodC8yO1xuICAgIC5oZWFkZXItaW1hZ2UtY29udGVudHtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICBtaW4taGVpZ2h0OiAkaGVhZGVyLWltYWdlLW1pbi1oZWlnaHQ7XG4gICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICB6LWluZGV4OiAxOyAgICAgICAgXG4gICAgICAgICYub2Zmc2V0LWJvdHRvbXtcbiAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAkbWFpbi1jb250ZW50LWhlYWRlci1vZmZzZXQtdG8tdG9wO1xuICAgICAgICAgICAgbWluLWhlaWdodDogJGhlYWRlci1pbWFnZS1taW4taGVpZ2h0ICsgJG1haW4tY29udGVudC1oZWFkZXItb2Zmc2V0LXRvLXRvcDtcbiAgICAgICAgfVxuICAgICAgICAmLmhvbWUtcGFnZXtcbiAgICAgICAgICAgIG1pbi1oZWlnaHQ6ICRoZWFkZXItaW1hZ2UtbWluLWhlaWdodCArICRtYWluLWNvbnRlbnQtaGVhZGVyLW9mZnNldC10by10b3AgKyA4MHB4O1xuICAgICAgICB9XG4gICAgICAgIC50aXRsZXtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogNDhweDsgXG4gICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlOyBcbiAgICAgICAgICAgIHBhZGRpbmc6IDAgMTZweDtcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgfVxuICAgICAgICAuZGVzY3tcbiAgICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjRweDsgXG4gICAgICAgICAgICBmb250LXN0eWxlOiBpdGFsaWM7IFxuICAgICAgICAgICAgcGFkZGluZzogMCAxNnB4O1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICB9XG4gICAgICAgIC5tYXQtcmFpc2VkLWJ1dHRvbntcbiAgICAgICAgICAgIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuODcpO1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgICAgICAgbWFyZ2luOiAwIDRweDtcbiAgICAgICAgfSAgICAgICAgXG4gICAgfVxuICAgIC5tYXNreyBcbiAgICAgICAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjcpOyBcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgICB0b3A6IDA7XG4gICAgICAgIGxlZnQ6IDA7XG4gICAgICAgIHotaW5kZXg6IDE7XG4gICAgfVxuICAgIC5iZ3tcbiAgICAgICAgd2lkdGg6IDExMCU7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgbGVmdDogMDtcbiAgICAgICAgcmlnaHQ6IDA7XG4gICAgICAgIHRvcDogMDtcbiAgICAgICAgYm90dG9tOiAwO1xuICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7IFxuICAgIH1cbiAgICAuYmctYW5pbWV7XG4gICAgICAgIC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IE1PVkUtQkc7XG4gICAgICAgIC13ZWJraXQtYW5pbWF0aW9uLWR1cmF0aW9uOiAxNXM7XG4gICAgICAgIC13ZWJraXQtYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbi1vdXQ7XG4gICAgICAgIC13ZWJraXQtYW5pbWF0aW9uLWl0ZXJhdGlvbi1jb3VudDogaW5maW5pdGU7XG4gICAgICAgIC13ZWJraXQtYW5pbWF0aW9uLWRpcmVjdGlvbjogYWx0ZXJuYXRlOyAgICAgIFxuICAgICAgICAtbW96LWFuaW1hdGlvbi1uYW1lOiBNT1ZFLUJHO1xuICAgICAgICAtbW96LWFuaW1hdGlvbi1kdXJhdGlvbjogMTVzO1xuICAgICAgICAtbW96LWFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2UtaW4tb3V0O1xuICAgICAgICAtbW96LWFuaW1hdGlvbi1pdGVyYXRpb24tY291bnQ6IGluZmluaXRlO1xuICAgICAgICAtbW96LWFuaW1hdGlvbi1kaXJlY3Rpb246IGFsdGVybmF0ZTsgICAgICBcbiAgICAgICAgLW1zLWFuaW1hdGlvbi1uYW1lOiBNT1ZFLUJHO1xuICAgICAgICAtbXMtYW5pbWF0aW9uLWR1cmF0aW9uOiAxNXM7XG4gICAgICAgIC1tcy1hbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDtcbiAgICAgICAgLW1zLWFuaW1hdGlvbi1pdGVyYXRpb24tY291bnQ6IGluZmluaXRlO1xuICAgICAgICAtbXMtYW5pbWF0aW9uLWRpcmVjdGlvbjogYWx0ZXJuYXRlOyAgICAgIFxuICAgICAgICBhbmltYXRpb24tbmFtZTogTU9WRS1CRztcbiAgICAgICAgYW5pbWF0aW9uLWR1cmF0aW9uOiAxNXM7XG4gICAgICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2UtaW4tb3V0O1xuICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTtcbiAgICAgICAgYW5pbWF0aW9uLWRpcmVjdGlvbjogYWx0ZXJuYXRlO1xuICAgIH1cbn1cblxuQC13ZWJraXQta2V5ZnJhbWVzIE1PVkUtQkcgeyBmcm9tIHsgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCk7IH0gdG8geyAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNyUpOyB9IH0gIFxuQC1tb3ota2V5ZnJhbWVzIE1PVkUtQkcgeyBmcm9tIHsgLW1vei10cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCk7IH0gdG8geyAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNyUpOyB9IH0gIFxuQC1tcy1rZXlmcmFtZXMgTU9WRS1CRyB7IGZyb20geyAtbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGVYKDApOyB9IHRvIHsgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNyUpOyB9IH0gXG5Aa2V5ZnJhbWVzIE1PVkUtQkcgeyBmcm9tIHsgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKDApOyB9IHRvIHsgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC03JSk7IH0gfVxuXG4uaGVhZGVyLWltYWdlLXdyYXBwZXJbZGlyPVwicnRsXCJde1xuICAgIC5iZy1hbmltZXtcbiAgICAgICAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogTU9WRS1CRy1SVEw7ICAgICAgXG4gICAgICAgIC1tb3otYW5pbWF0aW9uLW5hbWU6IE1PVkUtQkctUlRMOyAgICAgIFxuICAgICAgICAtbXMtYW5pbWF0aW9uLW5hbWU6IE1PVkUtQkctUlRMOyAgICAgIFxuICAgICAgICBhbmltYXRpb24tbmFtZTogTU9WRS1CRy1SVEw7IFxuICAgIH1cbn1cblxuQC13ZWJraXQta2V5ZnJhbWVzIE1PVkUtQkctUlRMIHsgZnJvbSB7IC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVYKDApOyB9IHRvIHsgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVgoNyUpOyB9IH0gIFxuQC1tb3ota2V5ZnJhbWVzIE1PVkUtQkctUlRMIHsgZnJvbSB7IC1tb3otdHJhbnNmb3JtOiB0cmFuc2xhdGVYKDApOyB9IHRvIHsgLW1vei10cmFuc2Zvcm06IHRyYW5zbGF0ZVgoNyUpOyB9IH0gIFxuQC1tcy1rZXlmcmFtZXMgTU9WRS1CRy1SVEwgeyBmcm9tIHsgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWCgwKTsgfSB0byB7IC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVgoNyUpOyB9IH0gXG5Aa2V5ZnJhbWVzIE1PVkUtQkctUlRMIHsgZnJvbSB7IHRyYW5zZm9ybTogdHJhbnNsYXRlWCgwKTsgfSB0byB7IHRyYW5zZm9ybTogdHJhbnNsYXRlWCg3JSk7IH0gfVxuXG4vLyB4c1xuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTk5cHgpIHtcbiAgICAuaGVhZGVyLWltYWdlLXdyYXBwZXJ7XG4gICAgICAgIC5oZWFkZXItaW1hZ2UtY29udGVudHtcbiAgICAgICAgICAgIG1pbi1oZWlnaHQ6ICRoZWFkZXItaW1hZ2UtbWluLWhlaWdodCAtIDgwcHg7XG4gICAgICAgICAgICAmLm9mZnNldC1ib3R0b217XG4gICAgICAgICAgICAgICAgbWluLWhlaWdodDogJGhlYWRlci1pbWFnZS1taW4taGVpZ2h0ICsgJG1haW4tY29udGVudC1oZWFkZXItb2Zmc2V0LXRvLXRvcCAtIDgwcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAmLmhvbWUtcGFnZXtcbiAgICAgICAgICAgICAgICBtaW4taGVpZ2h0OiAkaGVhZGVyLWltYWdlLW1pbi1oZWlnaHQgKyAkbWFpbi1jb250ZW50LWhlYWRlci1vZmZzZXQtdG8tdG9wO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLnRpdGxle1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjRweDsgXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAuZGVzY3sgXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4OyBcbiAgICAgICAgICAgIH0gICAgICAgICAgICAgXG4gICAgICAgIH0gXG4gICAgfVxufVxuXG4vLyBzbVxuQG1lZGlhIHNjcmVlbiBhbmQgKG1pbi13aWR0aDogNjAwcHgpIGFuZCAobWF4LXdpZHRoOiA5NTlweCkge1xuICAgIC5oZWFkZXItaW1hZ2Utd3JhcHBlcntcbiAgICAgICAgLmhlYWRlci1pbWFnZS1jb250ZW50e1xuICAgICAgICAgICAgbWluLWhlaWdodDogJGhlYWRlci1pbWFnZS1taW4taGVpZ2h0IC0gNDBweDtcbiAgICAgICAgICAgICYub2Zmc2V0LWJvdHRvbXtcbiAgICAgICAgICAgICAgICBtaW4taGVpZ2h0OiAkaGVhZGVyLWltYWdlLW1pbi1oZWlnaHQgKyAkbWFpbi1jb250ZW50LWhlYWRlci1vZmZzZXQtdG8tdG9wIC0gNDBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgICYuaG9tZS1wYWdle1xuICAgICAgICAgICAgICAgIG1pbi1oZWlnaHQ6ICRoZWFkZXItaW1hZ2UtbWluLWhlaWdodCArICRtYWluLWNvbnRlbnQtaGVhZGVyLW9mZnNldC10by10b3AgKyA0MHB4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLnRpdGxle1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMzZweDsgXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAuZGVzY3sgXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4OyBcbiAgICAgICAgICAgIH0gICAgICAgICAgICAgXG4gICAgICAgIH0gXG4gICAgfVxufSIsIiRmb250LWZhbWlseTogJ01vbnRzZXJyYXQnO1xuJHRoZW1lLW1heC13aWR0aDogMTMwMHB4O1xuJHRvcC10b29sYmFyLWhlaWdodDogMzZweDtcbiRtYWluLXRvb2xiYXItaGVpZ2h0OiA3MnB4O1xuJHVzZXItbWVudS13aWR0aDogMjIwcHg7XG4kaGVhZGVyLWltYWdlLW1pbi1oZWlnaHQ6IDMyMHB4O1xuJGhlYWRlci1jYXJvdXNlbC1oZWlnaHQ6IDQ2MHB4O1xuJG1haW4tY29udGVudC1oZWFkZXItb2Zmc2V0LXRvLXRvcDogODBweDtcblxuJG1haW4tc2lkZW5hdi13aWR0aDogMjUwcHg7XG4kc2VhcmNoLXNpZGVuYXYtd2lkdGg6IDI4OHB4OyJdfQ== */");

/***/ }),

/***/ "./src/app/shared/header-image/header-image.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/shared/header-image/header-image.component.ts ***!
  \***************************************************************/
/*! exports provided: HeaderImageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderImageComponent", function() { return HeaderImageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _app_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../app.settings */ "./src/app/app.settings.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



let HeaderImageComponent = class HeaderImageComponent {
    constructor(appSettings, sanitizer) {
        this.appSettings = appSettings;
        this.sanitizer = sanitizer;
        this.isHomePage = false;
        this.settings = this.appSettings.settings;
        this.settings.headerBgImage = true;
    }
    ngOnInit() {
        if (this.contentOffsetToTop)
            this.settings.contentOffsetToTop = this.contentOffsetToTop;
        if (this.backgroundImage)
            this.bgImage = this.sanitizer.bypassSecurityTrustStyle('url(' + this.backgroundImage + ')');
    }
    ngOnDestroy() {
        this.settings.headerBgImage = false;
        this.settings.contentOffsetToTop = false;
    }
};
HeaderImageComponent.ctorParameters = () => [
    { type: _app_settings__WEBPACK_IMPORTED_MODULE_2__["AppSettings"] },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["DomSanitizer"] }
];
HeaderImageComponent.propDecorators = {
    backgroundImage: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['backgroundImage',] }],
    bgImageAnimate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['bgImageAnimate',] }],
    contentOffsetToTop: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['contentOffsetToTop',] }],
    contentMinHeight: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['contentMinHeight',] }],
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['title',] }],
    desc: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['desc',] }],
    isHomePage: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['isHomePage',] }]
};
HeaderImageComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-header-image',
        template: __importDefault(__webpack_require__(/*! raw-loader!./header-image.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/header-image/header-image.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./header-image.component.scss */ "./src/app/shared/header-image/header-image.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_app_settings__WEBPACK_IMPORTED_MODULE_2__["AppSettings"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["DomSanitizer"]])
], HeaderImageComponent);



/***/ }),

/***/ "./src/app/shared/load-more/load-more.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/shared/load-more/load-more.component.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9sb2FkLW1vcmUvbG9hZC1tb3JlLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/shared/load-more/load-more.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/shared/load-more/load-more.component.ts ***!
  \*********************************************************/
/*! exports provided: LoadMoreComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadMoreComponent", function() { return LoadMoreComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app.settings */ "./src/app/app.settings.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let LoadMoreComponent = class LoadMoreComponent {
    constructor(appSettings) {
        this.appSettings = appSettings;
        this.step = 1;
        this.settings = this.appSettings.settings;
    }
    ngOnInit() {
        this.settings.loadMore.step = this.step;
    }
    startLoad() {
        this.settings.loadMore.start = true;
        this.settings.loadMore.load = true;
    }
};
LoadMoreComponent.ctorParameters = () => [
    { type: _app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"] }
];
LoadMoreComponent.propDecorators = {
    step: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }]
};
LoadMoreComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-load-more',
        template: __importDefault(__webpack_require__(/*! raw-loader!./load-more.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/load-more/load-more.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./load-more.component.scss */ "./src/app/shared/load-more/load-more.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"]])
], LoadMoreComponent);



/***/ }),

/***/ "./src/app/shared/logo/logo.component.ts":
/*!***********************************************!*\
  !*** ./src/app/shared/logo/logo.component.ts ***!
  \***********************************************/
/*! exports provided: LogoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogoComponent", function() { return LogoComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app.settings */ "./src/app/app.settings.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let LogoComponent = class LogoComponent {
    constructor(appSettings) {
        this.appSettings = appSettings;
        this.isHeader = false;
        this.settings = this.appSettings.settings;
    }
};
LogoComponent.ctorParameters = () => [
    { type: _app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"] }
];
LogoComponent.propDecorators = {
    isHeader: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }]
};
LogoComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-logo',
        template: __importDefault(__webpack_require__(/*! raw-loader!./logo.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/logo/logo.component.html")).default
    }),
    __metadata("design:paramtypes", [_app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"]])
], LogoComponent);



/***/ }),

/***/ "./src/app/shared/mission/mission.component.scss":
/*!*******************************************************!*\
  !*** ./src/app/shared/mission/mission.component.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9taXNzaW9uL21pc3Npb24uY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/shared/mission/mission.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/shared/mission/mission.component.ts ***!
  \*****************************************************/
/*! exports provided: MissionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MissionComponent", function() { return MissionComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

let MissionComponent = class MissionComponent {
    constructor() { }
    ngOnInit() {
    }
};
MissionComponent.ctorParameters = () => [];
MissionComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-mission',
        template: __importDefault(__webpack_require__(/*! raw-loader!./mission.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/mission/mission.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./mission.component.scss */ "./src/app/shared/mission/mission.component.scss")).default]
    }),
    __metadata("design:paramtypes", [])
], MissionComponent);



/***/ }),

/***/ "./src/app/shared/our-agents/our-agents.component.scss":
/*!*************************************************************!*\
  !*** ./src/app/shared/our-agents/our-agents.component.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9vdXItYWdlbnRzL291ci1hZ2VudHMuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/shared/our-agents/our-agents.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/shared/our-agents/our-agents.component.ts ***!
  \***********************************************************/
/*! exports provided: OurAgentsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OurAgentsComponent", function() { return OurAgentsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/app.service */ "./src/app/app.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let OurAgentsComponent = class OurAgentsComponent {
    constructor(appService) {
        this.appService = appService;
        this.config = {};
    }
    ngOnInit() {
        this.agents = this.appService.getAgents();
    }
    ngAfterViewInit() {
        this.config = {
            observer: true,
            slidesPerView: 4,
            spaceBetween: 16,
            keyboard: true,
            navigation: true,
            pagination: false,
            grabCursor: true,
            loop: false,
            preloadImages: false,
            lazy: true,
            breakpoints: {
                600: {
                    slidesPerView: 1,
                },
                960: {
                    slidesPerView: 2,
                },
                1280: {
                    slidesPerView: 3,
                }
            }
        };
    }
};
OurAgentsComponent.ctorParameters = () => [
    { type: src_app_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"] }
];
OurAgentsComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-our-agents',
        template: __importDefault(__webpack_require__(/*! raw-loader!./our-agents.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/our-agents/our-agents.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./our-agents.component.scss */ "./src/app/shared/our-agents/our-agents.component.scss")).default]
    }),
    __metadata("design:paramtypes", [src_app_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]])
], OurAgentsComponent);



/***/ }),

/***/ "./src/app/shared/our-services/our-services.component.scss":
/*!*****************************************************************!*\
  !*** ./src/app/shared/our-services/our-services.component.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".services-wrapper {\n  margin: -8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL291ci1zZXJ2aWNlcy9vdXItc2VydmljZXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0FBQ0oiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvb3VyLXNlcnZpY2VzL291ci1zZXJ2aWNlcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zZXJ2aWNlcy13cmFwcGVye1xuICAgIG1hcmdpbjogLThweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/shared/our-services/our-services.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/shared/our-services/our-services.component.ts ***!
  \***************************************************************/
/*! exports provided: OurServicesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OurServicesComponent", function() { return OurServicesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

let OurServicesComponent = class OurServicesComponent {
    constructor() { }
    ngOnInit() {
    }
};
OurServicesComponent.ctorParameters = () => [];
OurServicesComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-our-services',
        template: __importDefault(__webpack_require__(/*! raw-loader!./our-services.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/our-services/our-services.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./our-services.component.scss */ "./src/app/shared/our-services/our-services.component.scss")).default]
    }),
    __metadata("design:paramtypes", [])
], OurServicesComponent);



/***/ }),

/***/ "./src/app/shared/properties-carousel/properties-carousel.component.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/shared/properties-carousel/properties-carousel.component.scss ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9wcm9wZXJ0aWVzLWNhcm91c2VsL3Byb3BlcnRpZXMtY2Fyb3VzZWwuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/shared/properties-carousel/properties-carousel.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/shared/properties-carousel/properties-carousel.component.ts ***!
  \*****************************************************************************/
/*! exports provided: PropertiesCarouselComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PropertiesCarouselComponent", function() { return PropertiesCarouselComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

let PropertiesCarouselComponent = class PropertiesCarouselComponent {
    constructor() {
        this.properties = [];
        this.config = {};
    }
    ngOnInit() {
    }
    ngAfterViewInit() {
        this.config = {
            observer: true,
            slidesPerView: 4,
            spaceBetween: 16,
            keyboard: true,
            navigation: { nextEl: '.prop-next', prevEl: '.prop-prev' },
            pagination: true,
            grabCursor: true,
            loop: false,
            preloadImages: true,
            lazy: false,
            breakpoints: {
                600: {
                    slidesPerView: 1
                },
                960: {
                    slidesPerView: 2,
                },
                1280: {
                    slidesPerView: 3,
                }
            }
        };
    }
};
PropertiesCarouselComponent.ctorParameters = () => [];
PropertiesCarouselComponent.propDecorators = {
    properties: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['properties',] }]
};
PropertiesCarouselComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-properties-carousel',
        template: __importDefault(__webpack_require__(/*! raw-loader!./properties-carousel.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/properties-carousel/properties-carousel.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./properties-carousel.component.scss */ "./src/app/shared/properties-carousel/properties-carousel.component.scss")).default]
    }),
    __metadata("design:paramtypes", [])
], PropertiesCarouselComponent);



/***/ }),

/***/ "./src/app/shared/properties-search-results-filters/properties-search-results-filters.component.scss":
/*!***********************************************************************************************************!*\
  !*** ./src/app/shared/properties-search-results-filters/properties-search-results-filters.component.scss ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9wcm9wZXJ0aWVzLXNlYXJjaC1yZXN1bHRzLWZpbHRlcnMvcHJvcGVydGllcy1zZWFyY2gtcmVzdWx0cy1maWx0ZXJzLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/shared/properties-search-results-filters/properties-search-results-filters.component.ts":
/*!*********************************************************************************************************!*\
  !*** ./src/app/shared/properties-search-results-filters/properties-search-results-filters.component.ts ***!
  \*********************************************************************************************************/
/*! exports provided: PropertiesSearchResultsFiltersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PropertiesSearchResultsFiltersComponent", function() { return PropertiesSearchResultsFiltersComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

let PropertiesSearchResultsFiltersComponent = class PropertiesSearchResultsFiltersComponent {
    constructor() {
        this.onRemoveSearchField = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    ngOnInit() { }
    remove(field) {
        this.onRemoveSearchField.emit(field);
    }
};
PropertiesSearchResultsFiltersComponent.ctorParameters = () => [];
PropertiesSearchResultsFiltersComponent.propDecorators = {
    searchFields: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    onRemoveSearchField: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }]
};
PropertiesSearchResultsFiltersComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-properties-search-results-filters',
        template: __importDefault(__webpack_require__(/*! raw-loader!./properties-search-results-filters.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/properties-search-results-filters/properties-search-results-filters.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./properties-search-results-filters.component.scss */ "./src/app/shared/properties-search-results-filters/properties-search-results-filters.component.scss")).default]
    }),
    __metadata("design:paramtypes", [])
], PropertiesSearchResultsFiltersComponent);



/***/ }),

/***/ "./src/app/shared/properties-search/properties-search.component.scss":
/*!***************************************************************************!*\
  !*** ./src/app/shared/properties-search/properties-search.component.scss ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9wcm9wZXJ0aWVzLXNlYXJjaC9wcm9wZXJ0aWVzLXNlYXJjaC5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/shared/properties-search/properties-search.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/shared/properties-search/properties-search.component.ts ***!
  \*************************************************************************/
/*! exports provided: PropertiesSearchComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PropertiesSearchComponent", function() { return PropertiesSearchComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../app.service */ "./src/app/app.service.ts");
/* harmony import */ var _services_temporary_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/temporary-storage.service */ "./src/app/services/temporary-storage.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




let PropertiesSearchComponent = class PropertiesSearchComponent {
    constructor(temporaryStorageService, appService, fb) {
        this.appService = appService;
        this.fb = fb;
        this.prefix = 'search';
        this.variant = 1;
        this.vertical = false;
        this.searchOnBtnClick = false;
        this.onSearchChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.onSearchClick = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.showMore = false;
        this.propertyTypes = [];
        this.propertyStatuses = [];
        this.cities = [];
        this.neighborhoods = [];
        this.streets = [];
        this.features = [];
        // The TemporaryStorageService is a glorified key-value store. And, for this
        // component, we are going to store all of the temporary form-data in a single
        // key. As such, we can make our lives easier by creating a "Facet" of the
        // temporary storage, which locks-in a key, allowing us to make subsequent calls
        // against the facet without providing a key.
        this.searchStorage = temporaryStorageService.forKey(this.prefix + "_search");
        this.showMoreStorage = temporaryStorageService.forKey(this.prefix + "_showMore");
    }
    ngOnInit() {
        if (this.vertical) {
            this.showMore = true;
        }
        ;
        this.propertyTypes = this.appService.getPropertyTypes();
        this.propertyStatuses = this.appService.getPropertyStatuses();
        this.cities = this.appService.getCities();
        this.neighborhoods = this.appService.getNeighborhoods();
        this.streets = this.appService.getStreets();
        this.features = this.appService.getFeatures();
        this.form = this.fb.group({
            propertyType: null,
            propertyStatus: null,
            price: this.fb.group({
                from: null,
                to: null
            }),
            city: null,
            zipCode: null,
            neighborhood: [],
            street: null,
            bedrooms: this.fb.group({
                from: null,
                to: null
            }),
            bathrooms: this.fb.group({
                from: null,
                to: null
            }),
            floors: this.fb.group({
                from: null,
                to: null
            }),
            area: this.fb.group({
                from: null,
                to: null
            }),
            yearBuilt: this.fb.group({
                from: null,
                to: null
            }),
            features: this.buildFeatures()
        });
        this.form.valueChanges.subscribe(value => {
            this.saveSearchStorage();
        });
        this.restoreFromTemporaryStorage();
        this.onSearchChange.emit(this.form);
    }
    buildFeatures() {
        const arr = this.features.map(feature => {
            return this.fb.group({
                id: feature.id,
                name: feature.name,
                selected: feature.selected
            });
        });
        return this.fb.array(arr);
    }
    ngOnChanges() {
        if (this.removedSearchField) {
            if (this.removedSearchField.indexOf(".") > -1) {
                let arr = this.removedSearchField.split(".");
                this.form.controls[arr[0]]['controls'][arr[1]].reset();
            }
            else if (this.removedSearchField.indexOf(",") > -1) {
                let arr = this.removedSearchField.split(",");
                this.form.controls[arr[0]]['controls'][arr[1]]['controls']['selected'].setValue(false);
            }
            else {
                this.form.controls[this.removedSearchField].reset();
            }
        }
    }
    reset() {
        this.form.reset({
            propertyType: null,
            propertyStatus: null,
            price: {
                from: null,
                to: null
            },
            city: null,
            zipCode: null,
            neighborhood: null,
            street: null,
            bedrooms: {
                from: null,
                to: null
            },
            bathrooms: {
                from: null,
                to: null
            },
            floors: {
                from: null,
                to: null
            },
            area: {
                from: null,
                to: null
            },
            yearBuilt: {
                from: null,
                to: null
            },
            features: this.features
        });
        // Now that we've processed the new-friend form, we can flush any temporarily-
        // cached form data from our temporary storage.
        this.searchStorage.remove();
    }
    search() {
        this.onSearchClick.emit();
    }
    onSelectCity() {
        this.form.controls['neighborhood'].setValue(null, { emitEvent: false });
        this.form.controls['street'].setValue(null, { emitEvent: false });
    }
    onSelectNeighborhood() {
        this.form.controls['street'].setValue(null, { emitEvent: false });
    }
    getAppearance() {
        return (this.variant != 3) ? 'outline' : '';
    }
    getFloatLabel() {
        return (this.variant == 1) ? 'always' : '';
    }
    showMoreClicked() {
        this.showMore = !this.showMore;
        this.saveShowMoreStorage();
    }
    // I attempt to load persisted data from our Facet of the TemporaryStorageService
    // into the current view-model of the form-data.
    restoreFromTemporaryStorage() {
        return __awaiter(this, void 0, void 0, function* () {
            let searchData = yield this.searchStorage.get();
            let showMore = yield this.showMoreStorage.get();
            if (searchData) {
                this.form.setValue(searchData, { emitEvent: false });
            }
            if (showMore) {
                this.showMore = showMore;
            }
        });
    }
    // I save the current form-data view-model to the temporary storage.
    saveSearchStorage() {
        // NOTE: If I wanted to save a tiny bit of memory, I could check to see if any of
        // the form-data was actually populated before I persisted it to the temporary
        // storage. But, seeing as I would generally remove this data during the
        // ngOnDestroy() life-cycle event, there's really no need to make the code more
        // "clever" than it has to be.
        this.searchStorage.set(this.form.value);
    }
    saveShowMoreStorage() {
        this.showMoreStorage.set(this.showMore);
    }
    comparer(o1, o2) {
        // if possible compare by object's name, and not by reference.
        return o1 && o2 && o1.id === o2.id;
    }
};
PropertiesSearchComponent.ctorParameters = () => [
    { type: _services_temporary_storage_service__WEBPACK_IMPORTED_MODULE_3__["TemporaryStorageService"] },
    { type: _app_service__WEBPACK_IMPORTED_MODULE_2__["AppService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"] }
];
PropertiesSearchComponent.propDecorators = {
    prefix: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    variant: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    vertical: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    searchOnBtnClick: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    removedSearchField: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    onSearchChange: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onSearchClick: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }]
};
PropertiesSearchComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-properties-search',
        template: __importDefault(__webpack_require__(/*! raw-loader!./properties-search.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/properties-search/properties-search.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./properties-search.component.scss */ "./src/app/shared/properties-search/properties-search.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_services_temporary_storage_service__WEBPACK_IMPORTED_MODULE_3__["TemporaryStorageService"],
        _app_service__WEBPACK_IMPORTED_MODULE_2__["AppService"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]])
], PropertiesSearchComponent);



/***/ }),

/***/ "./src/app/shared/properties-toolbar/properties-toolbar.component.scss":
/*!*****************************************************************************!*\
  !*** ./src/app/shared/properties-toolbar/properties-toolbar.component.scss ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9wcm9wZXJ0aWVzLXRvb2xiYXIvcHJvcGVydGllcy10b29sYmFyLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/shared/properties-toolbar/properties-toolbar.component.ts":
/*!***************************************************************************!*\
  !*** ./src/app/shared/properties-toolbar/properties-toolbar.component.ts ***!
  \***************************************************************************/
/*! exports provided: PropertiesToolbarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PropertiesToolbarComponent", function() { return PropertiesToolbarComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _services_temporary_storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/temporary-storage.service */ "./src/app/services/temporary-storage.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let PropertiesToolbarComponent = class PropertiesToolbarComponent {
    constructor(temporaryStorageService) {
        this.prefix = 'search';
        this.isHomePage = false;
        this.showSidenavToggle = false;
        this.onSidenavToggle = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.onChangeCount = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.onChangeSorting = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.onChangeViewType = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.viewType = 'grid';
        this.viewCol = 25;
        this.counts = [8, 12, 16, 24, 36];
        this.sortings = ['Sort by Default', 'Newest', 'Oldest', 'Popular', 'Price (Low to High)', 'Price (High to Low)', 'Price per m2 (Low to High)', 'Price per m2 (High to Low)', 'Factor (Low to High)', 'Factor (High to Low)'];
        this.sortStorage = temporaryStorageService.forKey(this.prefix + "_sort");
        this.countStorage = temporaryStorageService.forKey(this.prefix + "_count");
        this.viewStorage = temporaryStorageService.forKey(this.prefix + "_view");
    }
    ngOnInit() {
        this.count = (this.isHomePage) ? this.counts[0] : this.counts[1];
        this.sort = this.sortings[0];
        this.restoreFromTemporaryStorage();
    }
    ngOnChanges() {
        // console.log(' show toggle - ' ,this.showSidenavToggle)
    }
    changeCount(count) {
        this.count = count;
        this.onChangeCount.emit(count);
        // this.getAllProducts(); 
    }
    changeSorting(sort) {
        this.sort = sort;
        this.onChangeSorting.emit(sort);
    }
    changeViewType(viewType, viewCol) {
        this.viewType = viewType;
        this.viewCol = viewCol;
        this.onChangeViewType.emit({ viewType: viewType, viewCol: viewCol });
    }
    sidenavToggle() {
        this.onSidenavToggle.emit();
    }
    // I attempt to load persisted data from our Facet of the TemporaryStorageService
    // into the current view-model of the form-data.
    restoreFromTemporaryStorage() {
        return __awaiter(this, void 0, void 0, function* () {
            const sort = yield this.sortStorage.get();
            const count = yield this.countStorage.get();
            const view = yield this.viewStorage.get();
            if (sort) {
                this.sort = sort;
            }
            if (count) {
                this.count = count;
            }
            if (view && (view === null || view === void 0 ? void 0 : view.viewType) && (view === null || view === void 0 ? void 0 : view.viewCol)) {
                this.viewType = view.viewType;
                this.viewCol = view.viewCol;
                if (!this.isHomePage && this.viewType === 'grid' && this.viewCol === 25) {
                    this.viewCol = 33.3;
                }
            }
        });
    }
};
PropertiesToolbarComponent.ctorParameters = () => [
    { type: _services_temporary_storage_service__WEBPACK_IMPORTED_MODULE_1__["TemporaryStorageService"] }
];
PropertiesToolbarComponent.propDecorators = {
    prefix: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    isHomePage: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    showSidenavToggle: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    onSidenavToggle: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onChangeCount: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onChangeSorting: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onChangeViewType: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }]
};
PropertiesToolbarComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-properties-toolbar',
        template: __importDefault(__webpack_require__(/*! raw-loader!./properties-toolbar.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/properties-toolbar/properties-toolbar.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./properties-toolbar.component.scss */ "./src/app/shared/properties-toolbar/properties-toolbar.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_services_temporary_storage_service__WEBPACK_IMPORTED_MODULE_1__["TemporaryStorageService"]])
], PropertiesToolbarComponent);



/***/ }),

/***/ "./src/app/shared/property-item/property-item.component.scss":
/*!*******************************************************************!*\
  !*** ./src/app/shared/property-item/property-item.component.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".property-item {\n  height: 100%;\n  overflow: hidden;\n}\n.property-item .thumbnail-section {\n  position: relative;\n}\n.property-item .mat-card-image {\n  position: relative;\n  min-height: 180px;\n}\n.property-item .mat-card-image .swiper-container .swipe-arrow.mat-icon-button {\n  color: #fff;\n}\n.property-item .mat-card-image .swiper-container .swipe-arrow.mat-icon-button.swiper-button-next {\n  right: 4px;\n}\n.property-item .mat-card-image .swiper-container .swipe-arrow.mat-icon-button.swiper-button-prev {\n  left: 4px;\n}\n.property-item .mat-card-image .swiper-slide {\n  text-align: center;\n  padding-bottom: 66.25%;\n  position: relative;\n  overflow: hidden;\n  background: rgba(0, 0, 0, 0.04);\n}\n.property-item .mat-card-image img {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: auto;\n}\n.property-item .property-status {\n  position: absolute;\n  z-index: 2;\n}\n.property-item .property-status span {\n  padding: 3px 6px;\n  margin: 4px;\n  font-size: 12px;\n  color: #fff;\n  font-weight: 500;\n  text-transform: uppercase;\n  border-radius: 4px;\n}\n.property-item .title {\n  font-size: 18px;\n}\n.property-item .title a {\n  transition: 0.2s;\n  text-decoration: none;\n}\n.property-item .address, .property-item .date {\n  font-style: italic;\n  margin-top: 8px;\n}\n.property-item .address .mat-icon, .property-item .date .mat-icon {\n  margin-left: -4px;\n}\n.property-item .price span {\n  display: block;\n}\n.property-item .features p span:first-child {\n  float: left;\n  padding: 0 0.4em 0 0;\n}\n.property-item .features p span + span {\n  float: right;\n  padding: 0 0 0 0.4em;\n  font-weight: 500;\n}\n.property-item .features p:after {\n  content: \"\";\n  display: block;\n  overflow: hidden;\n  height: 1em;\n}\n.property-item .control-icons {\n  position: absolute;\n  z-index: 2;\n  right: 2px;\n  margin-top: -30px;\n}\n.property-item .control-icons button.mat-button {\n  min-width: 26px;\n  width: 26px;\n  line-height: 26px;\n  padding: 0;\n  margin: 0 4px;\n  background: rgba(255, 252, 252, 0.6);\n  transition: 0.2s;\n  color: rgba(0, 0, 0, 0.87);\n}\n.property-item .control-icons button.mat-button:disabled {\n  color: rgba(0, 0, 0, 0.26);\n}\n.property-item .control-icons button.mat-button:hover:enabled {\n  background: #fffcfc;\n}\n.property-item.grid-item {\n  flex-flow: column !important;\n}\n.property-item.grid-item.column-2 .title {\n  font-size: 22px;\n}\n.property-item.grid-item.column-2 .price {\n  font-size: 18px;\n}\n.property-item.grid-item.column-3 .title {\n  font-size: 18px;\n}\n.property-item.grid-item.column-3 .address, .property-item.grid-item.column-3 .date {\n  font-size: 12px;\n}\n.property-item.grid-item.column-3 .address .mat-icon, .property-item.grid-item.column-3 .date .mat-icon {\n  font-size: 18px;\n  width: 18px;\n  height: 18px;\n}\n.property-item.grid-item.full-width-page.column-2 .title {\n  font-size: 28px;\n}\n.property-item.grid-item.full-width-page.column-2 .price {\n  font-size: 20px;\n}\n.property-item.grid-item.full-width-page.column-3 .title {\n  font-size: 22px;\n}\n.property-item.grid-item.full-width-page.column-3 .address, .property-item.grid-item.full-width-page.column-3 .date {\n  font-size: 14px;\n}\n.property-item.grid-item.full-width-page.column-3 .address .mat-icon, .property-item.grid-item.full-width-page.column-3 .date .mat-icon {\n  font-size: 24px;\n  width: 24px;\n  height: 24px;\n}\n.property-item.grid-item.full-width-page.column-3 .price {\n  font-size: 18px;\n}\n.property-item.grid-item.full-width-page.column-4 .title {\n  font-size: 18px;\n}\n.property-item.grid-item.full-width-page.column-4 .address, .property-item.grid-item.full-width-page.column-4 .date {\n  font-size: 12px;\n}\n.property-item.grid-item.full-width-page.column-4 .address .mat-icon, .property-item.grid-item.full-width-page.column-4 .date .mat-icon {\n  font-size: 18px;\n  width: 18px;\n  height: 18px;\n}\n.property-item.list-item .title {\n  font-size: 28px;\n  margin-top: -8px;\n}\n.property-item.list-item .price {\n  font-size: 20px;\n}\n.property-item.list-item .features {\n  display: flex;\n  flex-flow: wrap;\n}\n.property-item.list-item .features p {\n  margin-right: 24px;\n  display: flex;\n  white-space: nowrap;\n}\n.property-item.list-item .features p span:first-child:after {\n  content: \":\";\n  margin: 0 1px;\n}\n.property-item.list-item .features p:after {\n  content: none;\n}\n@media screen and (max-width: 959px) {\n  .property-item.grid-item .title {\n    font-size: 22px;\n  }\n  .property-item.grid-item.column-2 .title {\n    font-size: 22px;\n  }\n  .property-item.grid-item.full-width-page.column-2 .title {\n    font-size: 22px;\n  }\n  .property-item.list-item .title {\n    font-size: 22px;\n  }\n  .property-item.list-item .address, .property-item.list-item .date {\n    font-size: 12px;\n  }\n  .property-item.list-item .address .mat-icon, .property-item.list-item .date .mat-icon {\n    font-size: 18px;\n    width: 18px;\n    height: 18px;\n  }\n  .property-item.list-item .price {\n    font-size: 18px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3Byb3BlcnR5LWl0ZW0vcHJvcGVydHktaXRlbS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7RUFDQSxnQkFBQTtBQUNKO0FBQUk7RUFDSSxrQkFBQTtBQUVSO0FBQUk7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0FBRVI7QUFBWTtFQUNJLFdBQUE7QUFFaEI7QUFEZ0I7RUFDSSxVQUFBO0FBR3BCO0FBRGdCO0VBQ0ksU0FBQTtBQUdwQjtBQUNRO0VBQ0ksa0JBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSwrQkFBQTtBQUNaO0FBQ1E7RUFDSSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFDWjtBQUVJO0VBQ0ksa0JBQUE7RUFDQSxVQUFBO0FBQVI7QUFDUTtFQUNJLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0FBQ1o7QUFFSTtFQUNJLGVBQUE7QUFBUjtBQUNRO0VBQ0ksZ0JBQUE7RUFDQSxxQkFBQTtBQUNaO0FBRUk7RUFDSSxrQkFBQTtFQUNBLGVBQUE7QUFBUjtBQUNRO0VBQ0ksaUJBQUE7QUFDWjtBQUdRO0VBQ0ksY0FBQTtBQURaO0FBTVk7RUFDSSxXQUFBO0VBQ0Esb0JBQUE7QUFKaEI7QUFNWTtFQUNJLFlBQUE7RUFDQSxvQkFBQTtFQUNBLGdCQUFBO0FBSmhCO0FBT1E7RUFDSSxXQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtBQUxaO0FBUUk7RUFDSSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxVQUFBO0VBQ0EsaUJBQUE7QUFOUjtBQU9RO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0VBQ0Esb0NBQUE7RUFDQSxnQkFBQTtFQUNBLDBCQUFBO0FBTFo7QUFNWTtFQUNJLDBCQUFBO0FBSmhCO0FBTVk7RUFDSSxtQkFBQTtBQUpoQjtBQVFJO0VBQ0ksNEJBQUE7QUFOUjtBQVFZO0VBQ0ksZUFBQTtBQU5oQjtBQVFZO0VBQ0ksZUFBQTtBQU5oQjtBQVVZO0VBQ0ksZUFBQTtBQVJoQjtBQVVZO0VBQ0ksZUFBQTtBQVJoQjtBQVNnQjtFQUNJLGVBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQVBwQjtBQWFnQjtFQUNJLGVBQUE7QUFYcEI7QUFhZ0I7RUFDSSxlQUFBO0FBWHBCO0FBZWdCO0VBQ0ksZUFBQTtBQWJwQjtBQWVnQjtFQUNJLGVBQUE7QUFicEI7QUFjb0I7RUFDSSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFaeEI7QUFlZ0I7RUFDSSxlQUFBO0FBYnBCO0FBaUJnQjtFQUNJLGVBQUE7QUFmcEI7QUFpQmdCO0VBQ0ksZUFBQTtBQWZwQjtBQWdCb0I7RUFDSSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFkeEI7QUFxQlE7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7QUFuQlo7QUFxQlE7RUFDSSxlQUFBO0FBbkJaO0FBcUJRO0VBQ0ksYUFBQTtFQUNBLGVBQUE7QUFuQlo7QUFvQlk7RUFDSSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQWxCaEI7QUFtQmdCO0VBQ0ksWUFBQTtFQUNBLGFBQUE7QUFqQnBCO0FBbUJnQjtFQUNJLGFBQUE7QUFqQnBCO0FBMkJBO0VBR1k7SUFDSSxlQUFBO0VBMUJkO0VBNkJjO0lBQ0ksZUFBQTtFQTNCbEI7RUFnQ2tCO0lBQ0ksZUFBQTtFQTlCdEI7RUFvQ1U7SUFDSSxlQUFBO0VBbENkO0VBb0NVO0lBQ0ksZUFBQTtFQWxDZDtFQW1DYztJQUNJLGVBQUE7SUFDQSxXQUFBO0lBQ0EsWUFBQTtFQWpDbEI7RUFvQ1U7SUFDSSxlQUFBO0VBbENkO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvcHJvcGVydHktaXRlbS9wcm9wZXJ0eS1pdGVtLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnByb3BlcnR5LWl0ZW17XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgLnRodW1ibmFpbC1zZWN0aW9ue1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgfVxuICAgIC5tYXQtY2FyZC1pbWFnZXtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICBtaW4taGVpZ2h0OiAxODBweDtcbiAgICAgICAgLnN3aXBlci1jb250YWluZXJ7XG4gICAgICAgICAgICAuc3dpcGUtYXJyb3cubWF0LWljb24tYnV0dG9ue1xuICAgICAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICAgICAgICAgICYuc3dpcGVyLWJ1dHRvbi1uZXh0e1xuICAgICAgICAgICAgICAgICAgICByaWdodDogNHB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAmLnN3aXBlci1idXR0b24tcHJldntcbiAgICAgICAgICAgICAgICAgICAgbGVmdDogNHB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAuc3dpcGVyLXNsaWRleyAgICAgICAgICAgICAgXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogNjYuMjUlO1xuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjsgIFxuICAgICAgICAgICAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjA0KTsgICAgICAgICAgXG4gICAgICAgIH1cbiAgICAgICAgaW1ne1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgdG9wOiAwO1xuICAgICAgICAgICAgbGVmdDogMDtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgICAgICB9IFxuICAgIH1cbiAgICAucHJvcGVydHktc3RhdHVze1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHotaW5kZXg6IDI7XG4gICAgICAgIHNwYW57XG4gICAgICAgICAgICBwYWRkaW5nOiAzcHggNnB4O1xuICAgICAgICAgICAgbWFyZ2luOiA0cHg7XG4gICAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xuICAgICAgICB9XG4gICAgfVxuICAgIC50aXRsZXsgXG4gICAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgICAgYXtcbiAgICAgICAgICAgIHRyYW5zaXRpb246IDAuMnM7XG4gICAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLmFkZHJlc3MsIC5kYXRle1xuICAgICAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgICAgIG1hcmdpbi10b3A6IDhweDtcbiAgICAgICAgLm1hdC1pY29ue1xuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IC00cHg7XG4gICAgICAgIH1cbiAgICB9ICBcbiAgICAucHJpY2V7IFxuICAgICAgICBzcGFue1xuICAgICAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICAgIH1cbiAgICB9ICBcbiAgICAuZmVhdHVyZXMgcCB7XG4gICAgICAgIHNwYW57XG4gICAgICAgICAgICAmOmZpcnN0LWNoaWxkIHtcbiAgICAgICAgICAgICAgICBmbG9hdDogbGVmdDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwIC40ZW0gMCAwO1x0XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICArIHNwYW4ge1xuICAgICAgICAgICAgICAgIGZsb2F0OiByaWdodDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwIDAgMCAuNGVtO1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHRcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAmOmFmdGVyIHtcbiAgICAgICAgICAgIGNvbnRlbnQ6IFwiXCI7XG4gICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgICAgICBoZWlnaHQ6IDFlbTsgXG4gICAgICAgIH1cbiAgICB9XG4gICAgLmNvbnRyb2wtaWNvbnN7IFxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHotaW5kZXg6IDI7IFxuICAgICAgICByaWdodDogMnB4O1xuICAgICAgICBtYXJnaW4tdG9wOiAtMzBweDtcbiAgICAgICAgYnV0dG9uLm1hdC1idXR0b257XG4gICAgICAgICAgICBtaW4td2lkdGg6IDI2cHg7XG4gICAgICAgICAgICB3aWR0aDogMjZweDtcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAyNnB4O1xuICAgICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgICAgIG1hcmdpbjogMCA0cHg7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjUyLCAyNTIsIDAuNik7XG4gICAgICAgICAgICB0cmFuc2l0aW9uOiAwLjJzOyBcbiAgICAgICAgICAgIGNvbG9yOnJnYmEoMCwgMCwgMCwgMC44Nyk7XG4gICAgICAgICAgICAmOmRpc2FibGVke1xuICAgICAgICAgICAgICAgIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuMjYpOyBcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgICY6aG92ZXI6ZW5hYmxlZHtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjUyLCAyNTIsIDEpO1xuICAgICAgICAgICAgfSAgICAgICAgICAgICBcbiAgICAgICAgfVxuICAgIH1cbiAgICAmLmdyaWQtaXRlbXtcbiAgICAgICAgZmxleC1mbG93OiBjb2x1bW4gIWltcG9ydGFudDtcbiAgICAgICAgJi5jb2x1bW4tMntcbiAgICAgICAgICAgIC50aXRsZXtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDIycHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAucHJpY2V7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgICYuY29sdW1uLTN7XG4gICAgICAgICAgICAudGl0bGV7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLmFkZHJlc3MsIC5kYXRle1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgICAgICAubWF0LWljb257XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDE4cHg7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMThweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgJi5mdWxsLXdpZHRoLXBhZ2V7XG4gICAgICAgICAgICAmLmNvbHVtbi0ye1xuICAgICAgICAgICAgICAgIC50aXRsZXtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyOHB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAucHJpY2V7XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAmLmNvbHVtbi0ze1xuICAgICAgICAgICAgICAgIC50aXRsZXtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMnB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAuYWRkcmVzcywgLmRhdGV7XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICAgICAgICAgICAgLm1hdC1pY29ue1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDI0cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDI0cHg7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLnByaWNle1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgJi5jb2x1bW4tNHtcbiAgICAgICAgICAgICAgICAudGl0bGV7XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLmFkZHJlc3MsIC5kYXRle1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgICAgICAgICAgICAgIC5tYXQtaWNvbntcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxOHB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAxOHB4O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgICYubGlzdC1pdGVteyBcbiAgICAgICAgLnRpdGxle1xuICAgICAgICAgICAgZm9udC1zaXplOiAyOHB4O1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogLThweDtcbiAgICAgICAgfVxuICAgICAgICAucHJpY2V7XG4gICAgICAgICAgICBmb250LXNpemU6IDIwcHg7IFxuICAgICAgICB9XG4gICAgICAgIC5mZWF0dXJlc3tcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBmbGV4LWZsb3c6IHdyYXA7XG4gICAgICAgICAgICBwe1xuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMjRweDtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgICAgICAgICAgICAgc3BhbjpmaXJzdC1jaGlsZDphZnRlciB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6IFwiOlwiO1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDAgMXB4O1x0XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICY6YWZ0ZXIge1xuICAgICAgICAgICAgICAgICAgICBjb250ZW50OiBub25lO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuIFxufVxuXG5cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDk1OXB4KSB7XG4gICAgLnByb3BlcnR5LWl0ZW17XG4gICAgICAgICYuZ3JpZC1pdGVte1xuICAgICAgICAgICAgLnRpdGxle1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjJweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgICYuY29sdW1uLTJ7XG4gICAgICAgICAgICAgICAgLnRpdGxle1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDIycHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgJi5mdWxsLXdpZHRoLXBhZ2V7XG4gICAgICAgICAgICAgICAgJi5jb2x1bW4tMntcbiAgICAgICAgICAgICAgICAgICAgLnRpdGxle1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMnB4O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgICYubGlzdC1pdGVte1xuICAgICAgICAgICAgLnRpdGxle1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjJweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC5hZGRyZXNzLCAuZGF0ZXtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgICAgICAgICAgLm1hdC1pY29ue1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxOHB4O1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDE4cHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLnByaWNle1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIFxuICAgIH1cblxufSJdfQ== */");

/***/ }),

/***/ "./src/app/shared/property-item/property-item.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/shared/property-item/property-item.component.ts ***!
  \*****************************************************************/
/*! exports provided: PropertyItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PropertyItemComponent", function() { return PropertyItemComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ngx-swiper-wrapper */ "./node_modules/ngx-swiper-wrapper/__ivy_ngcc__/dist/ngx-swiper-wrapper.es5.js");
/* harmony import */ var _app_models__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../app.models */ "./src/app/app.models.ts");
/* harmony import */ var _app_settings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../app.settings */ "./src/app/app.settings.ts");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../app.service */ "./src/app/app.service.ts");
/* harmony import */ var _compare_overview_compare_overview_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../compare-overview/compare-overview.component */ "./src/app/shared/compare-overview/compare-overview.component.ts");
/* harmony import */ var ngx_lightbox__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-lightbox */ "./node_modules/ngx-lightbox/__ivy_ngcc__/index.js");
/* harmony import */ var ngx_lightbox__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(ngx_lightbox__WEBPACK_IMPORTED_MODULE_6__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};







let PropertyItemComponent = class PropertyItemComponent {
    constructor(appSettings, _lightbox, appService) {
        this.appSettings = appSettings;
        this._lightbox = _lightbox;
        this.appService = appService;
        this.viewType = "grid";
        this.viewColChanged = false;
        this.fullWidthPage = true;
        this.albums = [];
        this.column = 4;
        this.config = {};
        this.pagination = {
            el: '.swiper-pagination',
            clickable: true
        };
        this.settings = this.appSettings.settings;
    }
    ngOnInit() {
    }
    ngAfterViewInit() {
        this.initCarousel();
        if (this.property.gallery.length) {
            for (let i = 0; i < this.property.gallery.length; i++) {
                const album = {
                    src: this.property.gallery[i].big,
                    caption: "",
                    thumb: this.property.gallery[i].medium
                };
                this.albums.push(album);
            }
        }
        // this.appService.getAddress(this.property.location.lat, this.property.location.lng).subscribe(data=>{
        //   console.log(data['results'][0]['formatted_address']);
        //   this.address = data['results'][0]['formatted_address'];
        // })
    }
    ngOnChanges(changes) {
        if (changes.viewColChanged) {
            this.getColumnCount(changes.viewColChanged.currentValue);
            if (!changes.viewColChanged.isFirstChange()) {
                if (this.property.gallery.length > 1) {
                    this.directiveRef.update();
                }
            }
        }
        for (let propName in changes) {
            // let changedProp = changes[propName];
            // if (!changedProp.isFirstChange()) {
            //   if(this.property.gallery.length > 1){
            //     this.initCarousel();
            //     this.config.autoHeight = true;       
            //     this.directiveRef.update();  
            //   }       
            // }      
        }
    }
    getColumnCount(value) {
        if (value == 25) {
            this.column = 4;
        }
        else if (value == 33.3) {
            this.column = 3;
        }
        else if (value == 50) {
            this.column = 2;
        }
        else {
            this.column = 1;
        }
    }
    getStatusBgColor(status) {
        switch (status) {
            case 'For Sale':
                return '#558B2F';
            case 'For Rent':
                return '#1E88E5';
            case 'Open House':
                return '#009688';
            case 'No Fees':
                return '#FFA000';
            case 'Hot Offer':
                return '#F44336';
            case 'Sold':
                return '#000';
            default:
                return '#01579B';
        }
    }
    initCarousel() {
        this.config = {
            slidesPerView: 1,
            spaceBetween: 0,
            keyboard: false,
            navigation: true,
            pagination: this.pagination,
            grabCursor: true,
            loop: true,
            preloadImages: false,
            lazy: true,
            nested: true,
            // autoplay: {
            //   delay: 5000,
            //   disableOnInteraction: false
            // },
            speed: 500,
            effect: "slide"
        };
    }
    openImage(index) {
        //console.log(this.albums);
        this._lightbox.open(this.albums, index);
    }
    close() {
        // close lightbox programmatically
        this._lightbox.close();
    }
    addToCompare() {
        this.appService.addToCompare(this.property, _compare_overview_compare_overview_component__WEBPACK_IMPORTED_MODULE_5__["CompareOverviewComponent"], (this.settings.rtl) ? 'rtl' : 'ltr');
    }
    onCompare() {
        return this.appService.Data.compareList.filter(item => item.id == this.property.id)[0];
    }
    addToFavorites() {
        this.appService.addToFavorites(this.property, (this.settings.rtl) ? 'rtl' : 'ltr');
    }
    onFavorites() {
        return this.appService.Data.favorites.filter(item => item.id == this.property.id)[0];
    }
};
PropertyItemComponent.ctorParameters = () => [
    { type: _app_settings__WEBPACK_IMPORTED_MODULE_3__["AppSettings"] },
    { type: ngx_lightbox__WEBPACK_IMPORTED_MODULE_6__["Lightbox"] },
    { type: _app_service__WEBPACK_IMPORTED_MODULE_4__["AppService"] }
];
PropertyItemComponent.propDecorators = {
    property: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    viewType: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    viewColChanged: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    fullWidthPage: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    directiveRef: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"], args: [ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_1__["SwiperDirective"],] }]
};
PropertyItemComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-property-item',
        template: __importDefault(__webpack_require__(/*! raw-loader!./property-item.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/property-item/property-item.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./property-item.component.scss */ "./src/app/shared/property-item/property-item.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_app_settings__WEBPACK_IMPORTED_MODULE_3__["AppSettings"], ngx_lightbox__WEBPACK_IMPORTED_MODULE_6__["Lightbox"], _app_service__WEBPACK_IMPORTED_MODULE_4__["AppService"]])
], PropertyItemComponent);



/***/ }),

/***/ "./src/app/shared/rating/rating.component.scss":
/*!*****************************************************!*\
  !*** ./src/app/shared/rating/rating.component.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ratings {\n  color: #fbc02d;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3JhdGluZy9yYXRpbmcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0FBQ0oiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvcmF0aW5nL3JhdGluZy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yYXRpbmdze1xuICAgIGNvbG9yOiNmYmMwMmQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/shared/rating/rating.component.ts":
/*!***************************************************!*\
  !*** ./src/app/shared/rating/rating.component.ts ***!
  \***************************************************/
/*! exports provided: RatingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RatingComponent", function() { return RatingComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

let RatingComponent = class RatingComponent {
    constructor() { }
    ngDoCheck() {
        if (this.ratingsCount && this.ratingsValue && !this.avg) {
            this.calculateAvgValue();
        }
    }
    calculateAvgValue() {
        this.avg = this.ratingsValue / this.ratingsCount;
        switch (true) {
            case this.avg > 0 && this.avg < 20: {
                this.stars = ['star_half', 'star_border', 'star_border', 'star_border', 'star_border'];
                break;
            }
            case this.avg == 20: {
                this.stars = ['star', 'star_border', 'star_border', 'star_border', 'star_border'];
                break;
            }
            case this.avg > 20 && this.avg < 40: {
                this.stars = ['star', 'star_half', 'star_border', 'star_border', 'star_border'];
                break;
            }
            case this.avg == 40: {
                this.stars = ['star', 'star', 'star_border', 'star_border', 'star_border'];
                break;
            }
            case this.avg > 40 && this.avg < 60: {
                this.stars = ['star', 'star', 'star_half', 'star_border', 'star_border'];
                break;
            }
            case this.avg == 60: {
                this.stars = ['star', 'star', 'star', 'star_border', 'star_border'];
                break;
            }
            case this.avg > 60 && this.avg < 80: {
                this.stars = ['star', 'star', 'star', 'star_half', 'star_border'];
                break;
            }
            case this.avg == 80: {
                this.stars = ['star', 'star', 'star', 'star', 'star_border'];
                break;
            }
            case this.avg > 80 && this.avg < 100: {
                this.stars = ['star', 'star', 'star', 'star', 'star_half'];
                break;
            }
            case this.avg >= 100: {
                this.stars = ['star', 'star', 'star', 'star', 'star'];
                break;
            }
            default: {
                this.stars = ['star_border', 'star_border', 'star_border', 'star_border', 'star_border'];
                break;
            }
        }
    }
};
RatingComponent.ctorParameters = () => [];
RatingComponent.propDecorators = {
    ratingsCount: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    ratingsValue: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }]
};
RatingComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-rating',
        template: __importDefault(__webpack_require__(/*! raw-loader!./rating.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/rating/rating.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./rating.component.scss */ "./src/app/shared/rating/rating.component.scss")).default]
    }),
    __metadata("design:paramtypes", [])
], RatingComponent);



/***/ }),

/***/ "./src/app/shared/shared.module.ts":
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/*! exports provided: SharedModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedModule", function() { return SharedModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-swiper-wrapper */ "./node_modules/ngx-swiper-wrapper/__ivy_ngcc__/dist/ngx-swiper-wrapper.es5.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/__ivy_ngcc__/esm2015/flex-layout.js");
/* harmony import */ var _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/autocomplete */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/autocomplete.js");
/* harmony import */ var _angular_material_badge__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/badge */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/badge.js");
/* harmony import */ var _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/bottom-sheet */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/bottom-sheet.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button.js");
/* harmony import */ var _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/button-toggle */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/button-toggle.js");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/card.js");
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/checkbox */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/checkbox.js");
/* harmony import */ var _angular_material_chips__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/chips */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/chips.js");
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/core */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/datepicker */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/datepicker.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/dialog.js");
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/expansion */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/expansion.js");
/* harmony import */ var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/grid-list */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/grid-list.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/icon.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/input.js");
/* harmony import */ var _angular_material_list__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material/list */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/list.js");
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/material/menu */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/menu.js");
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/material/paginator */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/paginator.js");
/* harmony import */ var _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/material/progress-bar */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/progress-bar.js");
/* harmony import */ var _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/material/progress-spinner */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/progress-spinner.js");
/* harmony import */ var _angular_material_radio__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/material/radio */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/radio.js");
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/material/select */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/select.js");
/* harmony import */ var _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/material/sidenav */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/sidenav.js");
/* harmony import */ var _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/material/slide-toggle */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/slide-toggle.js");
/* harmony import */ var _angular_material_slider__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @angular/material/slider */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/slider.js");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @angular/material/snack-bar */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/snack-bar.js");
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @angular/material/sort */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/sort.js");
/* harmony import */ var _angular_material_stepper__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @angular/material/stepper */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/stepper.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/table.js");
/* harmony import */ var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @angular/material/tabs */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/tabs.js");
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/material/toolbar */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/toolbar.js");
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @angular/material/tooltip */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/tooltip.js");
/* harmony import */ var ngx_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ngx-perfect-scrollbar */ "./node_modules/ngx-perfect-scrollbar/__ivy_ngcc__/fesm2015/ngx-perfect-scrollbar.js");
/* harmony import */ var _theme_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ../theme/pipes/pipes.module */ "./src/app/theme/pipes/pipes.module.ts");
/* harmony import */ var _theme_directives_directives_module__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ../theme/directives/directives.module */ "./src/app/theme/directives/directives.module.ts");
/* harmony import */ var _header_image_header_image_component__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./header-image/header-image.component */ "./src/app/shared/header-image/header-image.component.ts");
/* harmony import */ var _header_carousel_header_carousel_component__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./header-carousel/header-carousel.component */ "./src/app/shared/header-carousel/header-carousel.component.ts");
/* harmony import */ var _property_item_property_item_component__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./property-item/property-item.component */ "./src/app/shared/property-item/property-item.component.ts");
/* harmony import */ var _load_more_load_more_component__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./load-more/load-more.component */ "./src/app/shared/load-more/load-more.component.ts");
/* harmony import */ var _properties_toolbar_properties_toolbar_component__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ./properties-toolbar/properties-toolbar.component */ "./src/app/shared/properties-toolbar/properties-toolbar.component.ts");
/* harmony import */ var _properties_search_properties_search_component__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! ./properties-search/properties-search.component */ "./src/app/shared/properties-search/properties-search.component.ts");
/* harmony import */ var _compare_overview_compare_overview_component__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ./compare-overview/compare-overview.component */ "./src/app/shared/compare-overview/compare-overview.component.ts");
/* harmony import */ var _rating_rating_component__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ./rating/rating.component */ "./src/app/shared/rating/rating.component.ts");
/* harmony import */ var _properties_search_results_filters_properties_search_results_filters_component__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! ./properties-search-results-filters/properties-search-results-filters.component */ "./src/app/shared/properties-search-results-filters/properties-search-results-filters.component.ts");
/* harmony import */ var _properties_carousel_properties_carousel_component__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! ./properties-carousel/properties-carousel.component */ "./src/app/shared/properties-carousel/properties-carousel.component.ts");
/* harmony import */ var _clients_clients_component__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! ./clients/clients.component */ "./src/app/shared/clients/clients.component.ts");
/* harmony import */ var _get_in_touch_get_in_touch_component__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! ./get-in-touch/get-in-touch.component */ "./src/app/shared/get-in-touch/get-in-touch.component.ts");
/* harmony import */ var _comments_comments_component__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! ./comments/comments.component */ "./src/app/shared/comments/comments.component.ts");
/* harmony import */ var _testimonials_testimonials_component__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! ./testimonials/testimonials.component */ "./src/app/shared/testimonials/testimonials.component.ts");
/* harmony import */ var _our_agents_our_agents_component__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! ./our-agents/our-agents.component */ "./src/app/shared/our-agents/our-agents.component.ts");
/* harmony import */ var _mission_mission_component__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! ./mission/mission.component */ "./src/app/shared/mission/mission.component.ts");
/* harmony import */ var _our_services_our_services_component__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(/*! ./our-services/our-services.component */ "./src/app/shared/our-services/our-services.component.ts");
/* harmony import */ var _logo_logo_component__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(/*! ./logo/logo.component */ "./src/app/shared/logo/logo.component.ts");
/* harmony import */ var _back_button_back_button_component__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(/*! ./back-button/back-button.component */ "./src/app/shared/back-button/back-button.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};








































const DEFAULT_PERFECT_SCROLLBAR_CONFIG = {
    wheelPropagation: false,
    suppressScrollX: true
};





















let SharedModule = class SharedModule {
};
SharedModule = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_4__["SwiperModule"],
            _angular_flex_layout__WEBPACK_IMPORTED_MODULE_5__["FlexLayoutModule"],
            _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_6__["MatAutocompleteModule"],
            _angular_material_badge__WEBPACK_IMPORTED_MODULE_7__["MatBadgeModule"],
            _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_8__["MatBottomSheetModule"],
            _angular_material_button__WEBPACK_IMPORTED_MODULE_9__["MatButtonModule"],
            _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_10__["MatButtonToggleModule"],
            _angular_material_card__WEBPACK_IMPORTED_MODULE_11__["MatCardModule"],
            _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_12__["MatCheckboxModule"],
            _angular_material_chips__WEBPACK_IMPORTED_MODULE_13__["MatChipsModule"],
            _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_15__["MatDatepickerModule"],
            _angular_material_dialog__WEBPACK_IMPORTED_MODULE_16__["MatDialogModule"],
            _angular_material_expansion__WEBPACK_IMPORTED_MODULE_17__["MatExpansionModule"],
            _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_18__["MatGridListModule"],
            _angular_material_icon__WEBPACK_IMPORTED_MODULE_19__["MatIconModule"],
            _angular_material_input__WEBPACK_IMPORTED_MODULE_20__["MatInputModule"],
            _angular_material_list__WEBPACK_IMPORTED_MODULE_21__["MatListModule"],
            _angular_material_menu__WEBPACK_IMPORTED_MODULE_22__["MatMenuModule"],
            _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatNativeDateModule"],
            _angular_material_paginator__WEBPACK_IMPORTED_MODULE_23__["MatPaginatorModule"],
            _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_24__["MatProgressBarModule"],
            _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_25__["MatProgressSpinnerModule"],
            _angular_material_radio__WEBPACK_IMPORTED_MODULE_26__["MatRadioModule"],
            _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatRippleModule"],
            _angular_material_select__WEBPACK_IMPORTED_MODULE_27__["MatSelectModule"],
            _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_28__["MatSidenavModule"],
            _angular_material_slider__WEBPACK_IMPORTED_MODULE_30__["MatSliderModule"],
            _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_29__["MatSlideToggleModule"],
            _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_31__["MatSnackBarModule"],
            _angular_material_sort__WEBPACK_IMPORTED_MODULE_32__["MatSortModule"],
            _angular_material_table__WEBPACK_IMPORTED_MODULE_34__["MatTableModule"],
            _angular_material_tabs__WEBPACK_IMPORTED_MODULE_35__["MatTabsModule"],
            _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_36__["MatToolbarModule"],
            _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_37__["MatTooltipModule"],
            _angular_material_stepper__WEBPACK_IMPORTED_MODULE_33__["MatStepperModule"],
            ngx_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_38__["PerfectScrollbarModule"],
            _theme_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_39__["PipesModule"],
            _theme_directives_directives_module__WEBPACK_IMPORTED_MODULE_40__["DirectivesModule"]
        ],
        exports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            ngx_swiper_wrapper__WEBPACK_IMPORTED_MODULE_4__["SwiperModule"],
            _angular_flex_layout__WEBPACK_IMPORTED_MODULE_5__["FlexLayoutModule"],
            _angular_material_autocomplete__WEBPACK_IMPORTED_MODULE_6__["MatAutocompleteModule"],
            _angular_material_badge__WEBPACK_IMPORTED_MODULE_7__["MatBadgeModule"],
            _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_8__["MatBottomSheetModule"],
            _angular_material_button__WEBPACK_IMPORTED_MODULE_9__["MatButtonModule"],
            _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_10__["MatButtonToggleModule"],
            _angular_material_card__WEBPACK_IMPORTED_MODULE_11__["MatCardModule"],
            _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_12__["MatCheckboxModule"],
            _angular_material_chips__WEBPACK_IMPORTED_MODULE_13__["MatChipsModule"],
            _angular_material_datepicker__WEBPACK_IMPORTED_MODULE_15__["MatDatepickerModule"],
            _angular_material_dialog__WEBPACK_IMPORTED_MODULE_16__["MatDialogModule"],
            _angular_material_expansion__WEBPACK_IMPORTED_MODULE_17__["MatExpansionModule"],
            _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_18__["MatGridListModule"],
            _angular_material_icon__WEBPACK_IMPORTED_MODULE_19__["MatIconModule"],
            _angular_material_input__WEBPACK_IMPORTED_MODULE_20__["MatInputModule"],
            _angular_material_list__WEBPACK_IMPORTED_MODULE_21__["MatListModule"],
            _angular_material_menu__WEBPACK_IMPORTED_MODULE_22__["MatMenuModule"],
            _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatNativeDateModule"],
            _angular_material_paginator__WEBPACK_IMPORTED_MODULE_23__["MatPaginatorModule"],
            _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_24__["MatProgressBarModule"],
            _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_25__["MatProgressSpinnerModule"],
            _angular_material_radio__WEBPACK_IMPORTED_MODULE_26__["MatRadioModule"],
            _angular_material_core__WEBPACK_IMPORTED_MODULE_14__["MatRippleModule"],
            _angular_material_select__WEBPACK_IMPORTED_MODULE_27__["MatSelectModule"],
            _angular_material_sidenav__WEBPACK_IMPORTED_MODULE_28__["MatSidenavModule"],
            _angular_material_slider__WEBPACK_IMPORTED_MODULE_30__["MatSliderModule"],
            _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_29__["MatSlideToggleModule"],
            _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_31__["MatSnackBarModule"],
            _angular_material_sort__WEBPACK_IMPORTED_MODULE_32__["MatSortModule"],
            _angular_material_table__WEBPACK_IMPORTED_MODULE_34__["MatTableModule"],
            _angular_material_tabs__WEBPACK_IMPORTED_MODULE_35__["MatTabsModule"],
            _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_36__["MatToolbarModule"],
            _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_37__["MatTooltipModule"],
            _angular_material_stepper__WEBPACK_IMPORTED_MODULE_33__["MatStepperModule"],
            ngx_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_38__["PerfectScrollbarModule"],
            _theme_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_39__["PipesModule"],
            _theme_directives_directives_module__WEBPACK_IMPORTED_MODULE_40__["DirectivesModule"],
            _logo_logo_component__WEBPACK_IMPORTED_MODULE_58__["LogoComponent"],
            _back_button_back_button_component__WEBPACK_IMPORTED_MODULE_59__["BackButtonComponent"],
            _header_image_header_image_component__WEBPACK_IMPORTED_MODULE_41__["HeaderImageComponent"],
            _header_carousel_header_carousel_component__WEBPACK_IMPORTED_MODULE_42__["HeaderCarouselComponent"],
            _property_item_property_item_component__WEBPACK_IMPORTED_MODULE_43__["PropertyItemComponent"],
            _load_more_load_more_component__WEBPACK_IMPORTED_MODULE_44__["LoadMoreComponent"],
            _properties_toolbar_properties_toolbar_component__WEBPACK_IMPORTED_MODULE_45__["PropertiesToolbarComponent"],
            _properties_search_properties_search_component__WEBPACK_IMPORTED_MODULE_46__["PropertiesSearchComponent"],
            _compare_overview_compare_overview_component__WEBPACK_IMPORTED_MODULE_47__["CompareOverviewComponent"],
            _rating_rating_component__WEBPACK_IMPORTED_MODULE_48__["RatingComponent"],
            _properties_search_results_filters_properties_search_results_filters_component__WEBPACK_IMPORTED_MODULE_49__["PropertiesSearchResultsFiltersComponent"],
            _properties_carousel_properties_carousel_component__WEBPACK_IMPORTED_MODULE_50__["PropertiesCarouselComponent"],
            _clients_clients_component__WEBPACK_IMPORTED_MODULE_51__["ClientsComponent"],
            _get_in_touch_get_in_touch_component__WEBPACK_IMPORTED_MODULE_52__["GetInTouchComponent"],
            _comments_comments_component__WEBPACK_IMPORTED_MODULE_53__["CommentsComponent"],
            _testimonials_testimonials_component__WEBPACK_IMPORTED_MODULE_54__["TestimonialsComponent"],
            _our_agents_our_agents_component__WEBPACK_IMPORTED_MODULE_55__["OurAgentsComponent"],
            _mission_mission_component__WEBPACK_IMPORTED_MODULE_56__["MissionComponent"],
            _our_services_our_services_component__WEBPACK_IMPORTED_MODULE_57__["OurServicesComponent"]
        ],
        declarations: [
            _logo_logo_component__WEBPACK_IMPORTED_MODULE_58__["LogoComponent"],
            _back_button_back_button_component__WEBPACK_IMPORTED_MODULE_59__["BackButtonComponent"],
            _header_image_header_image_component__WEBPACK_IMPORTED_MODULE_41__["HeaderImageComponent"],
            _header_carousel_header_carousel_component__WEBPACK_IMPORTED_MODULE_42__["HeaderCarouselComponent"],
            _property_item_property_item_component__WEBPACK_IMPORTED_MODULE_43__["PropertyItemComponent"],
            _load_more_load_more_component__WEBPACK_IMPORTED_MODULE_44__["LoadMoreComponent"],
            _properties_toolbar_properties_toolbar_component__WEBPACK_IMPORTED_MODULE_45__["PropertiesToolbarComponent"],
            _properties_search_properties_search_component__WEBPACK_IMPORTED_MODULE_46__["PropertiesSearchComponent"],
            _compare_overview_compare_overview_component__WEBPACK_IMPORTED_MODULE_47__["CompareOverviewComponent"],
            _rating_rating_component__WEBPACK_IMPORTED_MODULE_48__["RatingComponent"],
            _properties_search_results_filters_properties_search_results_filters_component__WEBPACK_IMPORTED_MODULE_49__["PropertiesSearchResultsFiltersComponent"],
            _properties_carousel_properties_carousel_component__WEBPACK_IMPORTED_MODULE_50__["PropertiesCarouselComponent"],
            _clients_clients_component__WEBPACK_IMPORTED_MODULE_51__["ClientsComponent"],
            _get_in_touch_get_in_touch_component__WEBPACK_IMPORTED_MODULE_52__["GetInTouchComponent"],
            _comments_comments_component__WEBPACK_IMPORTED_MODULE_53__["CommentsComponent"],
            _testimonials_testimonials_component__WEBPACK_IMPORTED_MODULE_54__["TestimonialsComponent"],
            _our_agents_our_agents_component__WEBPACK_IMPORTED_MODULE_55__["OurAgentsComponent"],
            _mission_mission_component__WEBPACK_IMPORTED_MODULE_56__["MissionComponent"],
            _our_services_our_services_component__WEBPACK_IMPORTED_MODULE_57__["OurServicesComponent"]
        ],
        entryComponents: [
            _compare_overview_compare_overview_component__WEBPACK_IMPORTED_MODULE_47__["CompareOverviewComponent"]
        ],
        providers: [
            { provide: ngx_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_38__["PERFECT_SCROLLBAR_CONFIG"], useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG }
        ]
    })
], SharedModule);



/***/ }),

/***/ "./src/app/shared/testimonials/testimonials.component.scss":
/*!*****************************************************************!*\
  !*** ./src/app/shared/testimonials/testimonials.component.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".testimonials-carousel .swiper-container {\n  padding-bottom: 50px;\n}\n.testimonials-carousel .swiper-container .content {\n  max-width: 650px;\n  margin: 0 auto;\n}\n.testimonials-carousel .swiper-container .content img {\n  border-radius: 50%;\n  width: 140px;\n  height: 140px;\n}\n.testimonials-carousel .swiper-container .content .quote {\n  font-size: 50px;\n  line-height: 14px;\n}\n.testimonials-carousel .swiper-container .content .quote.open {\n  margin-top: 24px;\n}\n.testimonials-carousel .swiper-container .content .quote.close {\n  margin-bottom: 24px;\n}\n.testimonials-carousel .swiper-container .content .text {\n  font-weight: 500;\n}\n.testimonials-carousel .swiper-container .content .author {\n  text-transform: uppercase;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3Rlc3RpbW9uaWFscy90ZXN0aW1vbmlhbHMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSxvQkFBQTtBQUFSO0FBQ1E7RUFDSSxnQkFBQTtFQUNBLGNBQUE7QUFDWjtBQUFZO0VBQ0ksa0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQUVoQjtBQUFZO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FBRWhCO0FBRGdCO0VBQ0ksZ0JBQUE7QUFHcEI7QUFEZ0I7RUFDSSxtQkFBQTtBQUdwQjtBQUFZO0VBQ0ksZ0JBQUE7QUFFaEI7QUFBWTtFQUNJLHlCQUFBO0FBRWhCIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkL3Rlc3RpbW9uaWFscy90ZXN0aW1vbmlhbHMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGVzdGltb25pYWxzLWNhcm91c2VseyAgICBcbiAgICAuc3dpcGVyLWNvbnRhaW5lcntcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDUwcHg7XG4gICAgICAgIC5jb250ZW50e1xuICAgICAgICAgICAgbWF4LXdpZHRoOiA2NTBweDtcbiAgICAgICAgICAgIG1hcmdpbjogMCBhdXRvOyBcbiAgICAgICAgICAgIGltZ3tcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDE0MHB4O1xuICAgICAgICAgICAgICAgIGhlaWdodDogMTQwcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAucXVvdGV7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiA1MHB4OyBcbiAgICAgICAgICAgICAgICBsaW5lLWhlaWdodDogMTRweDsgXG4gICAgICAgICAgICAgICAgJi5vcGVue1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAyNHB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAmLmNsb3Nle1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAyNHB4O1xuICAgICAgICAgICAgICAgIH0gICAgICAgICAgIFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLnRleHR7IFxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7IFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLmF1dGhvcntcbiAgICAgICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufSJdfQ== */");

/***/ }),

/***/ "./src/app/shared/testimonials/testimonials.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/shared/testimonials/testimonials.component.ts ***!
  \***************************************************************/
/*! exports provided: TestimonialsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestimonialsComponent", function() { return TestimonialsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/app.service */ "./src/app/app.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let TestimonialsComponent = class TestimonialsComponent {
    constructor(appService) {
        this.appService = appService;
        this.config = {};
        this.pagination = {
            el: '.swiper-pagination',
            clickable: true
        };
    }
    ngOnInit() {
        this.testimonials = this.appService.getTestimonials();
    }
    ngAfterViewInit() {
        this.config = {
            observer: true,
            slidesPerView: 1,
            spaceBetween: 0,
            keyboard: true,
            navigation: true,
            pagination: this.pagination,
            grabCursor: true,
            loop: false,
            preloadImages: false,
            lazy: true,
        };
    }
};
TestimonialsComponent.ctorParameters = () => [
    { type: src_app_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"] }
];
TestimonialsComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-testimonials',
        template: __importDefault(__webpack_require__(/*! raw-loader!./testimonials.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/testimonials/testimonials.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./testimonials.component.scss */ "./src/app/shared/testimonials/testimonials.component.scss")).default]
    }),
    __metadata("design:paramtypes", [src_app_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]])
], TestimonialsComponent);



/***/ }),

/***/ "./src/app/theme/components/contacts/contacts.component.scss":
/*!*******************************************************************!*\
  !*** ./src/app/theme/components/contacts/contacts.component.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RoZW1lL2NvbXBvbmVudHMvY29udGFjdHMvY29udGFjdHMuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/theme/components/contacts/contacts.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/theme/components/contacts/contacts.component.ts ***!
  \*****************************************************************/
/*! exports provided: ContactsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactsComponent", function() { return ContactsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

let ContactsComponent = class ContactsComponent {
    constructor() {
        this.dividers = true;
        this.iconSize = 'sm';
        this.iconColor = '';
    }
    ngOnInit() {
    }
};
ContactsComponent.ctorParameters = () => [];
ContactsComponent.propDecorators = {
    dividers: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    iconSize: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    iconColor: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }]
};
ContactsComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-contacts',
        template: __importDefault(__webpack_require__(/*! raw-loader!./contacts.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/contacts/contacts.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./contacts.component.scss */ "./src/app/theme/components/contacts/contacts.component.scss")).default]
    }),
    __metadata("design:paramtypes", [])
], ContactsComponent);



/***/ }),

/***/ "./src/app/theme/components/currency/currency.component.scss":
/*!*******************************************************************!*\
  !*** ./src/app/theme/components/currency/currency.component.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RoZW1lL2NvbXBvbmVudHMvY3VycmVuY3kvY3VycmVuY3kuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/theme/components/currency/currency.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/theme/components/currency/currency.component.ts ***!
  \*****************************************************************/
/*! exports provided: CurrencyComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CurrencyComponent", function() { return CurrencyComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../app.settings */ "./src/app/app.settings.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let CurrencyComponent = class CurrencyComponent {
    constructor(appSettings) {
        this.appSettings = appSettings;
        this.currencies = ['USD', 'EUR'];
        this.settings = this.appSettings.settings;
    }
    ngOnInit() {
        this.currency = this.settings.currency;
    }
    changeCurrency(currency) {
        this.currency = currency;
        this.settings.currency = currency;
    }
};
CurrencyComponent.ctorParameters = () => [
    { type: _app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"] }
];
CurrencyComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-currency',
        template: __importDefault(__webpack_require__(/*! raw-loader!./currency.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/currency/currency.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./currency.component.scss */ "./src/app/theme/components/currency/currency.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"]])
], CurrencyComponent);



/***/ }),

/***/ "./src/app/theme/components/footer/footer.component.scss":
/*!***************************************************************!*\
  !*** ./src/app/theme/components/footer/footer.component.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RoZW1lL2NvbXBvbmVudHMvZm9vdGVyL2Zvb3Rlci5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/theme/components/footer/footer.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/theme/components/footer/footer.component.ts ***!
  \*************************************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _utils_app_validators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utils/app-validators */ "./src/app/theme/utils/app-validators.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



let FooterComponent = class FooterComponent {
    constructor(formBuilder) {
        this.formBuilder = formBuilder;
        this.lat = 40.678178;
        this.lng = -73.944158;
        this.zoom = 12;
        this.mapStyles = [
            {
                "featureType": "all",
                "elementType": "labels.text.fill",
                "stylers": [
                    {
                        "saturation": 36
                    },
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 40
                    }
                ]
            },
            {
                "featureType": "all",
                "elementType": "labels.text.stroke",
                "stylers": [
                    {
                        "visibility": "on"
                    },
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 16
                    }
                ]
            },
            {
                "featureType": "all",
                "elementType": "labels.icon",
                "stylers": [
                    {
                        "visibility": "off"
                    }
                ]
            },
            {
                "featureType": "administrative",
                "elementType": "geometry.fill",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 20
                    }
                ]
            },
            {
                "featureType": "administrative",
                "elementType": "geometry.stroke",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 17
                    },
                    {
                        "weight": 1.2
                    }
                ]
            },
            {
                "featureType": "administrative",
                "elementType": "labels.text.fill",
                "stylers": [
                    {
                        "color": "#8b9198"
                    }
                ]
            },
            {
                "featureType": "landscape",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 20
                    }
                ]
            },
            {
                "featureType": "landscape",
                "elementType": "geometry.fill",
                "stylers": [
                    {
                        "color": "#323336"
                    }
                ]
            },
            {
                "featureType": "landscape.man_made",
                "elementType": "geometry.stroke",
                "stylers": [
                    {
                        "color": "#414954"
                    }
                ]
            },
            {
                "featureType": "poi",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 21
                    }
                ]
            },
            {
                "featureType": "poi",
                "elementType": "geometry.fill",
                "stylers": [
                    {
                        "color": "#2e2f31"
                    }
                ]
            },
            {
                "featureType": "road",
                "elementType": "labels.text.fill",
                "stylers": [
                    {
                        "color": "#7a7c80"
                    }
                ]
            },
            {
                "featureType": "road.highway",
                "elementType": "geometry.fill",
                "stylers": [
                    {
                        "color": "#242427"
                    },
                    {
                        "lightness": 17
                    }
                ]
            },
            {
                "featureType": "road.highway",
                "elementType": "geometry.stroke",
                "stylers": [
                    {
                        "color": "#202022"
                    },
                    {
                        "lightness": 29
                    },
                    {
                        "weight": 0.2
                    }
                ]
            },
            {
                "featureType": "road.arterial",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 18
                    }
                ]
            },
            {
                "featureType": "road.arterial",
                "elementType": "geometry.fill",
                "stylers": [
                    {
                        "color": "#393a3f"
                    }
                ]
            },
            {
                "featureType": "road.arterial",
                "elementType": "geometry.stroke",
                "stylers": [
                    {
                        "color": "#202022"
                    }
                ]
            },
            {
                "featureType": "road.local",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 16
                    }
                ]
            },
            {
                "featureType": "road.local",
                "elementType": "geometry.fill",
                "stylers": [
                    {
                        "color": "#393a3f"
                    }
                ]
            },
            {
                "featureType": "road.local",
                "elementType": "geometry.stroke",
                "stylers": [
                    {
                        "color": "#202022"
                    }
                ]
            },
            {
                "featureType": "transit",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 19
                    }
                ]
            },
            {
                "featureType": "water",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#000000"
                    },
                    {
                        "lightness": 17
                    }
                ]
            },
            {
                "featureType": "water",
                "elementType": "geometry.fill",
                "stylers": [
                    {
                        "color": "#202124"
                    }
                ]
            }
        ];
    }
    ngOnInit() {
        this.feedbackForm = this.formBuilder.group({
            email: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _utils_app_validators__WEBPACK_IMPORTED_MODULE_2__["emailValidator"]])],
            message: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]
        });
        this.subscribeForm = this.formBuilder.group({
            email: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _utils_app_validators__WEBPACK_IMPORTED_MODULE_2__["emailValidator"]])]
        });
    }
    onFeedbackFormSubmit(values) {
        if (this.feedbackForm.valid) {
            console.log(values);
        }
    }
    onSubscribeFormSubmit(values) {
        if (this.subscribeForm.valid) {
            console.log(values);
        }
    }
};
FooterComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"] }
];
FooterComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-footer',
        template: __importDefault(__webpack_require__(/*! raw-loader!./footer.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/footer/footer.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./footer.component.scss */ "./src/app/theme/components/footer/footer.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]])
], FooterComponent);



/***/ }),

/***/ "./src/app/theme/components/lang/lang.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/theme/components/lang/lang.component.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RoZW1lL2NvbXBvbmVudHMvbGFuZy9sYW5nLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/theme/components/lang/lang.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/theme/components/lang/lang.component.ts ***!
  \*********************************************************/
/*! exports provided: LangComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LangComponent", function() { return LangComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../app.settings */ "./src/app/app.settings.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let LangComponent = class LangComponent {
    constructor(appSettings) {
        this.appSettings = appSettings;
        this.flags = [
            { name: 'English', image: 'assets/images/flags/gb.svg', locale: 'en' },
            { name: 'German', image: 'assets/images/flags/de.svg', locale: 'de' },
            { name: 'Spanish', image: 'assets/images/flags/es.svg', locale: 'es' },
        ];
        this.settings = this.appSettings.settings;
    }
    ngOnInit() {
        this.flag = this.flags.find(flag => {
            return flag.locale === this.settings.locale;
        });
        this.locale = this.flag.locale;
    }
    changeLang(flag) {
        this.flag = flag;
        this.locale = this.flag.locale;
        this.settings.locale = this.flag.locale;
        console.log(this.flag, this.locale);
    }
};
LangComponent.ctorParameters = () => [
    { type: _app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"] }
];
LangComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-lang',
        template: __importDefault(__webpack_require__(/*! raw-loader!./lang.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/lang/lang.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./lang.component.scss */ "./src/app/theme/components/lang/lang.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_app_settings__WEBPACK_IMPORTED_MODULE_1__["AppSettings"]])
], LangComponent);



/***/ }),

/***/ "./src/app/theme/components/menu/horizontal-menu/horizontal-menu.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/theme/components/menu/horizontal-menu/horizontal-menu.component.scss ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RoZW1lL2NvbXBvbmVudHMvbWVudS9ob3Jpem9udGFsLW1lbnUvaG9yaXpvbnRhbC1tZW51LmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/theme/components/menu/horizontal-menu/horizontal-menu.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/theme/components/menu/horizontal-menu/horizontal-menu.component.ts ***!
  \************************************************************************************/
/*! exports provided: HorizontalMenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HorizontalMenuComponent", function() { return HorizontalMenuComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _menu_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../menu.service */ "./src/app/theme/components/menu/menu.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let HorizontalMenuComponent = class HorizontalMenuComponent {
    constructor(menuService) {
        this.menuService = menuService;
    }
    ngOnInit() {
        this.menuItems = this.menuService.getHorizontalMenuItems();
        this.menuItems = this.menuItems.filter(item => item.parentId == this.menuParentId);
    }
};
HorizontalMenuComponent.ctorParameters = () => [
    { type: _menu_service__WEBPACK_IMPORTED_MODULE_1__["MenuService"] }
];
HorizontalMenuComponent.propDecorators = {
    menuParentId: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['menuParentId',] }]
};
HorizontalMenuComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-horizontal-menu',
        template: __importDefault(__webpack_require__(/*! raw-loader!./horizontal-menu.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/menu/horizontal-menu/horizontal-menu.component.html")).default,
        providers: [_menu_service__WEBPACK_IMPORTED_MODULE_1__["MenuService"]],
        styles: [__importDefault(__webpack_require__(/*! ./horizontal-menu.component.scss */ "./src/app/theme/components/menu/horizontal-menu/horizontal-menu.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_menu_service__WEBPACK_IMPORTED_MODULE_1__["MenuService"]])
], HorizontalMenuComponent);



/***/ }),

/***/ "./src/app/theme/components/menu/menu.model.ts":
/*!*****************************************************!*\
  !*** ./src/app/theme/components/menu/menu.model.ts ***!
  \*****************************************************/
/*! exports provided: Menu */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Menu", function() { return Menu; });
class Menu {
    constructor(id, title, routerLink, href, target, hasSubMenu, parentId, auth, guest) {
        this.id = id;
        this.title = title;
        this.routerLink = routerLink;
        this.href = href;
        this.target = target;
        this.hasSubMenu = hasSubMenu;
        this.parentId = parentId;
        this.auth = auth;
        this.guest = guest;
    }
}


/***/ }),

/***/ "./src/app/theme/components/menu/menu.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/theme/components/menu/menu.service.ts ***!
  \*******************************************************/
/*! exports provided: MenuService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuService", function() { return MenuService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./menu */ "./src/app/theme/components/menu/menu.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




let MenuService = class MenuService {
    constructor(location, router) {
        this.location = location;
        this.router = router;
    }
    getVerticalMenuItems() {
        return _menu__WEBPACK_IMPORTED_MODULE_3__["verticalMenuItems"];
    }
    getHorizontalMenuItems() {
        return _menu__WEBPACK_IMPORTED_MODULE_3__["horizontalMenuItems"];
    }
    expandActiveSubMenu(menu) {
        let url = this.location.path();
        let routerLink = decodeURIComponent(url);
        let activeMenuItem = menu.filter(item => item.routerLink === routerLink);
        if (activeMenuItem[0]) {
            let menuItem = activeMenuItem[0];
            while (menuItem.parentId != 0) {
                let parentMenuItem = menu.filter(item => item.id == menuItem.parentId)[0];
                menuItem = parentMenuItem;
                this.toggleMenuItem(menuItem.id);
            }
        }
    }
    toggleMenuItem(menuId) {
        let menuItem = document.getElementById('menu-item-' + menuId);
        let subMenu = document.getElementById('sub-menu-' + menuId);
        if (subMenu) {
            if (subMenu.classList.contains('show')) {
                subMenu.classList.remove('show');
                menuItem.classList.remove('expanded');
            }
            else {
                subMenu.classList.add('show');
                menuItem.classList.add('expanded');
            }
        }
    }
    closeOtherSubMenus(menu, menuId) {
        let currentMenuItem = menu.filter(item => item.id == menuId)[0];
        menu.forEach(item => {
            if ((item.id != menuId && item.parentId == currentMenuItem.parentId) || (currentMenuItem.parentId == 0 && item.id != menuId)) {
                let subMenu = document.getElementById('sub-menu-' + item.id);
                let menuItem = document.getElementById('menu-item-' + item.id);
                if (subMenu) {
                    if (subMenu.classList.contains('show')) {
                        subMenu.classList.remove('show');
                        menuItem.classList.remove('expanded');
                    }
                }
            }
        });
    }
    closeAllSubMenus() {
        _menu__WEBPACK_IMPORTED_MODULE_3__["verticalMenuItems"].forEach(item => {
            let subMenu = document.getElementById('sub-menu-' + item.id);
            let menuItem = document.getElementById('menu-item-' + item.id);
            if (subMenu) {
                if (subMenu.classList.contains('show')) {
                    subMenu.classList.remove('show');
                    menuItem.classList.remove('expanded');
                }
            }
        });
    }
};
MenuService.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_2__["Location"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
];
MenuService = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
    __metadata("design:paramtypes", [_angular_common__WEBPACK_IMPORTED_MODULE_2__["Location"],
        _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
], MenuService);



/***/ }),

/***/ "./src/app/theme/components/menu/menu.ts":
/*!***********************************************!*\
  !*** ./src/app/theme/components/menu/menu.ts ***!
  \***********************************************/
/*! exports provided: horizontalMenuItems, verticalMenuItems */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "horizontalMenuItems", function() { return horizontalMenuItems; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verticalMenuItems", function() { return verticalMenuItems; });
/* harmony import */ var _menu_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./menu.model */ "./src/app/theme/components/menu/menu.model.ts");

const horizontalMenuItems = [
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](1, 'Home', '/', null, null, false, 0),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](2, 'Properties', '/properties', null, null, false, 0),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](40, 'Pages', null, null, null, true, 0),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](41, 'Agents', '/agents', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](42, 'Agent', '/agents/1', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](43, 'Login', '/login', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](44, 'Register', '/register', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](71, 'Forget Password', '/password/email', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](45, 'FAQs', '/faq', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](46, 'Pricing', '/pricing', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](47, 'Terms & Conditions', '/terms-conditions', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](50, '404 Page', '/404', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](70, 'About Us', '/about', null, null, false, 0)
];
const verticalMenuItems = [
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](1, 'Home', '/', null, null, false, 0),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](2, 'Properties', '/properties', null, null, false, 0),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](40, 'Pages', null, null, null, true, 0),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](41, 'Agents', '/agents', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](42, 'Agent', '/agents/1', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](43, 'Login', '/login', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](44, 'Register', '/register', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](71, 'Forget Password', '/password/email', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](45, 'FAQs', '/faq', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](46, 'Pricing', '/pricing', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](47, 'Terms & Conditions', '/terms-conditions', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](50, '404 Page', '/404', null, null, false, 40),
    new _menu_model__WEBPACK_IMPORTED_MODULE_0__["Menu"](70, 'About Us', '/about', null, null, false, 0)
];


/***/ }),

/***/ "./src/app/theme/components/menu/vertical-menu/vertical-menu.component.scss":
/*!**********************************************************************************!*\
  !*** ./src/app/theme/components/menu/vertical-menu/vertical-menu.component.scss ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".menu-expand-icon {\n  position: absolute;\n  right: 10px;\n  top: 10px;\n}\n\n.menu-item .mat-button {\n  width: 100%;\n  font-weight: 400;\n  text-transform: uppercase;\n  height: 38px;\n}\n\n.menu-item .mat-button.expanded .menu-expand-icon {\n  transform: rotate(180deg);\n}\n\n.menu-item .mat-button-wrapper {\n  padding-left: 16px;\n}\n\n.sub-menu {\n  max-height: 0;\n  overflow: hidden;\n  transition: max-height 0.25s ease-out;\n}\n\n.sub-menu .sub-menu .mat-button {\n  padding-left: 56px;\n}\n\n.sub-menu .sub-menu .sub-menu .mat-button {\n  padding-left: 76px;\n}\n\n.sub-menu .sub-menu .sub-menu .sub-menu .mat-button {\n  padding-left: 96px;\n}\n\n.sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .mat-button {\n  padding-left: 116px;\n}\n\n.sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .mat-button {\n  padding-left: 136px;\n}\n\n.sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .mat-button {\n  padding-left: 156px;\n}\n\n.sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .mat-button {\n  padding-left: 176px;\n}\n\n.sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .mat-button {\n  padding-left: 196px;\n}\n\n.sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .sub-menu .mat-button {\n  padding-left: 216px;\n}\n\n.sub-menu .mat-button {\n  padding-left: 36px;\n}\n\n.sub-menu.show {\n  max-height: 500px;\n  transition: max-height 0.25s ease-in;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGhlbWUvY29tcG9uZW50cy9tZW51L3ZlcnRpY2FsLW1lbnUvdmVydGljYWwtbWVudS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvdGhlbWUvc3R5bGVzL19taXhpbnMuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7QUFESjs7QUFLSTtFQUNJLFdBQUE7RUFDQSxnQkFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtBQUZSOztBQUlZO0VBR0kseUJBQUE7QUFGaEI7O0FBTUk7RUFDSSxrQkFBQTtBQUpSOztBQVFBO0VBRUksYUFBQTtFQUNBLGdCQUFBO0VBR0EscUNBQUE7QUFOSjs7QUN2QlE7RUFLUSxrQkFBQTtBRHFCaEI7O0FDMUJRO0VBS1Esa0JBQUE7QUR3QmhCOztBQzdCUTtFQUtRLGtCQUFBO0FEMkJoQjs7QUNoQ1E7RUFLUSxtQkFBQTtBRDhCaEI7O0FDbkNRO0VBS1EsbUJBQUE7QURpQ2hCOztBQ3RDUTtFQUtRLG1CQUFBO0FEb0NoQjs7QUN6Q1E7RUFLUSxtQkFBQTtBRHVDaEI7O0FDNUNRO0VBS1EsbUJBQUE7QUQwQ2hCOztBQy9DUTtFQUtRLG1CQUFBO0FENkNoQjs7QUFwQkk7RUFDSSxrQkFBQTtBQXNCUjs7QUFwQkk7RUFDSSxpQkFBQTtFQUdBLG9DQUFBO0FBc0JSIiwiZmlsZSI6InNyYy9hcHAvdGhlbWUvY29tcG9uZW50cy9tZW51L3ZlcnRpY2FsLW1lbnUvdmVydGljYWwtbWVudS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgXCIuLi8uLi8uLi9zdHlsZXMvbWl4aW5zXCI7XG5cbi5tZW51LWV4cGFuZC1pY29ue1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICByaWdodDogMTBweDtcbiAgICB0b3A6IDEwcHg7XG59XG5cbi5tZW51LWl0ZW17XG4gICAgLm1hdC1idXR0b257XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBmb250LXdlaWdodDogNDAwO1xuICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgICBoZWlnaHQ6IDM4cHg7XG4gICAgICAgICYuZXhwYW5kZWR7XG4gICAgICAgICAgICAubWVudS1leHBhbmQtaWNvbntcbiAgICAgICAgICAgICAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDE4MGRlZyk7XG4gICAgICAgICAgICAgICAgLW1vei10cmFuc2Zvcm06IHJvdGF0ZSgxODBkZWcpO1xuICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDE4MGRlZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgLm1hdC1idXR0b24td3JhcHBlcntcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICAgIH0gICAgXG59XG5cbi5zdWItbWVudXtcbiAgICBAaW5jbHVkZSBtZW51LWxldmVsLXBhZGRpbmcoJ2x0cicpO1xuICAgIG1heC1oZWlnaHQ6IDA7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAtd2Via2l0LXRyYW5zaXRpb246IG1heC1oZWlnaHQgMC4yNXMgZWFzZS1vdXQ7ICBcbiAgICAtbW96LXRyYW5zaXRpb246IG1heC1oZWlnaHQgMC4yNXMgZWFzZS1vdXQ7ICBcbiAgICB0cmFuc2l0aW9uOiBtYXgtaGVpZ2h0IDAuMjVzIGVhc2Utb3V0OyAgICBcbiAgICAubWF0LWJ1dHRvbntcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAzNnB4OyAgICAgIFxuICAgIH0gXG4gICAgJi5zaG93e1xuICAgICAgICBtYXgtaGVpZ2h0OiA1MDBweDtcbiAgICAgICAgLXdlYmtpdC10cmFuc2l0aW9uOiBtYXgtaGVpZ2h0IDAuMjVzIGVhc2UtaW47XG4gICAgICAgIC1tb3otdHJhbnNpdGlvbjogbWF4LWhlaWdodCAwLjI1cyBlYXNlLWluO1xuICAgICAgICB0cmFuc2l0aW9uOiBtYXgtaGVpZ2h0IDAuMjVzIGVhc2UtaW47XG4gICAgfSAgICBcbn0iLCJAbWl4aW4gbWVudS1sZXZlbC1wYWRkaW5nKCRkaXJlY3Rpb24pe1xuICAgICRlbGVtOiAnJztcbiAgICBAZm9yICRpIGZyb20gMiB0aHJvdWdoIDEwIHtcbiAgICAgICAgJGVsZW06IGlmKCRpID09IDIsIFwiLnN1Yi1tZW51XCIsIHNlbGVjdG9yLW5lc3QoJGVsZW0sIFwiLnN1Yi1tZW51XCIpKTsgICAgICBcbiAgICAgICAgI3skZWxlbSArICcgLm1hdC1idXR0b24nfSB7IFxuICAgICAgICAgICAgQGlmICRkaXJlY3Rpb24gPT0gXCJydGxcIiB7XG4gICAgICAgICAgICAgICAgcGFkZGluZy1yaWdodDogMTZweCArICgyMHB4ICogJGkpO1xuICAgICAgICAgICAgfSBcbiAgICAgICAgICAgIEBlbHNle1xuICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMTZweCArICgyMHB4ICogJGkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufSJdfQ== */");

/***/ }),

/***/ "./src/app/theme/components/menu/vertical-menu/vertical-menu.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/theme/components/menu/vertical-menu/vertical-menu.component.ts ***!
  \********************************************************************************/
/*! exports provided: VerticalMenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerticalMenuComponent", function() { return VerticalMenuComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _menu_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../menu.service */ "./src/app/theme/components/menu/menu.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let VerticalMenuComponent = class VerticalMenuComponent {
    constructor(menuService) {
        this.menuService = menuService;
    }
    ngOnInit() {
        this.menuItems = this.menuService.getVerticalMenuItems();
        this.menuItems = this.menuItems.filter(item => item.parentId == this.menuParentId);
    }
    onClick(menuId) {
        this.menuService.toggleMenuItem(menuId);
        this.menuService.closeOtherSubMenus(this.menuService.getVerticalMenuItems(), menuId);
    }
};
VerticalMenuComponent.ctorParameters = () => [
    { type: _menu_service__WEBPACK_IMPORTED_MODULE_1__["MenuService"] }
];
VerticalMenuComponent.propDecorators = {
    menuParentId: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"], args: ['menuParentId',] }]
};
VerticalMenuComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-vertical-menu',
        template: __importDefault(__webpack_require__(/*! raw-loader!./vertical-menu.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/menu/vertical-menu/vertical-menu.component.html")).default,
        providers: [_menu_service__WEBPACK_IMPORTED_MODULE_1__["MenuService"]],
        styles: [__importDefault(__webpack_require__(/*! ./vertical-menu.component.scss */ "./src/app/theme/components/menu/vertical-menu/vertical-menu.component.scss")).default]
    }),
    __metadata("design:paramtypes", [_menu_service__WEBPACK_IMPORTED_MODULE_1__["MenuService"]])
], VerticalMenuComponent);



/***/ }),

/***/ "./src/app/theme/components/social-icons/social-icons.component.scss":
/*!***************************************************************************!*\
  !*** ./src/app/theme/components/social-icons/social-icons.component.scss ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RoZW1lL2NvbXBvbmVudHMvc29jaWFsLWljb25zL3NvY2lhbC1pY29ucy5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/theme/components/social-icons/social-icons.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/theme/components/social-icons/social-icons.component.ts ***!
  \*************************************************************************/
/*! exports provided: SocialIconsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SocialIconsComponent", function() { return SocialIconsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

let SocialIconsComponent = class SocialIconsComponent {
    constructor() {
        this.iconSize = '';
        this.iconColor = '';
    }
    ngOnInit() {
    }
};
SocialIconsComponent.ctorParameters = () => [];
SocialIconsComponent.propDecorators = {
    iconSize: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    iconColor: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }]
};
SocialIconsComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-social-icons',
        template: __importDefault(__webpack_require__(/*! raw-loader!./social-icons.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/social-icons/social-icons.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./social-icons.component.scss */ "./src/app/theme/components/social-icons/social-icons.component.scss")).default]
    }),
    __metadata("design:paramtypes", [])
], SocialIconsComponent);



/***/ }),

/***/ "./src/app/theme/components/toolbar1/toolbar1.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/theme/components/toolbar1/toolbar1.component.ts ***!
  \*****************************************************************/
/*! exports provided: Toolbar1Component */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Toolbar1Component", function() { return Toolbar1Component; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/app.service */ "./src/app/app.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let Toolbar1Component = class Toolbar1Component {
    constructor(appService) {
        this.appService = appService;
        this.onMenuIconClick = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    ngOnInit() { }
    sidenavToggle() {
        this.onMenuIconClick.emit();
    }
};
Toolbar1Component.ctorParameters = () => [
    { type: src_app_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"] }
];
Toolbar1Component.propDecorators = {
    onMenuIconClick: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }]
};
Toolbar1Component = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-toolbar1',
        template: __importDefault(__webpack_require__(/*! raw-loader!./toolbar1.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/toolbar1/toolbar1.component.html")).default
    }),
    __metadata("design:paramtypes", [src_app_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]])
], Toolbar1Component);



/***/ }),

/***/ "./src/app/theme/components/toolbar2/toolbar2.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/theme/components/toolbar2/toolbar2.component.ts ***!
  \*****************************************************************/
/*! exports provided: Toolbar2Component */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Toolbar2Component", function() { return Toolbar2Component; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/app.service */ "./src/app/app.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


let Toolbar2Component = class Toolbar2Component {
    constructor(appService) {
        this.appService = appService;
        this.onMenuIconClick = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    ngOnInit() { }
    sidenavToggle() {
        this.onMenuIconClick.emit();
    }
};
Toolbar2Component.ctorParameters = () => [
    { type: src_app_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"] }
];
Toolbar2Component.propDecorators = {
    onMenuIconClick: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }]
};
Toolbar2Component = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-toolbar2',
        template: __importDefault(__webpack_require__(/*! raw-loader!./toolbar2.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/toolbar2/toolbar2.component.html")).default
    }),
    __metadata("design:paramtypes", [src_app_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]])
], Toolbar2Component);



/***/ }),

/***/ "./src/app/theme/components/user-menu/user-menu.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/theme/components/user-menu/user-menu.component.scss ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RoZW1lL2NvbXBvbmVudHMvdXNlci1tZW51L3VzZXItbWVudS5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/theme/components/user-menu/user-menu.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/theme/components/user-menu/user-menu.component.ts ***!
  \*******************************************************************/
/*! exports provided: UserMenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserMenuComponent", function() { return UserMenuComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/app.service */ "./src/app/app.service.ts");
/* harmony import */ var src_app_services_user_helper_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/user-helper.service */ "./src/app/services/user-helper.service.ts");
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ "./src/app/services/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/snack-bar */ "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/snack-bar.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};






let UserMenuComponent = class UserMenuComponent {
    constructor(appService, router, snackBar, authService, userHelperService) {
        this.appService = appService;
        this.router = router;
        this.snackBar = snackBar;
        this.authService = authService;
        this.userHelperService = userHelperService;
    }
    ngOnInit() {
        this.isLoggedIn$ = this.authService.isLoggedIn;
        this.isLoggedIn$.subscribe((res) => {
            this.user = this.userHelperService.user();
        });
    }
    onLogout() {
        this.authService.logout().subscribe((res) => {
            // Store the access token in the localstorage
            localStorage.setItem('access_token', null);
        }, (err) => {
            localStorage.setItem('access_token', null);
            // This error can be internal or invalid credentials
            // You need to customize this based on the error.status code
        });
        this.authService.loggedIn.next(false);
        localStorage.setItem('user', null);
        this.snackBar.open('Logged Out successfully!', '×', { panelClass: 'success', verticalPosition: 'top', duration: 3000 });
        this.router.navigate(['/login']);
    }
};
UserMenuComponent.ctorParameters = () => [
    { type: src_app_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_5__["MatSnackBar"] },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
    { type: src_app_services_user_helper_service__WEBPACK_IMPORTED_MODULE_2__["UserHelperService"] }
];
UserMenuComponent = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
        selector: 'app-user-menu',
        template: __importDefault(__webpack_require__(/*! raw-loader!./user-menu.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/theme/components/user-menu/user-menu.component.html")).default,
        styles: [__importDefault(__webpack_require__(/*! ./user-menu.component.scss */ "./src/app/theme/components/user-menu/user-menu.component.scss")).default]
    }),
    __metadata("design:paramtypes", [src_app_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
        _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_5__["MatSnackBar"],
        src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"],
        src_app_services_user_helper_service__WEBPACK_IMPORTED_MODULE_2__["UserHelperService"]])
], UserMenuComponent);



/***/ }),

/***/ "./src/app/theme/directives/directives.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/theme/directives/directives.module.ts ***!
  \*******************************************************/
/*! exports provided: DirectivesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DirectivesModule", function() { return DirectivesModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _only_number_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./only-number.directive */ "./src/app/theme/directives/only-number.directive.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



let DirectivesModule = class DirectivesModule {
};
DirectivesModule = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
        declarations: [
            _only_number_directive__WEBPACK_IMPORTED_MODULE_2__["OnlyNumberDirective"]
        ],
        exports: [
            _only_number_directive__WEBPACK_IMPORTED_MODULE_2__["OnlyNumberDirective"]
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]
        ]
    })
], DirectivesModule);



/***/ }),

/***/ "./src/app/theme/directives/only-number.directive.ts":
/*!***********************************************************!*\
  !*** ./src/app/theme/directives/only-number.directive.ts ***!
  \***********************************************************/
/*! exports provided: OnlyNumberDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OnlyNumberDirective", function() { return OnlyNumberDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

let OnlyNumberDirective = class OnlyNumberDirective {
    constructor() { }
    onInputChange(e) {
        if (e.target.value.length == 0 && e.which == 48) {
            return false;
        }
        var verified = String.fromCharCode(e.which).match(/[^0-9]/g);
        if (verified) {
            e.preventDefault();
            return false;
        }
        // var regex = new RegExp("[^0-9]");
        // var key = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        // if (regex.test(key)) {
        //     event.preventDefault();
        //     return false;
        // }    
    }
};
OnlyNumberDirective.ctorParameters = () => [];
OnlyNumberDirective.propDecorators = {
    onInputChange: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"], args: ['keypress', ['$event'],] }]
};
OnlyNumberDirective = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"])({
        selector: 'input[onlyNumber]'
    }),
    __metadata("design:paramtypes", [])
], OnlyNumberDirective);



/***/ }),

/***/ "./src/app/theme/pipes/filter-by-id.pipe.ts":
/*!**************************************************!*\
  !*** ./src/app/theme/pipes/filter-by-id.pipe.ts ***!
  \**************************************************/
/*! exports provided: FilterByIdPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilterByIdPipe", function() { return FilterByIdPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

let FilterByIdPipe = class FilterByIdPipe {
    transform(items, id) {
        return items.filter(item => item.id == id)[0];
    }
};
FilterByIdPipe = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({
        name: 'filterById'
    })
], FilterByIdPipe);



/***/ }),

/***/ "./src/app/theme/pipes/filter-neighborhoods.ts":
/*!*****************************************************!*\
  !*** ./src/app/theme/pipes/filter-neighborhoods.ts ***!
  \*****************************************************/
/*! exports provided: FilterNeighborhoodsPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilterNeighborhoodsPipe", function() { return FilterNeighborhoodsPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

let FilterNeighborhoodsPipe = class FilterNeighborhoodsPipe {
    transform(items, id) {
        if (id) {
            return items.filter(item => item.cityId == id);
        }
        return items;
    }
};
FilterNeighborhoodsPipe = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({
        name: 'filterNeighborhoods'
    })
], FilterNeighborhoodsPipe);



/***/ }),

/***/ "./src/app/theme/pipes/filter-streets.pipe.ts":
/*!****************************************************!*\
  !*** ./src/app/theme/pipes/filter-streets.pipe.ts ***!
  \****************************************************/
/*! exports provided: FilterStreetsPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilterStreetsPipe", function() { return FilterStreetsPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

let FilterStreetsPipe = class FilterStreetsPipe {
    transform(items, filter) {
        let neighborhoodIds = [];
        if (filter.neighborhoods) {
            filter.neighborhoods.forEach(neighborhood => {
                neighborhoodIds.push(neighborhood.id);
            });
        }
        if (neighborhoodIds.length > 0) {
            return items.filter(item => {
                return neighborhoodIds.indexOf(item.neighborhoodId) > -1;
            });
        }
        if (filter.cityId) {
            return items.filter(item => item.cityId == filter.cityId);
        }
        return items;
    }
};
FilterStreetsPipe = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({
        name: 'filterStreets'
    })
], FilterStreetsPipe);



/***/ }),

/***/ "./src/app/theme/pipes/l-trans.pipe.ts":
/*!*********************************************!*\
  !*** ./src/app/theme/pipes/l-trans.pipe.ts ***!
  \*********************************************/
/*! exports provided: LTransPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LTransPipe", function() { return LTransPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

let LTransPipe = class LTransPipe {
    transform(item, attribute, locale) {
        if (typeof item === 'undefined' || !item || typeof item[attribute] === 'undefined') {
            return;
        }
        return this.getLocaleValue(item, attribute, locale);
    }
    getLocaleValue(item, attribute, locale) {
        let value;
        if (typeof item[attribute][locale] !== 'undefined') {
            value = item[attribute][locale];
        }
        if (!value && locale !== 'en') {
            // get fallback locale 'en' translation
            return this.getLocaleValue(item, attribute, 'en');
        }
        if (!value) {
            // get any available translation then
            return item[attribute][Object.keys(item[attribute])[0]];
        }
        return value;
    }
};
LTransPipe = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({
        name: 'lTrans'
    })
], LTransPipe);



/***/ }),

/***/ "./src/app/theme/pipes/pipes.module.ts":
/*!*********************************************!*\
  !*** ./src/app/theme/pipes/pipes.module.ts ***!
  \*********************************************/
/*! exports provided: PipesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PipesModule", function() { return PipesModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _filter_by_id_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./filter-by-id.pipe */ "./src/app/theme/pipes/filter-by-id.pipe.ts");
/* harmony import */ var _filter_neighborhoods__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./filter-neighborhoods */ "./src/app/theme/pipes/filter-neighborhoods.ts");
/* harmony import */ var _filter_streets_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./filter-streets.pipe */ "./src/app/theme/pipes/filter-streets.pipe.ts");
/* harmony import */ var _l_trans_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./l-trans.pipe */ "./src/app/theme/pipes/l-trans.pipe.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






let PipesModule = class PipesModule {
};
PipesModule = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]
        ],
        declarations: [
            _filter_by_id_pipe__WEBPACK_IMPORTED_MODULE_2__["FilterByIdPipe"],
            _filter_neighborhoods__WEBPACK_IMPORTED_MODULE_3__["FilterNeighborhoodsPipe"],
            _filter_streets_pipe__WEBPACK_IMPORTED_MODULE_4__["FilterStreetsPipe"],
            _l_trans_pipe__WEBPACK_IMPORTED_MODULE_5__["LTransPipe"]
        ],
        exports: [
            _filter_by_id_pipe__WEBPACK_IMPORTED_MODULE_2__["FilterByIdPipe"],
            _filter_neighborhoods__WEBPACK_IMPORTED_MODULE_3__["FilterNeighborhoodsPipe"],
            _filter_streets_pipe__WEBPACK_IMPORTED_MODULE_4__["FilterStreetsPipe"],
            _l_trans_pipe__WEBPACK_IMPORTED_MODULE_5__["LTransPipe"]
        ]
    })
], PipesModule);



/***/ }),

/***/ "./src/app/theme/utils/app-interceptor.ts":
/*!************************************************!*\
  !*** ./src/app/theme/utils/app-interceptor.ts ***!
  \************************************************/
/*! exports provided: AppInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppInterceptor", function() { return AppInterceptor; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




let AppInterceptor = class AppInterceptor {
    constructor() { }
    intercept(req, next) {
        // console.log(`Request for ${req.urlWithParams} started...`);
        return next.handle(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])((event) => {
            if (event instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpResponse"]) {
                // console.log(`Request for ${req.urlWithParams} completed...`);
            }
            return event;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])((error) => {
            const started = Date.now();
            const elapsed = Date.now() - started;
            console.log(`Request for ${req.urlWithParams} failed after ${elapsed} ms.`);
            // debugger;
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])(error);
        }));
    }
};
AppInterceptor.ctorParameters = () => [];
AppInterceptor = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
    __metadata("design:paramtypes", [])
], AppInterceptor);



/***/ }),

/***/ "./src/app/theme/utils/app-validators.ts":
/*!***********************************************!*\
  !*** ./src/app/theme/utils/app-validators.ts ***!
  \***********************************************/
/*! exports provided: emailValidator, matchingPasswords */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "emailValidator", function() { return emailValidator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "matchingPasswords", function() { return matchingPasswords; });
function emailValidator(control) {
    var emailRegexp = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
    if (control.value && !emailRegexp.test(control.value)) {
        return { invalidEmail: true };
    }
}
function matchingPasswords(passwordKey, passwordConfirmationKey) {
    return (group) => {
        let password = group.controls[passwordKey];
        let passwordConfirmation = group.controls[passwordConfirmationKey];
        if (password.value !== passwordConfirmation.value) {
            return passwordConfirmation.setErrors({ mismatchedPasswords: true });
        }
    };
}


/***/ }),

/***/ "./src/app/theme/utils/custom-overlay-container.ts":
/*!*********************************************************!*\
  !*** ./src/app/theme/utils/custom-overlay-container.ts ***!
  \*********************************************************/
/*! exports provided: CustomOverlayContainer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomOverlayContainer", function() { return CustomOverlayContainer; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/cdk/overlay */ "./node_modules/@angular/cdk/__ivy_ngcc__/fesm2015/overlay.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


let CustomOverlayContainer = class CustomOverlayContainer extends _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_1__["OverlayContainer"] {
    _createContainer() {
        let container = document.createElement('div');
        container.classList.add('cdk-overlay-container');
        document.getElementById('app').appendChild(container);
        this._containerElement = container;
    }
};
CustomOverlayContainer = __decorate([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])()
], CustomOverlayContainer);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    apiUrl: 'https://crawlerproject.ddns.net',
    selfApiUrl: 'http://localhost:4200',
    hj: 'xxxxxxx',
    ga: 'xxxxxxx'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/__ivy_ngcc__/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
document.addEventListener('DOMContentLoaded', () => {
    Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
        .catch(err => console.log(err));
});


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Applications/XAMPP/xamppfiles/htdocs/hv-ionic-ssr/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map