function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-sendResetLinkEmail-sendResetLinkEmail-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sendResetLinkEmail/sendResetLinkEmail.component.html":
  /*!******************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sendResetLinkEmail/sendResetLinkEmail.component.html ***!
    \******************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesSendResetLinkEmailSendResetLinkEmailComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"p-3\">\n  <div class=\"theme-container\">\n\n    <div fxLayout=\"row\" fxLayoutAlign=\"center center\" class=\"my-3 sendResetLinkEmail-card-container\" fxFlex=\"100\" fxFlex.gt-sm=\"40\" fxFlex.sm=\"50\">\n        <mat-card class=\"sendResetLinkEmail-card\" [style.max-width.px]=\"500\">\n          <div fxLayout=\"column\" fxLayoutAlign=\"center center\" class=\"text-center\">  \n            <h1 class=\"uppercase\">Forgot Password?</h1>\n          </div>\n          <form [formGroup]=\"sendResetLinkEmailForm\" (ngSubmit)=\"onSendResetLinkEmailFormSubmit(sendResetLinkEmailForm.value)\">\n              <mat-form-field appearance=\"outline\" class=\"w-100 mt-2\">\n                  <mat-icon matPrefix class=\"mr-1 text-muted\">person</mat-icon>\n                  <mat-label>Email</mat-label>\n                  <input matInput placeholder=\"Email\" formControlName=\"email\" required>\n                  <mat-error *ngIf=\"sendResetLinkEmailForm.controls.email.errors?.required\">Email is required</mat-error>\n                  <mat-error *ngIf=\"sendResetLinkEmailForm.controls.email.hasError('email')\">Invalid Email</mat-error>\n              </mat-form-field>\n              <div class=\"text-center mt-2\"> \n                  <button mat-raised-button color=\"accent\" class=\"uppercase\" type=\"submit\" [disabled]=\"loading\">\n                      Send Password Reset Link\n                  </button>\n              </div>\n          </form>\n          <mat-card-actions fxLayoutAlign=\"end center\">\n            <a routerLink=\"/login\" mat-button>\n              <mat-icon class=\"text-muted\">login</mat-icon>\n              <span class=\"mx-1\">Back to Login</span>\n            </a>\n          </mat-card-actions>\n        </mat-card>\n    </div> \n\n  </div>\n</div>";
    /***/
  },

  /***/
  "./src/app/pages/sendResetLinkEmail/sendResetLinkEmail.component.scss":
  /*!****************************************************************************!*\
    !*** ./src/app/pages/sendResetLinkEmail/sendResetLinkEmail.component.scss ***!
    \****************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesSendResetLinkEmailSendResetLinkEmailComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".auth {\n  white-space: nowrap;\n  padding: 7px 14px;\n  font-weight: 500;\n}\n\n.alert.alert-danger {\n  color: #ff5252;\n}\n\n.sendResetLinkEmail-card-container {\n  margin: 0 auto;\n}\n\n.sendResetLinkEmail-card.mat-card {\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2VuZFJlc2V0TGlua0VtYWlsL3NlbmRSZXNldExpbmtFbWFpbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUNBO0VBQ0ksY0FBQTtBQUVKOztBQUFBO0VBQ0ksY0FBQTtBQUdKOztBQURBO0VBQ0ksV0FBQTtBQUlKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvc2VuZFJlc2V0TGlua0VtYWlsL3NlbmRSZXNldExpbmtFbWFpbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hdXRoIHtcbiAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgIHBhZGRpbmc6IDdweCAxNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG4uYWxlcnQuYWxlcnQtZGFuZ2Vye1xuICAgIGNvbG9yOiAjZmY1MjUyO1xufVxuLnNlbmRSZXNldExpbmtFbWFpbC1jYXJkLWNvbnRhaW5lcntcbiAgICBtYXJnaW46IDAgYXV0bztcbn1cbi5zZW5kUmVzZXRMaW5rRW1haWwtY2FyZC5tYXQtY2FyZHtcbiAgICB3aWR0aDogMTAwJTtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/sendResetLinkEmail/sendResetLinkEmail.component.ts":
  /*!**************************************************************************!*\
    !*** ./src/app/pages/sendResetLinkEmail/sendResetLinkEmail.component.ts ***!
    \**************************************************************************/

  /*! exports provided: SendResetLinkEmailComponent */

  /***/
  function srcAppPagesSendResetLinkEmailSendResetLinkEmailComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SendResetLinkEmailComponent", function () {
      return SendResetLinkEmailComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../services/auth.service */
    "./src/app/services/auth.service.ts");
    /* harmony import */


    var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/material/snack-bar */
    "./node_modules/@angular/material/__ivy_ngcc__/fesm2015/snack-bar.js");

    var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
      var c = arguments.length,
          r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
          d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      }
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };

    var __metadata = undefined && undefined.__metadata || function (k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };

    var __importDefault = undefined && undefined.__importDefault || function (mod) {
      return mod && mod.__esModule ? mod : {
        "default": mod
      };
    };

    var SendResetLinkEmailComponent = /*#__PURE__*/function () {
      function SendResetLinkEmailComponent(fb, router, snackBar, authService) {
        _classCallCheck(this, SendResetLinkEmailComponent);

        this.fb = fb;
        this.router = router;
        this.snackBar = snackBar;
        this.authService = authService;
        this.hide = true;
      }

      _createClass(SendResetLinkEmailComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.sendResetLinkEmailForm = this.fb.group({
            email: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].email])]
          });
        }
      }, {
        key: "onSendResetLinkEmailFormSubmit",
        value: function onSendResetLinkEmailFormSubmit(values) {
          var _this = this;

          if (this.sendResetLinkEmailForm.valid) {
            this.loading = true;
            this.errors = false;
            this.authService.sendResetLinkEmail(this.controls.email.value).subscribe(function (res) {
              // Store the access token in the localstorage
              // localStorage.setItem('access_token', res.success.token);
              // localStorage.setItem('user', JSON.stringify(res.success.user));
              // this.authService.loggedIn.next(true);
              _this.loading = false;

              _this.snackBar.open('We have e-mailed your password reset link!', '×', {
                panelClass: 'success',
                verticalPosition: 'top',
                duration: 3000
              }); // Navigate to home page
              // this.router.navigate(['/']);

            }, function (err) {
              // This error can be internal or invalid credentials
              // You need to customize this based on the error.status code
              _this.loading = false;
              _this.errors = true;
              console.log(err);

              _this.snackBar.open('Oops! Something went wrong', '×', {
                panelClass: 'danger',
                verticalPosition: 'top',
                duration: 3000
              });
            }); // this.router.navigate(['/']);
          }
        }
        /**
         * Getter for the form controls
         */

      }, {
        key: "controls",
        get: function get() {
          return this.sendResetLinkEmailForm.controls;
        }
      }]);

      return SendResetLinkEmailComponent;
    }();

    SendResetLinkEmailComponent.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_4__["MatSnackBar"]
      }, {
        type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }];
    };

    SendResetLinkEmailComponent = __decorate([Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
      selector: 'app-sendResetLinkEmail',
      template: __importDefault(__webpack_require__(
      /*! raw-loader!./sendResetLinkEmail.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sendResetLinkEmail/sendResetLinkEmail.component.html"))["default"],
      styles: [__importDefault(__webpack_require__(
      /*! ./sendResetLinkEmail.component.scss */
      "./src/app/pages/sendResetLinkEmail/sendResetLinkEmail.component.scss"))["default"]]
    }), __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_4__["MatSnackBar"], _services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]])], SendResetLinkEmailComponent);
    /***/
  },

  /***/
  "./src/app/pages/sendResetLinkEmail/sendResetLinkEmail.module.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/pages/sendResetLinkEmail/sendResetLinkEmail.module.ts ***!
    \***********************************************************************/

  /*! exports provided: routes, SendResetLinkEmailModule */

  /***/
  function srcAppPagesSendResetLinkEmailSendResetLinkEmailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "routes", function () {
      return routes;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SendResetLinkEmailModule", function () {
      return SendResetLinkEmailModule;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../shared/shared.module */
    "./src/app/shared/shared.module.ts");
    /* harmony import */


    var _sendResetLinkEmail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./sendResetLinkEmail.component */
    "./src/app/pages/sendResetLinkEmail/sendResetLinkEmail.component.ts");
    /* harmony import */


    var _services_guest_guard_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../services/guest-guard.service */
    "./src/app/services/guest-guard.service.ts");

    var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
      var c = arguments.length,
          r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
          d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      }
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };

    var routes = [{
      path: '',
      component: _sendResetLinkEmail_component__WEBPACK_IMPORTED_MODULE_4__["SendResetLinkEmailComponent"],
      canActivate: [_services_guest_guard_service__WEBPACK_IMPORTED_MODULE_5__["GuestGuardService"]],
      pathMatch: 'full'
    }];

    var SendResetLinkEmailModule = function SendResetLinkEmailModule() {
      _classCallCheck(this, SendResetLinkEmailModule);
    };

    SendResetLinkEmailModule = __decorate([Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
      declarations: [_sendResetLinkEmail_component__WEBPACK_IMPORTED_MODULE_4__["SendResetLinkEmailComponent"]],
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes), _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__["SharedModule"]]
    })], SendResetLinkEmailModule);
    /***/
  }
}]);
//# sourceMappingURL=pages-sendResetLinkEmail-sendResetLinkEmail-module-es5.js.map